#!/usr/bin/env python3
"""One fixed, exploratory equal-run isotonic calibration; nearest channel only."""
from __future__ import annotations

import hashlib
import importlib.util
import io
import json
from pathlib import Path
import platform
import sys
import time
import zipfile

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import isotonic_regression

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WORK = ROOT.parent
REPRO = WORK / "R2E_REPRO_CLEAN_20260920"
CANON = REPRO / "scripts/reproduce_weber_operational.py"
BASELINE = ROOT / "CAUSAL_CORRECTION/outputs/held_out_results.csv"
SENSOR = "TR404-085d"
METHOD = "temperature_isotonic_piecewise_linear"
TOLS = (1., 2., 5., 10.)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    return sha_bytes(Path(path).read_bytes())


def canonical_module():
    spec = importlib.util.spec_from_file_location("frozen_weber_isotonic", CANON)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def first_crossing(t, g):
    falling = np.flatnonzero((g[:-1] >= 1.) & (g[1:] < 1.))
    if not len(falling):
        return None, None
    k = int(falling[0])
    event = t[k] + (1.-g[k])*(t[k+1]-t[k])/(g[k+1]-g[k])
    return float(event), k


def load_runs(mod):
    records, provenance = {}, []
    for archive in sorted((REPRO / "source_zips").glob("DGIG_WEBER_CORE_PRIMARY_*.zip")):
        with zipfile.ZipFile(archive) as z:
            for member in z.namelist():
                if not member.endswith("MeasurementData.CSV"):
                    continue
                run = mod.test_number(Path(member))
                raw = z.read(member)
                df = mod.load_measurement(io.BytesIO(raw))
                expected_rows, expected_hash = mod.EXPECTED_SOURCE[run]
                assert len(df) == expected_rows and sha_bytes(raw) == expected_hash
                start, action = mod.reconstruct_action(df)
                whole_t = df["Time since Start [min]"].to_numpy(float)
                t = whole_t[start:action].copy()
                x = df[SENSOR].to_numpy(float)[start:action].copy()
                y = df[mod.SOURCE_SENSOR].to_numpy(float)[start:action].copy()
                assert np.isfinite([x, y]).all() and np.all(np.diff(t) > 0)
                idx, source_g = mod.gradient_series(t, y, 0, len(t)-1)
                source_event, _ = first_crossing(t[idx], source_g)
                assert source_event is not None and source_event <= t[-1] < whole_t[action]
                records[run] = dict(run=run, t=t, x=x, y=y, gradient_idx=idx, tg=t[idx],
                                    source_g=source_g, source_first=source_event,
                                    start=float(t[0]), horizon=float(t[-1]), action=float(whole_t[action]))
                provenance.append(dict(run=run, source_member=member, archive=archive.name,
                                       rows=len(df), sha256=sha_bytes(raw), hash_and_rows_match=True,
                                       heater_start_index=start, first_off_index=action,
                                       strict_preaction_samples=len(t)))
                del df
                print(f"Verified source and strict boundary: Test {run}", flush=True)
    assert sorted(records) == [4, 5, 6, 7, 8, 9]
    return records, pd.DataFrame(provenance)


def pava_with_duplicate_aggregation(x, y, w):
    knot_x, inverse, counts = np.unique(x, return_inverse=True, return_counts=True)
    knot_w = np.bincount(inverse, weights=w)
    weighted_y = np.bincount(inverse, weights=w*y)
    knot_y = weighted_y/knot_w
    result = isotonic_regression(knot_y, weights=knot_w, increasing=True)
    fitted = np.asarray(result.x, float)
    assert np.all(np.diff(knot_x) > 0) and np.all(np.diff(fitted) >= 0)
    assert np.isfinite(fitted).all() and np.all(knot_w > 0)
    direct_loss = float(np.sum(w*(y-fitted[inverse])**2))
    aggregated_loss = float(np.sum(knot_w*(knot_y-fitted)**2))
    within_duplicate_loss = float(np.sum(w*(y-knot_y[inverse])**2))
    discrepancy = abs(direct_loss-aggregated_loss-within_duplicate_loss)
    assert discrepancy < 1e-9*max(1., direct_loss)
    return dict(x=knot_x, y=fitted, raw_y_mean=knot_y, weights=knot_w,
                counts=counts, n_blocks=len(result.blocks)-1,
                loss=direct_loss, duplicate_loss_identity_error=discrepancy)


def tiny_analytic_check():
    # x=0 has weighted target 1.5 with weight 4/8; the next target is 0
    # with weight 2/8. PAVA pools these to 1. The last fitted value is 3.
    m = pava_with_duplicate_aggregation(np.array([0., 0., 1., 2.]),
         np.array([0., 2., 0., 3.]), np.array([1., 3., 2., 2.])/8.)
    assert np.array_equal(m["x"], [0., 1., 2.])
    assert np.allclose(m["raw_y_mean"], [1.5, 0., 3.], rtol=0, atol=1e-14)
    assert np.allclose(m["weights"], [.5, .25, .25], rtol=0, atol=1e-14)
    assert np.allclose(m["y"], [1., 1., 3.], rtol=0, atol=1e-14)
    assert np.array_equal(predict(m, np.array([-1., .5, 1.5, 3.])), [1., 1., 2., 3.])
    return dict(weighted_duplicate_and_pava_example_passed=True,
                piecewise_linear_interpolation_and_clamp_example_passed=True)


def predict(model, candidate):
    return np.interp(candidate, model["x"], model["y"],
                     left=model["y"][0], right=model["y"][-1])


def fit_model(training):
    assert len(training) == 5
    x = np.concatenate([r["x"] for r in training])
    y = np.concatenate([r["y"] for r in training])
    weights = [np.full(len(r["x"]), 1./(5*len(r["x"]))) for r in training]
    assert all(abs(w.sum()-.2) < 1e-12 for w in weights)
    w = np.concatenate(weights)
    model = pava_with_duplicate_aggregation(x, y, w)
    assert abs(model["weights"].sum()-1.) < 1e-12
    return model


def within_support(values, model):
    return (values >= model["x"][0]) & (values <= model["x"][-1])


def event_support(test, model, event, bracket):
    t, x = test["t"], test["x"]
    history_left = max(0, int(np.searchsorted(t, test["tg"][0]-15., side="right")-1))
    history_right = len(t)-1 if event is None else int(test["gradient_idx"][bracket+1])
    history = x[history_left:history_right+1]
    history_status = dict(first_event_search_history_in_support=bool(within_support(history, model).all()),
                          search_history_start_sample_min=float(t[history_left]),
                          search_history_end_sample_min=float(t[history_right]),
                          search_history_candidate_min_C=float(history.min()),
                          search_history_candidate_max_C=float(history.max()))
    if event is None:
        return dict(event_15min_window_in_support=None, event_computation_inputs_all_in_support=None,
                    event_window_candidate_min_C=None, event_window_candidate_max_C=None,
                    event_sample_footprint_min_C=None, event_sample_footprint_max_C=None,
                    event_footprint_start_sample_min=None, event_footprint_end_sample_min=None, **history_status)
    lower = event-15.
    # The raw candidate trace is linear between recorded timestamps.
    values = np.r_[np.interp([lower, event], t, x), x[(t >= lower) & (t <= event)]]
    left_time = test["tg"][bracket]
    right_index = int(test["gradient_idx"][bracket+1])
    past_left = left_time-15.
    left_index = max(0, int(np.searchsorted(t, past_left, side="right")-1))
    # Includes both event-gradient samples and any earlier interpolation
    # endpoint, as well as all samples between them: stronger than four-point
    # support alone and than support at the nominal event timestamp alone.
    footprint = x[left_index:right_index+1]
    return dict(event_15min_window_in_support=bool(within_support(values, model).all()),
                event_computation_inputs_all_in_support=bool(within_support(footprint, model).all()),
                event_window_candidate_min_C=float(values.min()), event_window_candidate_max_C=float(values.max()),
                event_sample_footprint_min_C=float(footprint.min()), event_sample_footprint_max_C=float(footprint.max()),
                event_footprint_start_sample_min=float(t[left_index]),
                event_footprint_end_sample_min=float(t[right_index]), **history_status)


def score(test, model, mod):
    prediction = predict(model, test["x"])
    outside = ~within_support(test["x"], model)
    idx, g = mod.gradient_series(test["t"], prediction, 0, len(prediction)-1)
    assert np.array_equal(idx, test["gradient_idx"])
    cross, bracket = first_crossing(test["tg"], g)
    error = None if cross is None else cross-test["source_first"]
    residual = prediction-test["y"]
    support = event_support(test, model, cross, bracket)
    assert prediction.min() >= model["y"][0] and prediction.max() <= model["y"][-1]
    assert cross is None or cross <= test["horizon"] < test["action"]
    row = dict(held_out_run=test["run"], sensor=SENSOR, radius_mm=80, method=METHOD,
               n_samples=len(prediction), rmse_C=float(np.sqrt(np.mean(residual**2))),
               mae_C=float(np.mean(np.abs(residual))), nmae=float(np.mean(np.abs(residual))/np.ptp(test["y"])),
               mapped_temperature_min_C=float(prediction.min()), mapped_temperature_max_C=float(prediction.max()),
               mapped_samples_outside_0_550_C=int(((prediction < 0.) | (prediction > 550.)).sum()),
               training_support_min_C=float(model["x"][0]), training_support_max_C=float(model["x"][-1]),
               test_candidate_min_C=float(test["x"].min()), test_candidate_max_C=float(test["x"].max()),
               samples_outside_training_support=int(outside.sum()), fraction_outside_training_support=float(outside.mean()),
               source_first_min=test["source_first"], heater_start_min=test["start"],
               observation_horizon_min=test["horizon"], recorded_action_min=test["action"],
               event_status="right_censored" if cross is None else "observed", crossing_min=cross,
               signed_error_vs_source_min=error, absolute_error_vs_source_min=None if error is None else abs(error),
               lead_vs_recorded_action_min=None if cross is None else test["action"]-cross,
               censored_delay_lower_bound_min=None if cross is not None else test["horizon"]-test["source_first"],
               **support)
    for tol in TOLS:
        status = ("within_tolerance" if abs(error) <= tol else "outside_tolerance") if error is not None else (
            "outside_tolerance" if test["horizon"]-test["source_first"] > tol else "unresolved_censored")
        row[f"timing_status_{tol:g}_min"] = status
        row[f"locally_supported_within_{tol:g}_min"] = bool(status == "within_tolerance" and
                                                           support["event_computation_inputs_all_in_support"])
        row[f"supported_within_{tol:g}_min"] = bool(row[f"locally_supported_within_{tol:g}_min"] and
                                                   support["first_event_search_history_in_support"])
    row["one_sided_5_min_status"] = ("within_window" if -5. <= error <= 0. else "outside_window") if error is not None else (
        "missed_source_deadline" if test["horizon"] >= test["source_first"] else "unresolved_censored")
    row["locally_supported_one_sided_5_min_success"] = bool(row["one_sided_5_min_status"] == "within_window" and
                                                            support["event_computation_inputs_all_in_support"])
    row["supported_one_sided_5_min_success"] = bool(row["locally_supported_one_sided_5_min_success"] and
                                                    support["first_event_search_history_in_support"])
    samples = pd.DataFrame(dict(held_out_run=test["run"], time_min=test["t"],
                               elapsed_min=test["t"]-test["start"], candidate_C=test["x"],
                               source_C=test["y"], predicted_C=prediction, residual_C=residual,
                               outside_training_support=outside))
    samples["mapped_trailing15_gradient_K_per_min"] = np.nan
    samples.loc[idx, "mapped_trailing15_gradient_K_per_min"] = g
    samples["source_trailing15_gradient_K_per_min"] = np.nan
    samples.loc[idx, "source_trailing15_gradient_K_per_min"] = test["source_g"]
    return row, samples


def verify_frozen_baseline(records, baseline, mod):
    checks = []
    assert len(baseline) == 18 and set(baseline.held_out_run) == set(records)
    for run, r in sorted(records.items()):
        rows = baseline[baseline.held_out_run == run]
        assert len(rows) == 3
        max_delta = 0.
        for column, actual in (("source_first_min", r["source_first"]), ("heater_start_min", r["start"]),
                               ("observation_horizon_min", r["horizon"]), ("recorded_action_min", r["action"]),
                               ("n_samples", len(r["x"]))):
            max_delta = max(max_delta, float(np.max(np.abs(rows[column]-actual))))
        raw_idx, raw_g = mod.gradient_series(r["t"], r["x"], 0, len(r["x"])-1)
        identity_cross, _ = first_crossing(r["t"][raw_idx], raw_g)
        identity = rows[rows.method == "identity"].iloc[0]
        rmse_delta = abs(np.sqrt(np.mean((r["x"]-r["y"])**2))-identity.rmse_C)
        event_delta = abs(identity_cross-identity.crossing_min)
        assert max(max_delta, rmse_delta, event_delta) < 1e-8
        checks.append(dict(run=run, boundary_max_difference=max_delta, identity_rmse_difference_C=rmse_delta,
                           identity_crossing_difference_min=event_delta, passed=True))
    return pd.DataFrame(checks)


def summarize(comparison):
    rows = []
    for method, group in comparison.groupby("method"):
        observed = group[group.event_status == "observed"]
        row = dict(method=method, run_units=len(group), observed=len(observed), right_censored=len(group)-len(observed),
                   median_rmse_C=group.rmse_C.median(), median_mae_C=group.mae_C.median(), median_nmae=group.nmae.median(),
                   median_abs_timing_error_observed_min=observed.absolute_error_vs_source_min.median(),
                   min_signed_error_observed_min=observed.signed_error_vs_source_min.min(),
                   max_signed_error_observed_min=observed.signed_error_vs_source_min.max(),
                   runs_outside_0_550_C=int((group.mapped_samples_outside_0_550_C > 0).sum()))
        for tol in TOLS:
            for status in ("within_tolerance", "outside_tolerance", "unresolved_censored"):
                row[f"n_{status}_{tol:g}_min"] = int((group[f"timing_status_{tol:g}_min"] == status).sum())
        for status in ("within_window", "outside_window", "missed_source_deadline", "unresolved_censored"):
            row[f"n_one_sided_5_min_{status}"] = int((group.one_sided_5_min_status == status).sum())
        if method == METHOD:
            row["events_with_supported_sample_footprint"] = int(group.event_computation_inputs_all_in_support.fillna(False).sum())
            row["first_event_search_histories_in_support"] = int(group.first_event_search_history_in_support.sum())
            row["locally_supported_one_sided_5_min_successes"] = int(group.locally_supported_one_sided_5_min_success.sum())
            row["supported_one_sided_5_min_successes"] = int(group.supported_one_sided_5_min_success.sum())
            for tol in TOLS:
                row[f"locally_supported_within_{tol:g}_min"] = int(group[f"locally_supported_within_{tol:g}_min"].sum())
                row[f"supported_within_{tol:g}_min"] = int(group[f"supported_within_{tol:g}_min"].sum())
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    started = time.perf_counter()
    unit = tiny_analytic_check()
    output = HERE / "outputs"
    models = output / "fold_models"
    models.mkdir(parents=True, exist_ok=True)
    mod = canonical_module()
    records, provenance = load_runs(mod)
    frozen_hash = sha_file(BASELINE)
    baseline = pd.read_csv(BASELINE)
    baseline = baseline[baseline.sensor == SENSOR].copy()
    baseline_checks = verify_frozen_baseline(records, baseline, mod)
    outcomes, parameters, sample_tables, weights_rows = [], [], [], []
    for held, test in sorted(records.items()):
        training = [r for run, r in sorted(records.items()) if run != held]
        training_ids = [r["run"] for r in training]
        assert held not in training_ids and len(training_ids) == 5
        tick = time.perf_counter()
        model = fit_model(training)
        fit_seconds = time.perf_counter()-tick
        knot_table = pd.DataFrame(dict(candidate_knot_C=model["x"], fitted_source_C=model["y"],
                                       aggregated_source_mean_C=model["raw_y_mean"],
                                       aggregated_sample_weight=model["weights"],
                                       exact_x_duplicate_count=model["counts"]))
        model_path = models / f"held_out_{held}_knots.csv"
        knot_table.to_csv(model_path, index=False)
        model_hash = sha_file(model_path)
        tick = time.perf_counter()
        row, samples = score(test, model, mod)
        replay_seconds = time.perf_counter()-tick
        row.update(training_runs=";".join(map(str, training_ids)), model_sha256=model_hash,
                   n_training_unique_knots=len(model["x"]), n_pava_blocks=model["n_blocks"],
                   fit_runtime_seconds=fit_seconds, replay_runtime_seconds=replay_seconds)
        outcomes.append(row)
        sample_tables.append(samples)
        parameters.append(dict(held_out_run=held, training_runs=row["training_runs"],
                               training_samples=sum(len(r["x"]) for r in training),
                               unique_candidate_knots=len(model["x"]), pava_blocks=model["n_blocks"],
                               training_equal_run_mse_C2=model["loss"],
                               minimum_fitted_knot_difference_C=float(np.min(np.diff(model["y"]))),
                               monotonicity_passed=bool(np.all(np.diff(model["y"]) >= 0)),
                               training_weight_sum=float(model["weights"].sum()),
                               duplicate_loss_identity_error_C2=model["duplicate_loss_identity_error"],
                               model_file=str(model_path.relative_to(HERE)), model_sha256=model_hash,
                               fit_runtime_seconds=fit_seconds, replay_runtime_seconds=replay_seconds))
        weights_rows.extend(dict(held_out_run=held, training_run=r["run"], n_samples=len(r["x"]),
                                 individual_sample_weight=1./(5*len(r["x"])), total_run_weight=.2) for r in training)
        print(f"Completed held-out Test {held}: {row['event_status']}", flush=True)
    result = pd.DataFrame(outcomes)
    comparison = pd.concat([baseline, result], ignore_index=True, sort=False)
    summary = summarize(comparison)
    tables = dict(source_provenance=provenance, baseline_reconstruction_checks=baseline_checks,
                  held_out_results=result, fold_parameters=pd.DataFrame(parameters),
                  training_run_weights=pd.DataFrame(weights_rows), held_out_samples=pd.concat(sample_tables, ignore_index=True),
                  frozen_baseline_comparison=comparison, method_summary=summary)
    for name, frame in tables.items():
        frame.to_csv(output / f"{name}.csv", index=False)
    assert sha_file(BASELINE) == frozen_hash
    manifest = dict(python=sys.version, numpy=np.__version__, pandas=pd.__version__, scipy=scipy.__version__,
                    platform=platform.platform(), run_units=6, channel=SENSOR,
                    source_hashes_verified=6, weighted_duplicate_analytic_check=unit,
                    script_sha256=sha_file(__file__), protocol_sha256=sha_file(HERE / "PROTOCOL.md"),
                    canonical_script_sha256=sha_file(CANON), frozen_baseline_csv_sha256=frozen_hash,
                    baseline_csv_unchanged=True, baseline_refitted=False,
                    model_family="equal-run weighted isotonic/PAVA; linear interpolation; fixed endpoint clamp",
                    fit_used_heldout_reference=False, strict_preaction=True,
                    family_selected_after_prior_campaign_results=True, external_validation=False,
                    support_amendment_utc="2026-09-26T21:58:41Z",
                    support_amended_before_any_isotonic_heldout_outcome_inspection=True,
                    initial_uninspected_compute_superseded=True,
                    elapsed_seconds=time.perf_counter()-started,
                    model_sha256={p["model_file"]: p["model_sha256"] for p in parameters},
                    output_sha256={f"{name}.csv": sha_file(output / f"{name}.csv") for name in tables})
    (output / "reproduction_record.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(summary.to_string(index=False))
    print("PASS: six source hashes/boundaries, six separated monotone folds, fixed support policy; no baseline writes.")


if __name__ == "__main__":
    main()
