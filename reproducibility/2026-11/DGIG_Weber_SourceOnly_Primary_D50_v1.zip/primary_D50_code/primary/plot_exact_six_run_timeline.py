#!/usr/bin/env python3
"""Rebuild the paper's six-run event timeline from unrounded original replay CSVs.

Input files are created by reproduce_weber_operational.py from original Weber V2
Measurements. This script does not refit models, alter results, or infer actuator
responses under a physically substituted sensor. Uses only recorded/reconstructed
source-clock facts; logged action is shown separately.
"""
import argparse
from pathlib import Path
import csv
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

COL_CAND='candidate_first_crossing_after_heater_on_min'
COL_SRC='source_first_crossing_after_heater_on_min'
COL_ACT='heating_duration_min'

def rows(path):
    with Path(path).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))

def make(primary,source,out):
    points={int(r['run']):r for r in rows(primary) if r['sensor']=='TR404-085d'}
    controls={int(r['run']):r for r in rows(source)}
    assert set(points)==set(controls)==set(range(4,10)), 'Expected source campaign Tests 4-9'
    rr=list(range(4,10))
    candidate=np.array([float(points[r][COL_CAND]) for r in rr])
    source_t=np.array([float(controls[r][COL_SRC]) for r in rr])
    off=np.array([float(controls[r][COL_ACT]) for r in rr])
    assert np.all(candidate<source_t) and np.all(source_t<off)
    assert np.allclose(off-candidate,[float(points[r]['lead_vs_action_min']) for r in rr],rtol=0,atol=1e-10)
    assert math.isclose(min(off-candidate),23.587037889,abs_tol=1e-8)
    assert math.isclose(max(off-candidate),31.118833872,abs_tol=1e-8)

    plt.rcParams.update({'pdf.fonttype':42,'ps.fonttype':42,'font.family':'DejaVu Sans',
            'font.size':8.3,'axes.labelsize':8.5,'xtick.labelsize':8,'ytick.labelsize':8,'axes.linewidth':0.65,
            'savefig.pad_inches':0.07})
    fig,ax=plt.subplots(figsize=(6.0,2.85),dpi=200)
    y=np.arange(6)[::-1]
    ax.hlines(y,candidate,off,color='#C4C6C9',lw=1.7,zorder=1)
    ax.scatter(candidate,y,s=46,c='#176CA5',marker='o',zorder=4,label='80-mm candidate: first crossing')
    ax.scatter(source_t,y,s=44,c='#EA8C22',marker='s',zorder=5,label='95-mm source: first crossing')
    ax.scatter(off,y,s=38,c='#289B4B',marker='D',zorder=6,label='Recorded heater-off command')
    for i,run in enumerate(rr):
        ax.text(89.1,y[i],f'{off[i]-candidate[i]:.1f} min',ha='left',va='center',fontsize=8.1,color='#242424')
    ax.text(89.1,5.65,'Lead to logged off',ha='left',va='bottom',fontsize=7.6,fontweight='bold')
    ax.set_yticks(y, [f'Test {r}' + (' (D50)' if r in [5,9] else '') for r in rr])
    ax.set_xlim(44,102)
    ax.set_ylim(-0.6,5.9)
    ax.set_xticks(range(45,90,5))
    ax.grid(axis='x',color='#EAEAEA',lw=.45)
    ax.set_axisbelow(True)
    ax.set_xlabel('Minutes since sustained heater-on')
    for spine in ('right','top'):ax.spines[spine].set_visible(False)
    ax.tick_params(axis='both',length=2.5,width=.65)
    fig.legend(loc='upper center',ncol=3,fontsize=7.3,frameon=False,
               bbox_to_anchor=(.5,.97),columnspacing=1.05,handletextpad=.35)
    fig.text(.013,.015,'Unrounded native replay ledger; no substitute-controlled shutdown.',fontsize=7.3,color='#484848')
    fig.subplots_adjust(left=.17,right=.97,top=.81,bottom=.23)
    out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(out,format='pdf',bbox_inches=None)
    plt.close(fig)
    return list(zip(rr,candidate,source_t,off))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--primary',type=Path,required=True)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    for run,c,s,off in make(a.primary,a.source,a.out):
        print(f'Test {run}: candidate={c:.9f} source={s:.9f} command={off:.9f} lead={off-c:.9f}')
