# Primary Weber replay and D50 numerical workflow (public source snapshot)

Follow the source-data acquisition and limits in `../README_START_HERE.md`.

1. Download official Weber V2 source from https://doi.org/10.17632/3pp86gdvh4.2.
2. Run `python prepare_from_weber_v2.py --upstream /PATH/TO/UNMODIFIED/WEBER_V2 --output /PATH/TO/NEW_WORKTREE`.
3. Run `python NEW_WORKTREE/primary/reproduce_weber_operational.py --source-zips NEW_WORKTREE/primary/source_zips --output NEW_PRIMARY_RESULTS`.
4. Run `python verify_primary_outputs.py --results NEW_PRIMARY_RESULTS` from this source directory (compares the three frozen derived output files bytewise).
5. Run `primary/plot_exact_six_run_timeline.py` as documented in its command-line help (optional figure reconstruction).
6. For D50, enter `NEW_WORKTREE/d50/DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/WRITER2_COLLABORATION_20260927/BLOCKED_LOW_CAPACITY_20260927` and execute:

```
python run_blocked_low_capacity.py --self-test
python run_blocked_low_capacity.py --prepare --output d50_fresh --protocol-sha256 0e39248efe6e627280f7585cebec8ffdac2d545f9a47055a2e8673cf3ef68559
```

Use the *newly printed* selection SHA-256 for the `--evaluate` call with the same protocol; then run `python independent_audit.py --run-real --output d50_fresh`. These numerical optimizations may be environment-sensitive and should not be represented as a fresh PASS unless completed.

The code is public to inspect, but an OSI reuse license has not been granted. No raw measurements or historical PLC code are included. The project uses a six-run recorded-trace experiment, not a new physical intervention.
