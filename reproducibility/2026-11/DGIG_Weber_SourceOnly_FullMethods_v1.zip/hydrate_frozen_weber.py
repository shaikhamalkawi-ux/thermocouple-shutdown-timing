#!/usr/bin/env python3
"""Offline Weber-V2 source verification and exact original compact-container reconstruction.

Does not download, modify, or redistribute published upstream data. Creates a NEW
local working directory only after all nine source files pass known hashes. Existing
paths are never overwritten. All input measurements remain third-party evidence.
"""
from __future__ import annotations
import argparse, hashlib, json, shutil, zipfile, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent

def sha256(p: Path):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):h.update(chunk)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--upstream', required=True, type=Path, help='Extracted unmodified Weber Version-2 dataset')
    p.add_argument('--output', required=True, type=Path, help='New local directory; MUST NOT exist')
    x=p.parse_args();upstream=x.upstream.resolve();dest=x.output.resolve()
    if not upstream.is_dir():raise SystemExit('ERROR: upstream directory absent')
    if dest.exists():raise SystemExit('ERROR: destination already exists; existing work must be preserved')
    if dest == HERE or HERE.is_relative_to(dest): raise SystemExit('ERROR: destination encompasses package')
    metadata=json.loads((HERE/'SOURCE_ZIP_CONTAINER_METADATA.json').read_text())
    admission=json.loads((HERE/'primary_D50_code/EXPECTED_UPSTREAM_SOURCE_FILES.json').read_text())['members']
    located={}
    for row in admission:
        relative=Path(row['relative_source_path'])
        matches=[p for p in upstream.rglob(relative.name)
                 if p.is_file() and p.parent.name==relative.parent.name]
        if len(matches)!=1:raise SystemExit(f"ERROR: run {row['run']} expected exactly one {relative.parent.name}/{relative.name}; found {len(matches)}")
        f=matches[0]
        if f.stat().st_size!=row['bytes'] or sha256(f)!=row['sha256']:
            raise SystemExit(f"ERROR: run {row['run']} does not match admitted Weber V2 SHA256/length")
        located[row['relative_source_path']]=f
    if len(located)!=9:raise SystemExit('ERROR: expected exactly nine source files')
    # All upstream file hashes pass before we create any output.
    dest.mkdir(parents=True)
    try:
        module_source={}
        for folder in ('modules','primary_D50_code'):
            shutil.copytree(HERE/folder,dest/folder)
        for name in ('SOURCE_ZIP_CONTAINER_METADATA.json','EXCLUDED_UPSTREAM_CONTAINER_INDEX.json'):
            shutil.copy2(HERE/name,dest/name)
        srczips=dest/'frozen_compact_source_zips';srczips.mkdir()
        for name, spec in metadata.items():
            output=srczips/name
            with zipfile.ZipFile(output,'w') as z:
                for item in spec['members']:
                    rel=item['filename'];fname=located.get(rel)
                    if fname is None: raise ValueError(f'unknown source member {rel}')
                    raw=fname.read_bytes()
                    if len(raw)!=item['uncompressed_bytes'] or hashlib.sha256(raw).hexdigest()!=item['sha256']:
                        raise ValueError('source bytes changed during hydration')
                    zi=zipfile.ZipInfo(rel,tuple(item['date_time']))
                    zi.create_system=item['create_system']
                    zi.external_attr=item['external_attr']
                    zi.compress_type=item['compress_type']
                    zi.flag_bits=item['flag_bits']
                    z.writestr(zi,raw,compress_type=zi.compress_type,compresslevel=9)
            actual=sha256(output)
            if actual!=spec['source_container_sha256']:
                raise ValueError(f'Exact frozen ZIP failed {name}: {actual}')
            module_source[name]=actual
        # Place only source containers; all original scientific script/result bytes stay unchanged.
        location_by_module={
          'event_contract':Path('DGIG_EventContract_20261010/inputs/compact'),
          'exact_certificates':Path('DGIG_Novelty_FixedKnot_Certificates_20261010/DGIG_EventContract_20261010/inputs/compact'),
          'raw_error':Path('DGIG_R18R3_RawError_Counterexamples/inputs'),
        }
        for module,rel in location_by_module.items():
            target=dest/'modules'/module/rel;target.mkdir(exist_ok=True,parents=True)
            for name in ('DGIG_WEBER_CORE_PRIMARY_A_tests4_6.zip','DGIG_WEBER_CORE_PRIMARY_B_tests7_9.zip'):
                shutil.copy2(srczips/name,target/name)
        # Primary/D50 EP7 code tree, using only source-verified container bytes.
        prepared=dest/'primary_D50_worktree'
        prepared.mkdir()
        for dirname in ('primary','d50','expected'):
            shutil.copytree(dest/'primary_D50_code'/dirname,prepared/dirname)
        (prepared/'primary'/'source_zips').mkdir(exist_ok=True)
        for name in metadata:
            shutil.copy2(srczips/name,prepared/'primary'/'source_zips'/name)
        source_d50=prepared/'d50'/'DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/R2E_REPRO_CLEAN_20260920/source_zips'
        source_d50.mkdir(parents=True,exist_ok=True)
        for name in ('DGIG_WEBER_CORE_PRIMARY_A_tests4_6.zip','DGIG_WEBER_CORE_PRIMARY_B_tests7_9.zip'):
            shutil.copy2(srczips/name,source_d50/name)
        receipt={'status':'PASS','source':'Weber Mendeley Data Version 2',
          'doi':'10.17632/3pp86gdvh4.2','nine_original_csv_sha256_verified':True,
          'three_frozen_zip_containers_byte_identical':True,
          'zip_sha256':module_source,
          'claim_scope':'Local rehydration only; no new physical experiment or measurements'}
        (dest/'SOURCE_HYDRATION_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    except BaseException:
        shutil.rmtree(dest,ignore_errors=True)
        raise
    print('PASS: 9/9 raw Weber CSVs and 3/3 original compact ZIPs; original code/result bytes retained')
    print(dest)

if __name__=='__main__':main()
