#!/usr/bin/env python3
"""Construct hypothetical raw-error witnesses; never modifies source measurements.
The LP has a fixed separator and is NOT a global first-event robustness optimization.
"""
from __future__ import annotations
import argparse, csv, hashlib, io, json, platform, sys, zipfile
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, csr_matrix, vstack, hstack, eye

HASHES = {4:'985f4452c04e495c6f07227d3ce238975d596caa5a9ea04f8e52fb08645e1d68',5:'3318140e2de217cce5c407f862b238385f5872e46a11710ef8fed260cce22425',6:'cbbf5b9846c2bd0945cebf6517f8a9b003f7d4b5aaf54c1de6bc8dc8de1a629b',7:'19b88ec506a3e2407ca4bb40adeb8247d2467f4913b0a62de39afede45254a6b',8:'1cbfdd865524224959a0d28836528c79dc7228e37e725e9e4be7b32f4ea799ef',9:'050bd98e110121a9063e7c361f8a7cbbedad55fea6eed42c05e2e69a22ccbe2e'}
W=15.0; THETA=1.0; GUARD=0.0001

def load(folder: Path):
    runs={}
    for p in sorted(folder.glob('*PRIMARY*.zip')):
        with zipfile.ZipFile(p) as z:
            for name in z.namelist():
                if not name.endswith('/MeasurementData.CSV'):continue
                rid=int(Path(name).parent.name.split('_')[0]);raw=z.read(name)
                if hashlib.sha256(raw).hexdigest()!=HASHES[rid]: raise ValueError('Wrong source hash')
                rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')),delimiter=';'))
                a=np.array([[float(r[k].replace(',','.')) for k in ['Time since Start [min]','TR404-085d','TR404-108e','Heater_AO']] for r in rows])
                on=a[:,3]>4.5;beg=np.flatnonzero(on & np.r_[True,~on[:-1]]);end=np.flatnonzero(on & np.r_[~on[1:],True])+1
                m=int(np.argmax(end-beg));s,e=int(beg[m]),int(end[m]);q=a[s:e]
                if not np.isfinite(q).all() or not np.all(np.diff(q[:,0])>0):raise ValueError('Invalid source')
                runs[rid]={'t':q[:,0], 'x':q[:,1], 'y':q[:,2], 'start_row':s,'off_row':e,'member':name,'action':float(a[e,0]),'source_archive':p.name}
    if sorted(runs)!=list(range(4,10)):raise ValueError('Six-run universe changed')
    return runs

def operator(t):
    ids=np.flatnonzero(t>=t[0]+W);rr=[];cc=[];vv=[]
    for k,i in enumerate(ids):
        u=t[i]-W;j=int(np.searchsorted(t,u,side='right')-1)
        if j<0:raise ValueError('Incomplete lag history')
        rr.append(k);cc.append(i);vv.append(1/W)
        if t[j]==u:rr.append(k);cc.append(j);vv.append(-1/W)
        else:
            b=(u-t[j])/(t[j+1]-t[j]);rr +=[k,k];cc +=[j,j+1];vv +=[-(1-b)/W,-b/W]
    return ids,coo_matrix((vv,(rr,cc)),shape=(len(ids),len(t))).tocsr()

def first(t,g):
    a=np.flatnonzero((g[:-1]>=THETA)&(g[1:]<THETA))
    if len(a)==0:return None
    j=int(a[0]);return float(t[j]+(THETA-g[j])*(t[j+1]-t[j])/(g[j+1]-g[j]))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if any(args.output.iterdir()):raise ValueError('Use a new empty output directory')
    sep={int(r['run']):r for r in csv.DictReader((args.inputs/'primary_order_certificates.csv').open())}
    summary=[]
    for rid,r in sorted(load(args.inputs).items()):
        t,x,y=r['t'],r['x'],r['y'];ids,D=operator(t);tt=t[ids];gx=D@x;gy=D@y
        k=int(sep[rid]['separator_gradient_index']);n=int(ids[k])+1
        if abs(t[ids[k]]-float(sep[rid]['separator_native_min']))>1e-10:raise ValueError('Separator mismatch')
        # Only source row 0 and k enter the contract. Other source errors are zero.
        source_cols=np.union1d(D.getrow(0).indices,D.getrow(k).indices)
        Ds=D[[0,k],:][:,source_cols];nc=n+len(source_cols)
        C=vstack([hstack([-D[:k+1,:n],csr_matrix((k+1,len(source_cols)))]),hstack([csr_matrix((1,n)),-Ds[0,:]]),hstack([csr_matrix((1,n)),Ds[1,:]])]).tocsr()
        rhs=np.r_[gx[:k+1]-THETA-GUARD,gy[0]-THETA-GUARD,THETA-GUARD-gy[k]]
        A=vstack([hstack([C,csr_matrix((C.shape[0],1))]),hstack([eye(nc),csr_matrix(-np.ones((nc,1)))]),hstack([-eye(nc),csr_matrix(-np.ones((nc,1)))])],format='csr')
        b=np.r_[rhs,np.zeros(2*nc)];c=np.r_[np.zeros(nc),1.0]
        sol=linprog(c,A_ub=A,b_ub=b,bounds=[(None,None)]*nc+[(0,None)],method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
        if not sol.success:raise RuntimeError(f'Test {rid}: {sol.message}')
        ea=np.zeros(len(t));es=np.zeros(len(t));ea[:n]=np.round(sol.x[:n],12);es[source_cols]=np.round(sol.x[n:nc],12)
        ga=D@(x+ea);gs=D@(y+es);fa=first(tt,ga);fs=first(tt,gs)
        actual=max(float(np.max(np.abs(ea))),float(np.max(np.abs(es))))
        if not (min(ga[:k+1])>THETA and gs[0]>THETA and gs[k]<THETA and fs is not None and (fa is None or fs<fa)):raise AssertionError('Numerical reversal not verified')
        fn=f'raw_error_witness_test{rid}.csv'
        with (args.output/fn).open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['preaction_row_index','candidate_error_K','source_error_K'])
            for i in range(len(t)):w.writerow([i,f'{ea[i]:.12f}',f'{es[i]:.12f}'])
        rec={'run':rid,'source_sha256':HASHES[rid],'source_member':r['member'],'raw_preaction_samples':len(t),'separator_preaction_index':int(ids[k]),'separator_gradient_index':k,'separator_elapsed_min':float(t[ids[k]]-t[0]),'lp_target_guard_K_per_min':GUARD,'numeric_fixed_separator_optimum_K':float(sol.fun),'rounded_witness_max_error_K':actual,'candidate_min_prefix_gradient':float(min(ga[:k+1])),'source_initial_gradient':float(gs[0]),'source_separator_gradient':float(gs[k]),'nominal_candidate_event_elapsed_min':first(tt,gx)-t[0],'nominal_source_event_elapsed_min':first(tt,gy)-t[0],'perturbed_candidate_event_elapsed_min':None if fa is None else fa-t[0],'perturbed_source_event_elapsed_min':fs-t[0],'source_before_candidate_numeric':True,'witness_file':fn,'solver_status':sol.message,'satisfies_1p60_box':actual<=1.60,'satisfies_2p28_box':actual<=2.28,'satisfies_4p57_box':actual<=4.57}
        summary.append(rec);print(json.dumps(rec),flush=True)
    (args.output/'NUMERICAL_WITNESS_REGISTER.json').write_text(json.dumps({'status':'NUMERIC_PASS_PENDING_EXACT_CHECK','scope':'Hypothetical adversarial raw-error boxes on fixed recorded traces; no probability or physical sensor-noise claim. Fixed-separator LP optima are not global reversal radii.','runs':summary},indent=2)+'\n')
    (args.output/'ENVIRONMENT.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'platform':platform.platform()},indent=2)+'\n')
if __name__=='__main__':main()
