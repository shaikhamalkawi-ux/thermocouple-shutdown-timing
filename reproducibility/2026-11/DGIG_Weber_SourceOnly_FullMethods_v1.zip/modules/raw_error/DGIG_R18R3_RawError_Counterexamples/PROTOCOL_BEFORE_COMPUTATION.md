# Protocol fixed before computation — constructive raw-error reversal test

Date: 2026-11-06. Status: new bounded, retrospective numerical investigation; not a new physical experiment.

## Question
R18 proves candidate-first ordering for a common 1.60 K per-sample raw-error box. A failed sufficient certificate above that box is not a reversal. Test whether explicit raw-channel perturbations can reverse the event ordering on the SAME six traces.

## Frozen choices
- Original hash-checked Weber Tests 4–9, nearest alternative TR404-085d and source TR404-108e.
- Same longest sustained heater-on interval and strict pre-action horizon, 15-min finite difference, threshold 1 K/min, native lag interpolation and linearly interpolated gradient crossings.
- The separator in each run is fixed to that already published by R18's native-grid certificate. No separator search in this extension.
- Raw errors e_a and e_s are additive at the original sample times, independently selectable and bounded in absolute value by a common delta. No probability, zero-mean, smoothness or calibrated correlation model is asserted.
- Guard gamma = 0.0001 K/min, fixed for all runs. It is a computational strictness guard, not a physical acceptance tolerance.

## Reversed-sign contract
Keep the perturbed candidate gradient >= 1 + gamma at EVERY eligible native time from the first full window through the frozen separator. Keep the source initial gradient >= 1 + gamma, and put its gradient at the separator <= 1 - gamma. This suffices for a source first crossing before the separator while the candidate has not crossed. The later candidate may cross or remain censored.

Solve a sparse LP minimizing the common raw-error amplitude for these fixed sufficient constraints. The numeric optimum is NOT the exact minimal amplitude for all possible first-event reversals. It only constructs a feasible upper bound. Existing R18 radii remain certified lower bounds (strict inequalities).

## Checks and reporting
- Round each proposed raw-error witness to 12 decimal places, retain all errors and source hashes, and recompute directly from the original source decimals with Fraction arithmetic.
- Verify the error amplitudes, every prefix sign, source arming, separator sign, and actual first-event ordering. Do not rely on solver status alone.
- Report checks against 1.60, 2.28 and 4.57 K without treating published accuracy bands as evidence that the hypothetical errors occur. Different source temperature ranges are not collapsed into a calibrated common error model.
- Record solver/runtime errors and infeasibility honestly. Do not infer failed event preservation merely from NOT_CERTIFIED.
- Preserve all prior scientific results. Integrate only verified constructive evidence, not a claim of general operational unreliability or new physical measurement.
