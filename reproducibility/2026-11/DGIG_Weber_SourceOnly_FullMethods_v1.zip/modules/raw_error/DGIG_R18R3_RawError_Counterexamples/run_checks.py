#!/usr/bin/env python3
"""Verify shipped raw-error witnesses; --reconstruct additionally reruns the sparse LP."""
from __future__ import annotations
import argparse,json,subprocess,sys,hashlib
from pathlib import Path

def run(cmd,root,log):
    with log.open('x') as f:
        p=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=False)
    if p.returncode:raise SystemExit(f'FAILED: {log.name}; inspect log (exit {p.returncode})')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--reconstruct',action='store_true');a=ap.parse_args()
    root=Path(__file__).resolve().parent;out=a.output.resolve()
    if out==root or root in out.parents:raise SystemExit('Output must be outside the source package')
    out.mkdir(parents=True,exist_ok=False)
    run([sys.executable,'-m','unittest','-v','test_constructive'],root,out/'tests.log')
    run([sys.executable,'verify_raw_witnesses.py','--inputs',str(root/'inputs'),'--witnesses',str(root/'results/witnesses'),'--output',str(out/'EXACT_RAW_REVERSAL_VERIFICATION.json')],root,out/'exact.log')
    expected=(root/'results/EXACT_RAW_REVERSAL_VERIFICATION.json').read_bytes();got=(out/'EXACT_RAW_REVERSAL_VERIFICATION.json').read_bytes()
    if got!=expected:raise SystemExit('Exact witness report differs from shipped expected output')
    report={'status':'PASS','tests':14,'exact_report_byte_identical':True,'exact_report_sha256':hashlib.sha256(got).hexdigest(),'source_files_verified':6,'original_1p60K_guarantees_recovered':6,'raw_error_reversals_verified':6,'reconstruction_executed':a.reconstruct}
    if a.reconstruct:
        run([sys.executable,'construct_reversal.py','--inputs',str(root/'inputs'),'--output',str(out/'regenerated_witnesses')],root,out/'construct.log')
        run([sys.executable,'verify_raw_witnesses.py','--inputs',str(root/'inputs'),'--witnesses',str(out/'regenerated_witnesses'),'--output',str(out/'REGENERATED_EXACT_REPORT.json')],root,out/'regenerated_exact.log')
        new=json.loads((out/'REGENERATED_EXACT_REPORT.json').read_text())
        report['regenerated_witness_exact_verification_pass']=new['status']=='PASS' and new['all_within_2p28_K']
        report['regenerated_witnesses_byte_identical']=all((p.read_bytes()==(root/'results/witnesses'/p.name).read_bytes()) for p in (out/'regenerated_witnesses').glob('raw_error_witness_test*.csv'))
    (out/'RUN_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
