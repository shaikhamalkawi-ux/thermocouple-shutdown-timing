# DGIG R18R3 — constructive raw-error counterexamples

Private scientific author-review candidate. This module adds an explicit counterexample search to the R18/R18R2 sufficient ordering analysis. It does not change the frozen measurements, original replay, calibrated models or exact fixed-basis LP certificate.

## One-command verification (Python standard library only)

```bash
python run_checks.py --output ../fresh_exact_check
```

Use a new output directory outside this package. The run executes 14 tests and checks the six shipped raw-error sequences directly against the original source decimals with `fractions.Fraction`. It verifies all 19,703 candidate prefix signs, source arming and crossing, 59,040 raw error values, sampled event ordering, interpolated first-event ordering, and all six unchanged 1.60-K sufficient guarantees. The regenerated exact report must be byte-identical to the expected report.

## Optional numerical construction

```bash
python run_checks.py --output ../fresh_lp_check --reconstruct
```

This additionally requires NumPy and SciPy; see results/witnesses/ENVIRONMENT.json for the actually executed versions. The LP uses the SAME separators as R18, a fixed 0.0001 K/min numerical sign guard, and no calibration refit. Solutions may be nonunique across solver versions; an independently verified feasible witness matters, not bitwise agreement with one numerical optimizer. The serialized delivered witnesses can always be checked without a solver.

## Reading the results

- `inputs/primary_order_certificates.csv`: frozen prior lower-certificate locations and values.
- `results/witnesses/raw_error_witness_test{4..9}.csv`: hypothetical additive errors ONLY, indexed against the strict pre-action raw sample sequence. These are not measured sensor errors.
- `results/EXACT_RAW_REVERSAL_VERIFICATION.json`: exact amplitudes, margins and events, source/witness hashes, and first-below sample indices.
- `results/witnesses/NUMERICAL_WITNESS_REGISTER.json`: numerical construction diagnostics, not exact optimizer certificates.
- `PROTOCOL_BEFORE_COMPUTATION.md`: fixed choices and scope established before construction.

The source crosses below threshold at the separator sample; the alternative remains above it through that sample and crosses later. Each witness has amplitude below 2.28 K. The source-first reversals are examples in an unrestricted sample-error box. They do not say that these rapidly varying errors occur in the apparatus, that a constant sensor bias would change a finite-difference event, or that a physical shutdown was reversed. No calibrated probability, noise covariance, smoothness bound or globally minimal reversal radius is supplied.

## Relation to the earlier work

The earlier 1.60-K universal raw-error guarantee remains unchanged. The approximately 0.062405-K post-calibration sign boundary concerns a DIFFERENT signal space and fixed reference deadlines; do not compare it as if it were a raw-sensor accuracy specification. A failed sufficient check is inconclusive. A separate verified counterexample establishes possible failure only in its stated mathematical error set.

The source Weber measurements are attributed to Weber et al., Mendeley Data version 2, DOI 10.17632/3pp86gdvh4.2 (CC BY 4.0). Compact input archives are unchanged from the predecessor package. No PCM raw data, private correspondence, credentials or author photos are included. Code licence and public archival DOI remain author decisions; no new public licence is granted by this private candidate.
