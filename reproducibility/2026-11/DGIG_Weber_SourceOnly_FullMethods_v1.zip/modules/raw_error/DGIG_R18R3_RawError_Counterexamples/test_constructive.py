import csv, tempfile, unittest
from pathlib import Path
from fractions import Fraction as F
import verify_raw_witnesses as v

class WitnessChecks(unittest.TestCase):
    def setUp(self):
        self.t=list(map(F,[0,15,30,45])); self.x=list(map(F,[0,30,42,54]));self.y=list(map(F,[0,36,54,66]));self.off=F(60)
        self.rows=[{'preaction_row_index':str(i),'candidate_error_K':str(e),'source_error_K':str(s)} for i,(e,s) in enumerate(zip([0,0,4,0],[0,0,-4,0]))]
    def case(self,rows=None,sep=2):return v.verify_case(self.t,self.x,self.y,self.off,self.rows if rows is None else rows,sep)
    def test_valid_counterexample(self):self.assertTrue(self.case()['source_first_order_exact'])
    def test_exact_amplitude(self):self.assertEqual(self.case()['max_abs_raw_error_K']['numerator'],'4')
    def test_original_order(self):
        _,tt,g=v.grad(self.t,self.x);_,_,h=v.grad(self.t,self.y);self.assertLess(v.event(tt,g),v.event(tt,h))
    def test_zero_errors_rejected(self):
        for q in self.rows:q['candidate_error_K']=q['source_error_K']='0'
        with self.assertRaises(ValueError):self.case()
    def test_candidate_equality_rejected(self):
        self.rows[2]['candidate_error_K']='3'
        with self.assertRaises(ValueError):self.case()
    def test_source_equality_rejected(self):
        self.rows[2]['source_error_K']='-3'
        with self.assertRaises(ValueError):self.case()
    def test_duplicate_row_rejected(self):
        self.rows[2]['preaction_row_index']='1'
        with self.assertRaises(ValueError):self.case()
    def test_missing_row_rejected(self):
        with self.assertRaises(ValueError):self.case(self.rows[:-1])
    def test_bad_separator_rejected(self):
        with self.assertRaises(ValueError):self.case(sep=0)
    def test_reversed_clock_rejected(self):
        self.t=[F(0),F(30),F(15),F(45)]
        with self.assertRaises(ValueError):self.case()
    def test_offset_invariance_exact(self):
        _,_,a=v.grad(self.t,self.x);_,_,b=v.grad(self.t,[q+F(100) for q in self.x]);self.assertEqual(a,b)
    def test_post_horizon_separator_rejected(self):
        self.off=F(30)
        with self.assertRaises(ValueError):self.case()
    def test_sampled_order_not_only_interpolation(self):
        a=[x+v.number(r['candidate_error_K']) for x,r in zip(self.x,self.rows)];s=[y+v.number(r['source_error_K']) for y,r in zip(self.y,self.rows)]
        _,tt,ga=v.grad(self.t,a);_,_,gs=v.grad(self.t,s)
        ia=next(i for i,g in enumerate(ga) if g<1);iss=next(i for i,g in enumerate(gs) if g<1);self.assertLess(iss,ia)
    def test_csv_decimal_not_binary_float(self):self.assertEqual(v.number('0.100000000001'),F(100000000001,10**12))

if __name__=='__main__':unittest.main(verbosity=2)
