#!/usr/bin/env python3
"""Separate exact verifier: standard-library only, no import from LP constructor.
Checks serialized perturbations against native source decimals and all required signs.
"""
from __future__ import annotations
import argparse,bisect,csv,hashlib,io,json,zipfile
from decimal import Decimal,localcontext
from fractions import Fraction as F
from pathlib import Path
HASHES={4:'985f4452c04e495c6f07227d3ce238975d596caa5a9ea04f8e52fb08645e1d68',5:'3318140e2de217cce5c407f862b238385f5872e46a11710ef8fed260cce22425',6:'cbbf5b9846c2bd0945cebf6517f8a9b003f7d4b5aaf54c1de6bc8dc8de1a629b',7:'19b88ec506a3e2407ca4bb40adeb8247d2467f4913b0a62de39afede45254a6b',8:'1cbfdd865524224959a0d28836528c79dc7228e37e725e9e4be7b32f4ea799ef',9:'050bd98e110121a9063e7c361f8a7cbbedad55fea6eed42c05e2e69a22ccbe2e'}

def require(v,msg):
    if not v:raise ValueError(msg)
def number(s):return F(str(s).strip().replace(',','.'))
def serial(x):
    if x is None:return None
    with localcontext() as c:
        c.prec=42;d=str(Decimal(x.numerator)/Decimal(x.denominator))
    return {'numerator':str(x.numerator),'denominator':str(x.denominator),'decimal':d}
def source_runs(folder):
    out={}
    for p in sorted(folder.glob('*PRIMARY*.zip')):
        with zipfile.ZipFile(p) as z:
            for name in z.namelist():
                if not name.endswith('/MeasurementData.CSV'):continue
                r=int(Path(name).parent.name.split('_')[0]);raw=z.read(name)
                require(hashlib.sha256(raw).hexdigest()==HASHES[r],'Source hash mismatch')
                data=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')),delimiter=';'))
                spans=[];i=0
                while i<len(data):
                    if number(data[i]['Heater_AO'])>F(9,2):
                        a=i
                        while i<len(data) and number(data[i]['Heater_AO'])>F(9,2):i+=1
                        spans.append((i-a,a,i))
                    else:i+=1
                _,a,b=max(spans);q=data[a:b]
                out[r]=([number(v['Time since Start [min]']) for v in q],[number(v['TR404-085d']) for v in q],[number(v['TR404-108e']) for v in q],number(data[b]['Time since Start [min]']))
    require(sorted(out)==list(range(4,10)),'Expected exactly six runs');return out

def grad(t,v):
    start=bisect.bisect_left(t,t[0]+15);tt=t[start:];g=[]
    for i in range(start,len(t)):
        lag=t[i]-15;j=bisect.bisect_right(t,lag)-1
        require(j>=0,'Incomplete history')
        if t[j]==lag:u=v[j]
        else:
            w=(lag-t[j])/(t[j+1]-t[j]);u=(1-w)*v[j]+w*v[j+1]
        g.append((v[i]-u)/15)
    return start,tt,g

def event(tt,g):
    for i in range(1,len(g)):
        if g[i-1]>=1 and g[i]<1:return tt[i-1]+(1-g[i-1])*(tt[i]-tt[i-1])/(g[i]-g[i-1])
    return None

def verify_case(t,x,y,action,rows,separator):
    require(all(a<b for a,b in zip(t,t[1:])),'Nonincreasing clock')
    require(len(rows)==len(t),'Witness length mismatch')
    require([int(q['preaction_row_index']) for q in rows]==list(range(len(t))),'Wrong witness row order')
    ea=[number(q['candidate_error_K']) for q in rows];es=[number(q['source_error_K']) for q in rows]
    delta=max(map(abs,ea+es));require(delta>0,'Empty perturbation')
    st,tt,ga=grad(t,[u+e for u,e in zip(x,ea)]);_,_,gs=grad(t,[u+e for u,e in zip(y,es)])
    j=separator-st;require(0<j<len(tt),'Invalid separator');tau=tt[j]
    min_candidate=min(ga[:j+1])-1;source_initial=gs[0]-1;source_below=1-gs[j]
    require(min_candidate>0 and source_initial>0 and source_below>0,'Reversed-sign contract failed')
    fs=event(tt,gs);fa=event(tt,ga)
    require(fs is not None and fs<tau,'Reference first crossing not before separator')
    require(fa is None or fa>tau,'Candidate crossing not after separator')
    require(tau<action,'Not pre-action')
    _,_,gna=grad(t,x);_,_,gns=grad(t,y)
    na=event(tt,gna);ns=event(tt,gns);require(na is not None and ns is not None and na<ns,'Wrong nominal order')
    original_guard=min(gna[0]-1,min(gns[:j+1])-1,1-gna[j])
    below_s=next(i for i,z in enumerate(gs) if z<1)
    below_a=next((i for i,z in enumerate(ga) if z<1),None)
    require(below_a is None or below_s<below_a,'Sampled first-below ordering failed')
    return {'original_radius_exact_K':serial(original_guard*F(15,2)),'sampled_source_first_below_index':below_s,'sampled_candidate_first_below_index':below_a,'sampled_order_reversed':True,'max_abs_raw_error_K':serial(delta),'candidate_prefix_count':j+1,'candidate_prefix_min_margin':serial(min_candidate),'source_initial_margin':serial(source_initial),'source_separator_margin':serial(source_below),'separator_elapsed_min':serial(tau-t[0]),'nominal_candidate_event_elapsed_min':serial(na-t[0]),'nominal_source_event_elapsed_min':serial(ns-t[0]),'perturbed_source_event_elapsed_min':serial(fs-t[0]),'perturbed_candidate_event_elapsed_min':serial(None if fa is None else fa-t[0]),'maximum_adjacent_candidate_error_jump_K':serial(max(abs(b-a) for a,b in zip(ea,ea[1:]))),'maximum_adjacent_source_error_jump_K':serial(max(abs(b-a) for a,b in zip(es,es[1:]))),'amplitude_le_1p60_K':delta<=F(8,5),'amplitude_le_2p28_K':delta<=F(57,25),'amplitude_le_4p57_K':delta<=F(457,100),'source_first_order_exact':True,'candidate_censored':fa is None,'all_prefix_signs_checked_exactly':True}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,default=Path(__file__).parent/'inputs');ap.add_argument('--witnesses',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    require(not a.output.exists(),'Output already exists')
    seps={int(q['run']):q for q in csv.DictReader((a.inputs/'primary_order_certificates.csv').open())};out=[]
    for r,(t,x,y,off) in sorted(source_runs(a.inputs).items()):
        p=a.witnesses/f'raw_error_witness_test{r}.csv';rows=list(csv.DictReader(p.open()))
        result=verify_case(t,x,y,off,rows,int(seps[r]['separator_native_sample_index']))
        require(F(int(result['original_radius_exact_K']['numerator']),int(result['original_radius_exact_K']['denominator']))>F(8,5),'Original 1.60 K guarantee not recovered')
        result['original_common_1p60_K_guarantee_verified']=True
        result.update({'run':r,'source_sha256':HASHES[r],'witness_sha256':hashlib.sha256(p.read_bytes()).hexdigest()});out.append(result)
        print(f"Test {r}: EXACT PASS; delta={result['max_abs_raw_error_K']['decimal']} K; prefix={result['candidate_prefix_count']}; <=2.28 K={result['amplitude_le_2p28_K']}",flush=True)
    final={'status':'PASS','method':'Independent standard-library rational recomputation of serialized witnesses against native decimal source values','source_files_verified':len(out),'prefix_constraints_verified':sum(q['candidate_prefix_count'] for q in out),'raw_sample_error_values_verified':2*sum(len(q[0]) for q in source_runs(a.inputs).values()),'source_first_reversals_verified':sum(q['source_first_order_exact'] for q in out),'all_within_2p28_K':all(q['amplitude_le_2p28_K'] for q in out),'scope':'Existence of hypothetical adversarial sample errors on a frozen replay; no probability, realistic time-correlation, physical intervention, calibrated uncertainty budget, or globally minimal reversal radius claimed.','runs':out}
    a.output.write_text(json.dumps(final,indent=2)+'\n')
if __name__=='__main__':main()
