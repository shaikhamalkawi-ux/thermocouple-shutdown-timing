"""Exact native-decimal check of a rounded LP positive six-run K7 witness.
Checks all no-early constraints plus L/U evaluations with rational arithmetic.
"""
from __future__ import annotations
import bisect,csv,json
from decimal import Decimal, getcontext
from fractions import Fraction as F
from pathlib import Path
from exact_three_row_certificate import rational,scan_source,weights_for_x,exact_event_and_coeff
getcontext().prec=50
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'DGIG_EventContract_20261010'/'inputs'/'compact'

def value(h,xx,knots):
    w=weights_for_x(xx,knots)
    return sum(q*z for q,z in zip(w,h))

def lerp(xx,yy,x):
    j=bisect.bisect_right(xx,x)-1
    if j<0 or j>=len(xx):raise ValueError('not a supported interpolation time')
    if xx[j]==x:return yy[j]
    alpha=(x-xx[j])/(xx[j+1]-xx[j]);return yy[j]+alpha*(yy[j+1]-yy[j])

def first_event(xx,yy):
    for i in range(1,len(yy)):
        if yy[i-1]>=1>yy[i]:
            return xx[i-1]+(1-yy[i-1])*(xx[i]-xx[i-1])/(yy[i]-yy[i-1])
    return None

def main():
    with open(SRC/'K7_knots.csv') as f:
        knots=[rational(a['candidate_knot_C']) for a in csv.DictReader(f)]
    source=json.loads((ROOT/'oracle_certificates.json').read_text())
    raw=source['K7_all_six']['h_lp']
    # This deterministic 12dp serialization ensures simple exact rational witness heights.
    h=[F(Decimal(f'{v:.12f}')) for v in raw]
    eta=F(Decimal('0.008319'))
    assert all(F(0)<=a<=550 for a in h) and all(a<=b for a,b in zip(h,h[1:]))
    verified=[]
    for rid in (4,6,7,8,5,9):
        rec=scan_source(rid)
        t,x,y=rec['times'],rec['x'],rec['y']
        mapped=[value(h,z,knots) for z in x]
        start=bisect.bisect_left(t,t[0]+15)
        tt=t[start:]
        g=[(mapped[start+j]-lerp(t,mapped,ts-15))/15 for j,ts in enumerate(tt)]
        gy=[(y[start+j]-lerp(t,y,ts-15))/15 for j,ts in enumerate(tt)]
        U=first_event(tt,gy)
        assert U is not None
        L=U-5
        early=[g[j]-1-eta for j,ts in enumerate(tt) if ts<=L]
        assert early
        l_slack=lerp(tt,g,L)-1-eta
        u_slack=1-eta-lerp(tt,g,U)
        slacks=early+[l_slack,u_slack]
        min_slack=min(slacks)
        assert min_slack>=0,('violated',rid,float(min_slack))
        first=first_event(tt,g)
        assert first is not None and L<=first<=U,('event outside target',rid,float(first),float(L),float(U))
        ups=sum(g[j-1]<1<=g[j] and tt[j]>=first for j in range(1,len(g)))
        verified.append({'run':rid,'margin_K_min':float(eta),'positive_min_slack_K_min':float(min_slack),
                        'first_event_min':float(first),'source_event_min':float(U),'source_lead_min':float(U-first),
                        'upward_recrossings':ups,'evaluated_early_points':len(early),'source_native_sha256':rec['sha256']})
        print('run',rid,'constraints',len(early)+2,'minimum_exact_slack',float(min_slack),'lead',float(U-first),'recross',ups)
    output={'status':'PASS','test':'exact native-decimal Fraction replay against ALL event-contract inequality rows with rounded fixed-grid 7-knot witness','margin_decimal':'0.008319','witness_heights_12dp':[str(Decimal(v.numerator)/Decimal(v.denominator)) for v in h], 'runs':verified}
    (ROOT/'exact_positive_witness.json').write_text(json.dumps(output,indent=2)+'\n')
    print('EXACT POSITIVE SIX-RUN WITNESS PASS')

if __name__=='__main__':main()
