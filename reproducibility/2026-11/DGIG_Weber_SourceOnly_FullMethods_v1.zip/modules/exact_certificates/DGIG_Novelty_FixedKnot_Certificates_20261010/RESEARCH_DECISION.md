# DGIG novelty investigation — evidence-admission decision (10 October 2026)

## What is genuinely NEW relative to frozen R14 and completed EventContract experiment

**New computed fact:** Under one *frozen* K7 knot basis, the sufficient event-timing contract can be satisfied across all six observed Weber primary runs with margin >0, even though the four-training-run-selected K7 calibration missed the D50 Test 9 source deadline.

1. Training-only maximum gradient margin: +0.158134000119908 K/min (previously known).
2. All-six maximum margin: +0.00832067508632655 K/min (new; test9 inclusion binds).
3. Three original Weber data inequalities suffice to derive the same all-six upper bound **exactly over the rational field**. Tight rows: Test 6 sample time 80.80443333 min, Test 7 deadline and Test 9 deadline. Dual coefficients approximately (0.495839662456837, 0.147576860090242, 0.356583477452921), with EXACT cancellation of all seven knot coefficients.
4. A fixed, 12-decimal-height witness satisfies every source-derived sampled/interpolated six-run inequality at positive margin 0.008319 K/min in exact Fraction arithmetic. All six first crossings fall in the predeclared five-minute one-sided window. **Every run has later upward recrossings on its recorded continuation**; this is NOT stable or executed shutdown equivalence.
5. Numerical minimum-temperature-error *retrospective oracles* fit the same K7 basis to ALL SIX known event constraints. At required margin 0.00001 K/min, fitted six-run temperature RMSE is 3.432618 C; at 0.008319 K/min it is 3.435823 C. Test 9 first crossing occurs 0.5033 min before the reference in one oracle, versus not observed in the original training-selected event-contract map. The oracle uses the very D50 outcomes, so cannot be called held-out success.
6. K5 sufficient contract remains infeasible already on the training runs (earlier result), but this does not establish full first-crossing impossibility for every K5 map.

## Independent scientific QA executed now

* The raw source archive's SHA-256 measurement hashes were verified by the existing immutable-source parser and a separate CSV DictReader used on original bytes.
* The new LP's primal/dual stationarity, residual and gaps were checked for 12 problems; sparse active dual vectors retained.
* New exact rational 3-row dual upper certificate independently reproduces the floating LP result to <2e-15 K/min.
* New exact rational positive six-run feasible witness: PASS for all 21,980 event inequalities; smallest strictly positive slack about 1.675e-6 K/min.
* An independently coded native CSV gradient/first-event replay reproduces 12 K7 oracle/run rows, 72 event/temperature/status comparisons.
* Eight machine-readable result files were regenerated from a fresh copy and found byte-identical (same environment).
* All figures are computed from original source data and the archived/frozen calibration vectors; no plotting sample invented.

## Novelty and transfer boundaries

This is an application-specific **feasibility-versus-selection certificate** and a sparse exact-number instance. It is not invention of LP duality, decision-focused learning, first threshold-time analysis, or temporal logic. The observed favorable Oracle outcomes are intrinsically post-hoc and use the D50 event measurements. No independent operating test, physical uncertainty budget, sensor-error robust guarantee, energy savings or closed-loop command execution was performed. The 5-minute event window is descriptive, not a calibrated operational safety tolerance. All observations remain from one apparatus and six recorded runs. The contract is sufficient but not necessary for arbitrary first-event satisfaction.

The current best publication path is to *replace* a weaker or repetitive R14 analysis passage with a short theorem+3-witness table, and put the full code and exact witnesses in supplementary evidence, but only after separate scientific/novelty review. R14 itself remains frozen, and no R15 paper was generated here.

## Closest work and reasons not to overclaim

- Elmachtoub and Grigas, *Smart Predict, then Optimize*, doi:10.1287/mnsc.2020.3922, establish decision-focused losses.
- Chaudhry, Estep, Stevens and Tavener, doi:10.1007/s10543-020-00825-0, establish first-threshold-time error analysis.
- Asarin et al., doi:10.1007/978-3-642-29860-8_12, establish parameter-validity reasoning over traces.
- Buyukkocak et al., arXiv:2103.14193, describe derivative/integral temporal predicates and MILP synthesis.
- Cardona, Kamale and Vasile, doi:10.1016/j.nahs.2025.101576, describe disjunction-centric temporal-logic MILP approaches.
- Roberts et al., doi:10.1111/ecog.02881, explain structured experimental splitting.

## Strong next scientific trigger

1. Source-independent real dataset with native time-synchronized thermocouple topology, controller state/rule, command and actuator-state evidence. The earlier KIT VESPA archive remains **mechanistic only** and its half-charge protocol censors the primary target; do not upgrade it.
2. A genuinely more general, **necessary and sufficient** event reachability certificate (including initially-below cases and recrossings), with a different proof/checker, valid without tuning to D50, plus a second independent experimental family. Current LP covers only a specified sufficient event contract.
3. Prospective fixed-protocol shadow-controller measurements from a consenting operator. Such passive prospective comparisons are NOT equivalent to executed alternative closed-loop shutdowns.

Reject: arbitrary Gaussian sensor-noise levels, simulated closed-loop experiments presented as physical validation, extra polynomial/NN calibrators chosen after D50, and rhetoric-driven claims of a first-invention.
