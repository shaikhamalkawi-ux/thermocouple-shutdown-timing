"""Retrospective fixed-grid event-contract oracle; NOT a learned D50 transfer model.
Input provenance and event definitions are taken from the frozen EventContract package.
"""
from __future__ import annotations
import json,sys,time,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linprog,minimize

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'DGIG_EventContract_20261010'
sys.path.insert(0,str(SOURCE/'code'))
from common import load_runs,hat,gradient,event,interp_vec,score
RUNS=(4,6,7,8,5,9)
TRAIN=(4,6,7,8)
TEST=(5,9)


def build_one(r,knots,K):
  B=hat(r['x'],knots)
  tt,C=gradient(r['t'],B)
  _,gsource=gradient(r['t'],r['y'])
  U=event(tt,gsource)
  L=U-5.
  # Numerical strictness convention: record g>=1+eta through L, and g(U)<=1-eta
  ix=np.flatnonzero(tt<=L)
  mat=[];bs=[];meta=[]
  for i in ix:
    mat.append(np.r_[-C[i],1.]);bs.append(-1.);meta.append({'run':r['run'],'type':'no_early','index':int(i),'time_min':float(tt[i])})
  mat.append(np.r_[-interp_vec(tt,C,L),1.]);bs.append(-1.);meta.append({'run':r['run'],'type':'early_boundary','time_min':float(L)})
  mat.append(np.r_[interp_vec(tt,C,U),1.]);bs.append(1.);meta.append({'run':r['run'],'type':'source_deadline','time_min':float(U)})
  return np.asarray(mat),np.asarray(bs),meta


def make_problem(data,K):
 d=pd.read_csv(SOURCE/'inputs/compact'/f'K{K}_knots.csv')
 knots=d.candidate_knot_C.to_numpy()
 assert len(knots)==K and np.all(np.diff(knots)>0)
 parts={rid:build_one(data[rid],knots,K) for rid in RUNS}
 mon=np.zeros((K-1,K+1))
 mon[np.arange(K-1),np.arange(K-1)]=1
 mon[np.arange(K-1),np.arange(1,K)]=-1
 def gather(ids):
   mats=[parts[r][0] for r in ids]+[mon]
   bs=[parts[r][1] for r in ids]+[np.zeros(K-1)]
   m=sum([parts[r][2] for r in ids],[])+[{'run':0,'type':'monotone','index':i} for i in range(K-1)]
   A=np.vstack(mats);b=np.concatenate(bs)
   return A,b,m
 return knots,gather


def score_lp(A,b,K):
  obj=np.r_[np.zeros(K),-1.]
  rr=linprog(obj,A_ub=A,b_ub=b,bounds=[(0.,550.)]*K+[(None,None)],method='highs',options={'primal_feasibility_tolerance':1e-9,'dual_feasibility_tolerance':1e-9})
  if not rr.success: raise RuntimeError(rr.message)
  v=float(np.max(A@rr.x-b))
  stat=obj - A.T@rr.ineqlin.marginals-rr.lower.marginals-rr.upper.marginals
  dual=float(b@rr.ineqlin.marginals+550*np.sum(rr.upper.marginals[:K]))
  info={'max_eta_K_min':float(rr.x[-1]),'max_primal_inequality_violation':v,'max_dual_stationarity_residual':float(np.max(abs(stat))),'primal_minus_dual_objective':float(obj@rr.x-dual),'num_constraints':len(b),'num_nonzero_duals':int(np.sum(np.abs(rr.ineqlin.marginals)>1e-8))}
  if v>5e-7 or info['max_dual_stationarity_residual']>1e-6 or abs(info['primal_minus_dual_objective'])>5e-7:raise ValueError('failed LP certificate QA: '+str(info))
  return rr,info


def rmse_objective(data,knots,ids):
   K=len(knots);Q=np.zeros((K,K));c=np.zeros(K);y2=0.
   for run in ids:
     r=data[run];B=hat(r['x'],knots);y=r['y'];weight=1/(len(ids)*len(y))
     Q+=weight*(B.T@B)
     c+=weight*(B.T@y)
     y2+=float(weight*(y@y))
   h0=np.linalg.solve(Q,c)
   def loss(h):
     delta=h-h0
     return float(delta@Q@delta+np.dot(h0,Q@h0)-2*c@h0+y2)
   def jac(h):return 2*Q@(h-h0)
   return loss,jac,h0


def restricted_qp(A,b,knots,data,ids,start,eta=1e-5):
  K=len(knots)
  # A:[-G_i,1] inequality encodes at-least margin eta; translate to heights-only constraint.
  AH=A[:,:K];bH=b-A[:,K]*eta
  loss,jac,hls=rmse_objective(data,knots,ids)
  # Collect a finite reduced working set, exchange violating constraints.
  # This convex quadratic is global if KKT residual and feasibility checks pass.
  h=start[:K].copy(); active=set(np.flatnonzero(AH@h>bH-1e-6).tolist())
  if not active:active={int(np.argmax(AH@h-bH))}
  info=[]
  for it in range(50):
    idx=np.array(sorted(active),dtype=int);aa=AH[idx];bb=bH[idx]
    fit=minimize(loss,h,jac=jac,method='SLSQP',bounds=[(0.,550.)]*K,
                 constraints=[{'type':'ineq','fun':lambda h,aa=aa,bb=bb:bb-aa@h,
                     'jac':lambda h,aa=aa:-aa}],
                 options={'maxiter':750,'ftol':1e-11})
    h=fit.x;v=AH@h-bH
    mx=float(v.max());bad=np.flatnonzero(v>2e-7)
    info.append({'iter':it,'working_set':len(idx),'max_viol':mx,'mse':loss(h),'fit_success':bool(fit.success)})
    if len(bad)==0:break
    # Add all violations, including near duplicates; selection remains deterministic.
    prev=len(active);active.update(map(int,bad))
    if prev==len(active):break
  good=bool(mx<5e-7)
  if not good:raise RuntimeError(f'Exchange algorithm not feasible, max viol={mx}, it={it}')
  # KKT residual on active-set with nonnegative multipliers; for numerical purposes, do not claim exact certificate here.
  from scipy.optimize import nnls
  eligible=np.flatnonzero(abs(AH@h-bH)<2e-5)
  # normalized gradients of inequality constraints; for minimum objective, grad f + A.T lambda=0, lambda>=0
  mat=AH[eligible].T
  if mat.size:
    lam,res=nnls(mat,-jac(h))
  else:lam,res=np.array([]),float(np.linalg.norm(jac(h)))
  return h,{'MSE_C2':loss(h),'RMSE_C':np.sqrt(loss(h)),'QP_feasible':good,'KKT_gradient_residual':float(res),'positive_multipliers':int(np.sum(lam>1e-8)),'iterations':len(info),'exchange_log':info,'eta_set':eta}


def main():
  data=load_runs(strict=True)
  rows=[];joint_results={}; witnesses={}
  for K in (5,7):
    knots,gather=make_problem(data,K)
    for selection,ids in [
      ('train',TRAIN),('train_plus_5',(*TRAIN,5)),('train_plus_9',(*TRAIN,9)),
      ('all_six',RUNS),('test5_only',(5,)),('test9_only',(9,))]:
      A,b,meta=gather(ids);rr,report=score_lp(A,b,K)
      orig={'K':K,'scope':selection,'runs':','.join(map(str,ids)),'max_eta_K_min':report['max_eta_K_min'],
            'num_inequalities':len(b),'num_nonzero_lp_duals':report['num_nonzero_duals'],
            'lp_primal_violation':report['max_primal_inequality_violation'],'lp_dual_gap':report['primal_minus_dual_objective'],
            'lp_stationarity_residual':report['max_dual_stationarity_residual']}
      rows.append(orig)
      dual_ix=np.flatnonzero(np.abs(rr.ineqlin.marginals)>1e-8)
      joint_results[f'K{K}_{selection}']={'summary':report,'h_lp':rr.x[:K].tolist(),
          'supporting_rows':[dict(meta[i],inequality_row=int(i),dual_multiplier=float(rr.ineqlin.marginals[i]),constraint_residual=float(A[i]@rr.x-b[i])) for i in dual_ix],
          'lo_bound_multipliers':rr.lower.marginals.tolist(),'hi_bound_multipliers':rr.upper.marginals.tolist()}
      if K==7 and selection=='all_six':
        # Raw trace replay is required; optimum witness may have huge temperature error because LP disregards MSE.
        witness=[]
        for rid in RUNS:
          v=score(data[rid],knots,rr.x[:K]);witness.append({'run':rid,**v})
        joint_results['K7_all_six']['raw_replay_lp']=witness
        witnesses['K7_all_six_lp']=rr.x[:K]
        for ids2,name in [(TRAIN,'train_MSE'),(RUNS,'all_six_MSE')]:
          h,q=restricted_qp(A,b,knots,data,ids2,rr.x,eta=1e-5)
          k='K7_all_six_'+name+'_oracle'
          joint_results[k]={'status':'retrospective_uses_D50_event_data','QP':q,'run_replay':[{'run':rid,**score(data[rid],knots,h)} for rid in RUNS]}
          witnesses[k]=h
    if K==7:
       fitframe=pd.DataFrame({'candidate_knot_C':knots, **{k+'_source_knot_C':v for k,v in witnesses.items()}})
       fitframe.to_csv(HERE/'oracle_K7_witnesses.csv',index=False,float_format='%.17g')
  pd.DataFrame(rows).to_csv(HERE/'grid_contract_feasibility.csv',index=False,float_format='%.17g')
  (HERE/'oracle_certificates.json').write_text(json.dumps(joint_results,indent=2,allow_nan=False))
  print(pd.DataFrame(rows)[['K','scope','max_eta_K_min','num_inequalities','num_nonzero_lp_duals']].to_string(index=False))
  for k,v in joint_results.items():
    if 'oracle' in k:
      print('ORACLE',k,'MSE',v['QP']['MSE_C2'],'KKT',v['QP']['KKT_gradient_residual'])
      for z in v['run_replay']:
        print(z['run'],z['rmse_C'],z['status'],z['source_lead_min'],z['recrossings'])

if __name__=='__main__':main()
