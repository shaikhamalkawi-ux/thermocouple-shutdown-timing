#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python verify_manifest.py # immutable received package BEFORE execution
python work_oracle.py
python exact_three_row_certificate.py
python exact_positive_witness.py
python independent_native_replay.py
python oracle_frontier.py
python make_oracle_figures.py
python verify_science_outputs.py # source and result parity; ignores mutable PDF metadata
