"""Vector figures made only from original Weber source and frozen calibration maps."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'pdf.fonttype':42,'ps.fonttype':42,'font.size':10,'axes.titlesize':10,'axes.labelsize':10,'legend.fontsize':8})
HERE=Path(__file__).resolve().parent
SRC=HERE/'DGIG_EventContract_20261010'
sys.path.insert(0,str(SRC/'code'))
from common import load_runs,gradient,event,hat

def main():
    (HERE/'figures').mkdir(exist_ok=True)
    data=load_runs(strict=True)
    k=pd.read_csv(SRC/'inputs/compact/K7_knots.csv').candidate_knot_C.to_numpy()
    d=pd.read_csv(SRC/'results/K7_min_MSE_contract_knots.csv')
    frozen=d.predicted_source_knot_C.to_numpy()
    v=pd.read_csv(HERE/'oracle_K7_witnesses.csv')
    oracle=v['K7_all_six_train_MSE_oracle_source_knot_C'].to_numpy()
    r=data[9];t,x,y=r['t'],r['x'],r['y']
    tt,gr=gradient(t,y);_,gf=gradient(t,hat(x,k)@frozen);_,go=gradient(t,hat(x,k)@oracle)
    U=event(tt,gr)
    lo=U-5.5
    xx=tt-U
    mask=tt>=lo
    fig,ax=plt.subplots(figsize=(8.3,4.7))
    ax.plot(xx[mask],gr[mask],lw=1.75,label='Reconstructed reference gradient')
    ax.plot(xx[mask],gf[mask],lw=1.6,ls='--',label='Training-selected seven-knot calibration')
    ax.plot(xx[mask],go[mask],lw=1.6,ls='-.',label='Retrospective six-run oracle (uses Test 9)')
    ax.axhline(1,lw=1,ls=':',color='0.25',label='Rule threshold')
    ax.axvline(0,lw=1,ls=':',color='0.55')
    ax.axvline(-5,lw=.9,ls=':',color='0.65')
    candidate_event=event(tt,go)
    ax.plot(candidate_event-U,1,marker='o',ms=6,markerfacecolor='white',markeredgecolor='black')
    ax.set_xlabel('Time relative to reconstructed source event (min)')
    ax.set_ylabel('Fifteen-minute gradient (K/min)')
    ax.set_xlim(-5.5,max(xx[mask])+.06)
    ax.set_title('D50 Test 9: model-family feasibility versus train-only selection')
    ax.legend(loc='upper left',frameon=True)
    fig.tight_layout();fig.savefig(HERE/'figures/test9_oracle_gradient.pdf');fig.savefig(HERE/'figures/test9_oracle_gradient.png',dpi=170);plt.close(fig)
    print('Source event',U,'oracle first event',candidate_event,'horizon',r['horizon']-U)
    f=pd.read_csv(HERE/'retrospective_margin_accuracy_frontier.csv')
    fig,ax=plt.subplots(figsize=(7.6,4.6))
    ax.plot(f['margin_K_min'],f['all6_RMSE_C'],'o-',lw=1.5)
    ax.set_xlabel('Required retrospective six-run gradient margin (K/min)')
    ax.set_ylabel('Minimum fitted six-run temperature RMSE (C)')
    ax.set_title('Seven-knot representational trade-off on observed traces')
    ax.ticklabel_format(axis='x',style='plain')
    fig.tight_layout();fig.savefig(HERE/'figures/margin_rmse_frontier.pdf');fig.savefig(HERE/'figures/margin_rmse_frontier.png',dpi=170);plt.close(fig)

if __name__=='__main__':main()
