"""Exact native-decimal Fraction certificate for K7 six-run LP bound.

This is intentionally separate from the floating-point LP's matrix construction.
It reads the raw Weber CSV bytes, forms each of three tight constraints with
native decimal rational numbers, independently reconstructs exact source-event
interpolation, and solves the three-weight dual identity in Q.
"""
from __future__ import annotations
import bisect,csv,hashlib,io,json,sys,zipfile
from decimal import Decimal, getcontext
from fractions import Fraction as F
from pathlib import Path
getcontext().prec=45
ROOT=Path(__file__).resolve().parent
BUNDLE=ROOT/'DGIG_EventContract_20261010'
INPUT=BUNDLE/'inputs/compact'
OUT=ROOT/'three_row_exact_certificate.json'


def rational(s):return F(Decimal(str(s).strip().replace(',','.')))


def scan_source(n):
  for archive in sorted(INPUT.glob('*PRIMARY*.zip')):
    with zipfile.ZipFile(archive) as z:
      for fn in z.namelist():
        if fn.endswith('/MeasurementData.CSV') and int(Path(fn).parent.name.split('_')[0])==n:
          raw=z.read(fn);f=io.StringIO(raw.decode('utf-8-sig'))
          rr=csv.DictReader(f,delimiter=';')
          rows=[r for r in rr]
          # Selection based on longest contiguous Heater_AO > 4.5 mA
          on=[float(row['Heater_AO'].replace(',','.'))>4.5 for row in rows]
          starts=[i for i in range(len(rows)) if on[i] and (i==0 or not on[i-1])]
          spans=[]
          for start in starts:
            i=start
            while i<len(rows) and on[i]:i+=1
            spans.append((i-start,start,i))
          _,begin,end=max(spans)
          ordered=rows[begin:end]
          times=[rational(x['Time since Start [min]']) for x in ordered]
          assert all(times[i]<times[i+1] for i in range(len(times)-1))
          return dict(times=times,
                      x=[rational(x['TR404-085d']) for x in ordered],
                      y=[rational(x['TR404-108e']) for x in ordered],
                      name=fn,sha256=hashlib.sha256(raw).hexdigest(),begin=begin,end=end)
  raise FileNotFoundError(n)


def weights_for_x(x,knots):
  k=len(knots)
  if x<=knots[0]:return (F(1),)+tuple(F(0) for _ in range(k-1))
  if x>=knots[-1]:return tuple(F(0) for _ in range(k-1))+(F(1),)
  j=bisect.bisect_right(knots,x)-1
  p=(x-knots[j])/(knots[j+1]-knots[j]); v=[F(0)]*k;v[j]=1-p;v[j+1]=p
  return tuple(v)


def interp_series(vals,times,where):
  j=bisect.bisect_right(times,where)-1
  if j<0 or j>=len(times): raise ValueError('outside native time axis')
  if times[j]==where:return vals[j]
  alpha=(where-times[j])/(times[j+1]-times[j])
  return vals[j]+alpha*(vals[j+1]-vals[j])


def gradient_component(rec,index,knots=None):
  t=rec['times'][index];lag=t-15
  if knots is None:
    y=rec['y'];return (y[index]-interp_series(y,rec['times'],lag))/15
  weights=[weights_for_x(x,knots) for x in rec['x']]
  w=weights[index];start=bisect.bisect_right(rec['times'],lag)-1
  if rec['times'][start]==lag:older=weights[start]
  else:
    frac=(lag-rec['times'][start])/(rec['times'][start+1]-rec['times'][start]);older=tuple(a+frac*(b-a) for a,b in zip(weights[start],weights[start+1]))
  return tuple((a-b)/15 for a,b in zip(w,older))


def exact_event_and_coeff(rec,knots):
  # Calculate the native-basis source event exactly from the first crossing.
  # This loop does not use the other analysis implementation or any interpolation library.
  ts=rec['times'];k0=bisect.bisect_left(ts,ts[0]+15)
  last=None
  for i in range(k0,len(ts)):
    if i==k0:before=gradient_component(rec,i);last=i;continue
    after=gradient_component(rec,i)
    if before>=1 and after<1:
      U=ts[last]+(F(1)-before)*(ts[i]-ts[last])/(after-before)
      wa=gradient_component(rec,last,knots);wb=gradient_component(rec,i,knots)
      alpha=(U-ts[last])/(ts[i]-ts[last]);out=tuple(a+alpha*(b-a) for a,b in zip(wa,wb))
      return U,out,last,i
    last=i;before=after
  raise AssertionError('no source first event')


def solve3(A,b):
  D=[[F(z) for z in row]+[F(v)] for row,v in zip(A,b)]
  n=3
  for j in range(n):
    pivot=next(i for i in range(j,n) if D[i][j])
    D[j],D[pivot]=D[pivot],D[j]
    div=D[j][j];D[j]=[e/div for e in D[j]]
    for i in range(n):
      if i==j:continue
      mult=D[i][j]
      D[i]=[a-mult*x for a,x in zip(D[i],D[j])]
  return tuple(row[-1] for row in D)


def main():
  ks=[]
  with open(INPUT/'K7_knots.csv') as f:
    for row in csv.DictReader(f):ks.append(rational(row['candidate_knot_C']))
  records={k:scan_source(k) for k in (6,7,9)}
  # Test 6 active constraint is the native gradient sample index 3647
  ix=bisect.bisect_left(records[6]['times'],records[6]['times'][0]+15)+3647
  g6=gradient_component(records[6],ix,ks)
  U6,_,_,_=exact_event_and_coeff(records[6],ks)
  assert records[6]['times'][ix]<=U6-5
  U7,g7,j7a,j7b=exact_event_and_coeff(records[7],ks)
  U9,g9,j9a,j9b=exact_event_and_coeff(records[9],ks)
  # A_ub h eta <= b. 6 noearly: -g6 h + eta <= -1,
  # 7/9 deadlines: g7 h + eta <= 1, g9 h + eta <= 1
  rows=[tuple(-z for z in g6),g7,g9];rhs=[F(-1),F(1),F(1)]
  weights=solve3([[F(1),F(1),F(1)],[row[4] for row in rows],[row[5] for row in rows]],[F(1),F(0),F(0)])
  assert all(w>0 for w in weights) and sum(weights)==1
  coef=[sum(weights[i]*rows[i][j] for i in range(3)) for j in range(7)]
  assert all(v==0 for v in coef),coef
  upper=sum(a*b for a,b in zip(weights,rhs))
  assert abs(float(upper)-0.008320675086328066)<1e-8,(float(upper))
  as_float=lambda a:float(a)
  print('Exact three-row joint K7 margin bound: ',str(Decimal(upper.numerator)/Decimal(upper.denominator)))
  print('weight6, weight7, weight9: ',[float(z) for z in weights])
  print('All seven h coefficients cancel in Q: ',all(z==0 for z in coef))
  print('Source exact event U7=',float(U7),'U9=',float(U9),'original t6=',float(records[6]['times'][ix]))
  data={'description':'Native-decimal source, exact rational dual three-row bound for fixed K7 knot grid, finite-interval gradients; NOT a physical uncertainty guarantee',
        'source_sha256':{str(k):r['sha256'] for k,r in records.items()},
        'active_constraints':[{'run':6,'kind':'no_early','time_min':float(records[6]['times'][ix]),'native_sample_index':ix},
          {'run':7,'kind':'source_deadline','time_min':float(U7),'gradient_native_bracket':[j7a,j7b]},
          {'run':9,'kind':'source_deadline','time_min':float(U9),'gradient_native_bracket':[j9a,j9b]}],
        'exact_numerator':str(upper.numerator),'exact_denominator':str(upper.denominator),
        'upper_bound_40dp':str(Decimal(upper.numerator)/Decimal(upper.denominator)),
        'dual_weights_numerator_denominator':[[str(z.numerator),str(z.denominator)] for z in weights],
        'dual_weights_approx':[float(z) for z in weights],
        'coefficient_identity_exact_zero':all(z==0 for z in coef),
        'nonnegative_dual_weights':all(w>=0 for w in weights),
        'independent_floating_lp_comparison_difference':float(upper)-0.008320675086328066}
  OUT.write_text(json.dumps(data,indent=2)+'\n')

if __name__=='__main__':main()
