# DGIG fixed-basis oracle and exact-source certificate (2026-10-10)

**Status:** real-data exploratory research extension; **NOT an integrated/new journal manuscript**, not blind D50 evaluation, not a deployed control algorithm. The original R14 16-page manuscript and 6-page supplement have not been modified.

## Scientific question

Under the fixed K5/K7 knot grids and the pre-existing sufficient first-event contract, can a positive-margin model satisfy the four homogeneous training runs and also both D50 observed traces? If so, the failure of the *training-selected* D50 predictor is not a universal representational impossibility. D50-observed oracle fits are retrospective diagnostics and are **not independent test results**.

## Results created from original Weber data

* `grid_contract_feasibility.csv` has 12 LP comparisons, including train, train + each D50, joint six, and individual D50.
* `oracle_certificates.json` retains all LP primal/dual residuals, sparse active constraints and oracle QP run-by-run results.
* `three_row_exact_certificate.json` contains the **exact native-decimal rational** three-constraint dual proof of the tight K7 all-six-run margin upper bound: 0.008320675086326554... K/min.
* `exact_positive_witness.json` independently checks a 12-decimal seven-knot witness at margin 0.008319 K/min against every required raw-source gradient inequality, using exact fractions (not floating-point tests).
* `oracle_K7_witnesses.csv` lists numerical knot heights for two retrospective D50-informed QP oracles.
* `independent_replay.json` checks 12 model/run replay rows and 72 output comparisons directly from the original Weber CSV bytes via separate source parsing and event routines.
* `retrospective_margin_accuracy_frontier.csv` records the declared fixed 5-point margin/RMSE diagnostic grid; the fits use Test 5/9 event outcomes as constraints, so no prospective-performance interpretation is possible.
* `figures/test9_oracle_gradient.pdf` and `figures/margin_rmse_frontier.pdf` are vector PDF figures generated from measured data and the saved model maps.
* `technical_report.pdf` documents evidence, math, limitations and closest established literature.

## Inputs and license

`DGIG_EventContract_20261010/inputs/compact/DGIG_WEBER_CORE_PRIMARY_A_tests4_6.zip` and `...PRIMARY_B_tests7_9.zip` contain original Weber Version 2 CSVs. **Data source**: Weber et al., Mendeley Data, DOI [10.17632/3pp86gdvh4.2](https://doi.org/10.17632/3pp86gdvh4.2), CC BY 4.0. The six `MeasurementData.CSV` file hashes and row counts are enforced within `DGIG_EventContract_20261010/code/common.py` and checked by the exact replayer. Source thermocouple: TR404-108e; candidate: TR404-085d.

`K5_knots.csv`, `K7_knots.csv` and `K7_min_MSE_contract_knots.csv` are the **frozen pre-existing model bases/maps**. No fitted knots, event windows or thresholds have been changed for this experiment.

## Reproduce from a fresh extracted copy

Use Python 3.11+ with NumPy, pandas, SciPy and matplotlib. Tested in Python 3.13. Exact dependencies of this environment are recorded in `environment.json`.

```bash
bash run_all.sh
```

The runner verifies the immutable payload **before** generating new outputs, then compares eight main machine-readable results and two PNG scientific figures byte-for-byte with the packaged snapshot. PDF plot metadata may contain creation timestamps and is therefore checked for legibility/vector content, not strict PDF byte identity. Different numerical library versions can still change the last digits: the exact-rational proof does not depend on the LP solver.

## Scientific boundaries

1. The contract is a **sufficient, not necessary**, condition for first downward crossing within [source event − 5 minutes, source event]. Infeasibility does not imply impossibility of all alternative event-preserving maps, particularly those with intermediate recrossings.
2. D50 events are included to fit all-six-run oracles. Their event-success scores are **retrospective and data-leaking by design**; the originally trained K7 map missed Test 9. Do not advertise successful external validation.
3. The margin is in gradient units on the recorded traces. No source-event measurement uncertainty, physical sensor-noise process, or prospective closed-loop behavior has been certified.
4. Standard polyhedral feasibility and LP duality are established mathematical techniques; this bundle does not claim priority for them. Novelty admission requires scholarly review of this **particular source-derived certificate and application**.
