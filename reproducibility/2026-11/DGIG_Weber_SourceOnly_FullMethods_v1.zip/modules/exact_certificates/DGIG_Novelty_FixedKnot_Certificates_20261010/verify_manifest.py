from pathlib import Path
import hashlib,csv,sys
ROOT=Path(__file__).resolve().parent
p=ROOT/'MANIFEST_SHA256.csv'
with p.open(newline='') as f:rows=list(csv.DictReader(f))
assert rows and len({r['file'] for r in rows})==len(rows)
errors=[]
for r in rows:
 q=ROOT/r['file']
 if not q.is_file() or hashlib.sha256(q.read_bytes()).hexdigest()!=r['sha256']:
  errors.append(r['file'])
if errors:
 print('FAIL',errors);sys.exit(1)
print('PASS: all',len(rows),'payload files match SHA256 manifest')
