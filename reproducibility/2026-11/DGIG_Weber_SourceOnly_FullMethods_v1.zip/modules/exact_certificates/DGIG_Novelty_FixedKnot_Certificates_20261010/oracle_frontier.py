"""Retrospective six-run fixed-K7 margin/temperature-MSE frontier.
D50 event constraints participate in EACH fit: explanatory oracle only.
"""
import csv,json,sys
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from work_oracle import RUNS,TRAIN,TEST,make_problem,restricted_qp,rmse_objective
sys.path.insert(0,str(ROOT/'DGIG_EventContract_20261010'/'code'))
from common import load_runs,score

def main():
    data=load_runs(strict=True)
    K=7;knots,gather=make_problem(data,K);A,b,_=gather(RUNS)
    q=json.loads((ROOT/'oracle_certificates.json').read_text())
    x=np.array(q['K7_all_six']['h_lp']+[q['K7_all_six']['summary']['max_eta_K_min']])
    rows=[];witness=[]
    for margin in [1e-5,0.001,0.004,0.008,0.008319]:
        h,qa=restricted_qp(A,b,knots,data,RUNS,x,eta=margin)
        tr=[score(data[r],knots,h) for r in TRAIN]
        held=[score(data[r],knots,h) for r in TEST]
        rows.append({'margin_K_min':margin,'all6_RMSE_C':qa['RMSE_C'],
            'train_equal_run_MSE_C2':float(np.mean([z['rmse_C']**2 for z in tr])),
            'test5_RMSE_C':held[0]['rmse_C'],'test9_RMSE_C':held[1]['rmse_C'],
            'test5_status':held[0]['status'],'test9_status':held[1]['status'],
            'test5_recrossings':held[0]['recrossings'],'test9_recrossings':held[1]['recrossings'],
            'KKT_residual':qa['KKT_gradient_residual'],
            'QP_max_violation':max(A@np.r_[h,margin]-b)})
        witness.append({'margin_K_min':margin,'h':h.tolist(),'QP':qa})
        print(margin,'RMSE all6',qa['RMSE_C'],'train_mse',rows[-1]['train_equal_run_MSE_C2'],
              'D50 RMSE',held[0]['rmse_C'],held[1]['rmse_C'],'KKT',qa['KKT_gradient_residual'])
    pd.DataFrame(rows).to_csv(ROOT/'retrospective_margin_accuracy_frontier.csv',index=False,float_format='%.17g')
    (ROOT/'frontier_witnesses.json').write_text(json.dumps(witness,indent=2,allow_nan=False)+'\n')

if __name__=='__main__':main()
