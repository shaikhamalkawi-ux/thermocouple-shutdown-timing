"""Compare deterministic science outputs to the originally packaged hashes.
Do not require figure PDFs to have byte-identical creation metadata.
"""
from pathlib import Path
import csv,hashlib,sys
ROOT=Path(__file__).resolve().parent
with (ROOT/'MANIFEST_SHA256.csv').open(newline='') as fh:
 rows={r['file']:r['sha256'] for r in csv.DictReader(fh)}
science=['grid_contract_feasibility.csv','oracle_K7_witnesses.csv','oracle_certificates.json',
         'three_row_exact_certificate.json','exact_positive_witness.json','independent_replay.json',
         'retrospective_margin_accuracy_frontier.csv','frontier_witnesses.json',
         'figures/test9_oracle_gradient.png','figures/margin_rmse_frontier.png']
errors=[]
for f in science:
 p=ROOT/f
 if f not in rows or not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=rows[f]:errors.append(f)
if errors:
 print('FAIL scientific parity:',errors);sys.exit(1)
print('PASS:',len(science),'numerical/machine-scientific output files byte-identical after clean replay')
