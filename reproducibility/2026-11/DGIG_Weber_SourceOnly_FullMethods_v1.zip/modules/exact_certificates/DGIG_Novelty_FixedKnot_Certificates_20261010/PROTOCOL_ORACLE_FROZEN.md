# Prespecified exploratory representational-feasibility diagnostic — DGIG

Original project baseline R14 and frozen event-contract results are immutable. This diagnostic is selected after previous examination of the six-run campaign and after prior D50 outcomes; it is deliberately retrospective (an explanatory oracle), not external or unbiased held-out validation. No new learning method or knot positions are allowed.

## Frozen inputs
The original Weber V2 six rule-controlled experiments 4-9, exact source hashes in prior bundle. Source TR404-108e and candidate TR404-085d, strict pre-action measurement history. The fixed K5 and K7 knots are exactly those archived in EventContract inputs. Source first crossing reconstructed with 15-minute finite-interval gradient and threshold 1 K/min. Early allowance 5 minutes is descriptive only. Same event interpolation and same monotonic knot-height bounds [0,550] C as archived LP.

## Research questions
(A) Does a monotone calibration on each frozen K5/K7 grid exist for each D50 case individually, satisfying the sufficient recorded-gradient contract (no subthreshold sampled gradient before L=source_event-5 min; gradient >= 1 at L; gradient <=1 at U=source_event)? Maximize a uniform signed gradient margin eta using LP with eta>=0 as the condition. Always replay the resulting *first event* from measurements.
(B) Is a single frozen-grid calibration feasible on all four training runs and both D50 runs, using the *same* sufficient event contract? LP maximize eta across all six, optionally report a strict positive margin. Any infeasible result is ONLY for this sufficient contract, not nonexistence of another first-crossing-calibration with recrossings.
(C) When feasible, find an after-outcome oracle that minimizes D50-only temperature MSE while satisfying the contract, with no claim of training generalization. Quantify gap against original training-selected maps; do not use resulting oracle as a new test-trained method. Given potential nonconvexity of exact first crossing, do not claim necessary-and-sufficient or global first-event feasibility from this contract.

## Numerical controls
Use SciPy HiGHS LP with primal+dual optimality checks; independently replay every claimed witness from raw source CSV. Preserve censored runs, incomplete horizon and upward recrossings. When solver certificate strong, verify selected rows from native decimal Fraction where feasible. Do not promote results until QA passes.

## Stopping
If the sufficient-contract grid cannot conclusively distinguish representations, record that negative finding. Do not expand to high-capacity spline/SGD/other layouts or tune to D50 as a proposed deployable method.
