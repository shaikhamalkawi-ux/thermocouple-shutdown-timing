"""Independent standard-library decoder/gradient/event reader of original Weber CSV.
Does not import the original helper implementation or invoke optimization.
Checks saved heldout-event-informed *oracle* mappings against raw series.
"""
from __future__ import annotations
from bisect import bisect_right
from decimal import Decimal
import csv, hashlib,io,json,math,zipfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'DGIG_EventContract_20261010'/'inputs'/'compact'
REF=json.loads((ROOT/'oracle_certificates.json').read_text())

def field(s):return float(Decimal(s.replace(',','.')))

def native(run):
    for zp in sorted(SRC.glob('*PRIMARY*.zip')):
        with zipfile.ZipFile(zp) as z:
            for name in z.namelist():
                if not name.endswith('/MeasurementData.CSV') or int(Path(name).parent.name.split('_')[0])!=run:continue
                raw=z.read(name)
                rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')), delimiter=';'))
                v=np.array([[field(row[c]) for c in ['Time since Start [min]','TR404-085d','TR404-108e','Heater_AO']] for row in rows])
                on=v[:,3]>4.5;starts=[];ends=[]
                for i,flag in enumerate(on):
                    if flag and (i==0 or not on[i-1]):starts.append(i)
                    if flag and (i==len(on)-1 or not on[i+1]):ends.append(i+1)
                idx=int(np.argmax(np.subtract(ends,starts)))
                s,a=starts[idx],ends[idx]
                v=v[s:a]
                return v,hashlib.sha256(raw).hexdigest()
    raise FileNotFoundError(run)

def interp(t,v,x):
    j=bisect_right(t,x)-1
    if j<0:return v[0]
    if j>=len(t)-1:return v[-1]
    if t[j]==x:return v[j]
    return v[j]+(x-t[j])*(v[j+1]-v[j])/(t[j+1]-t[j])

def grad(t,y):
    ts=[];vals=[]
    for j in range(len(t)):
        if t[j]-t[0]<15:continue
        old=interp(t,y,t[j]-15)
        ts.append(t[j]);vals.append((y[j]-old)/15)
    return ts,vals

def crossing(ts,g):
    for j in range(1,len(g)):
        if g[j-1]>=1 and g[j]<1:
            t=ts[j-1]+(1-g[j-1])*(ts[j]-ts[j-1])/(g[j]-g[j-1]);return t,j
    return None,None

def scored(run,knots,heights):
    m,digest=native(run)
    t=m[:,0].tolist();x=m[:,1].tolist();y=m[:,2].tolist()
    cand=np.interp(x,knots,heights).tolist()
    tr,gy=grad(t,y);tc,gc=grad(t,cand)
    assert len(tr)==len(tc) and max(abs(a-b) for a,b in zip(tr,tc))<1e-9
    source, _=crossing(tr,gy)
    first, ix=crossing(tc,gc)
    status='censored_deadline_missed' if first is None and t[-1]>=source else 'censored_unresolved' if first is None else 'within_window' if source-5<=first<=source else 'too_early' if first<source-5 else 'after_source_deadline'
    ups=None if first is None else sum(gc[j-1]<1<=gc[j] and tr[j]>=first for j in range(1,len(gc)))
    return {'run':run,'rmse_C':math.sqrt(sum((a-b)**2 for a,b in zip(cand,y))/len(y)),
            'source_event_min':source,'first_event_min':first,'source_lead_min':source-first if first is not None else None,
            'status':status,'recrossings':ups,'raw_source_sha256':digest}


def close(left,right,name):
    if left is None or right is None:
        assert left is right,(name,left,right)
    else:assert abs(left-right)<1e-7,(name,left,right)

def main():
    r=[]
    with open(ROOT/'oracle_K7_witnesses.csv',newline='') as f:
        w=list(csv.DictReader(f))
    knots=[float(row['candidate_knot_C']) for row in w]
    for name in ['K7_all_six_train_MSE_oracle','K7_all_six_all_six_MSE_oracle']:
        heights=[float(row[name+'_source_knot_C']) for row in w]
        exp=REF[name]['run_replay']
        for e in exp:
            got=scored(e['run'],knots,heights)
            for col in ('rmse_C','source_event_min','first_event_min','source_lead_min'):
                close(got[col],e[col],name+':'+str(e['run'])+':'+col)
            for col in ('status','recrossings'):
                assert got[col]==e[col],(name,e['run'],col)
            r.append({'model':name,**got})
    (ROOT/'independent_replay.json').write_text(json.dumps({'result':'PASS','comparisons':len(r)*6,'native_run_model_rows':len(r),'results':r},indent=2,allow_nan=False)+'\n')
    print('INDEPENDENT NATIVE CSV REPLAY PASS,',len(r),'policy/run rows, numeric/status metrics checked')

if __name__=='__main__':main()
