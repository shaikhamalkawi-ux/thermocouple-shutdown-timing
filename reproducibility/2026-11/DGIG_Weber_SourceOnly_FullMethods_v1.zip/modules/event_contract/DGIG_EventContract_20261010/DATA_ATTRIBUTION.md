# Original data attribution

Anika Weber, Sebastian Schürg, Timo Roeder, Johannes Grobbel, Martina Neises-von Puttkamer, and Christian Sattler.
**Experimental study of heating and cooling of a shallow packed bed suspected to air temperatures between 300 and 773 K.** Mendeley Data, Version 2, published 22 April 2025.
DOI: https://doi.org/10.17632/3pp86gdvh4.2
Official record: https://data.mendeley.com/datasets/3pp86gdvh4/2
License displayed by the official record: Creative Commons Attribution 4.0 International (CC BY 4.0), https://creativecommons.org/licenses/by/4.0/.

The official title includes “suspected”; it is preserved verbatim. The study authors are the creators of the experimental measurements; the present package contains a secondary computational analysis, not new laboratory measurements or endorsement by those creators.

## Original measurement bytes

`inputs/compact/DGIG_WEBER_CORE_PRIMARY_A_tests4_6.zip` and `inputs/compact/DGIG_WEBER_CORE_PRIMARY_B_tests7_9.zip` are the previously prepared compact source containers. Native MeasurementData.CSV bytes for Tests 4–9 remain unchanged. Checksums, row counts and source-member names are in `results/source_provenance.csv`; each replay checks all six hashes. Cropping to the analysis interval, lagged interpolation, calibration and event extraction are computed in memory and do not modify native CSV files.

## Prior DGIG-derived inputs

`K5_knots.csv`, `K7_knots.csv` and `baseline_D50_results.csv` preserve the existing training-only knot grids / temperature fits and prior results for baseline comparison. These are prior DGIG calculations, not experimental measurements. New optimized knot heights are clearly separated in `results/`.

## Rights of new material

No public code-license or authorship approval is selected by this research step. This delivery is for author examination and reproducibility; public repository release requires the project's normal approval. The source-data CC BY 4.0 notice is not an assertion that all new code has been licensed identically.
