from common import *
from train_contract import constraints
from scipy.optimize import minimize,nnls
import numpy as np

def solve_qp(runs,K,eta):
 d=pd.read_csv(INPUT/f'K{K}_knots.csv');knots=d.candidate_knot_C.to_numpy();base=d.fitted_source_C.to_numpy()
 B=np.vstack([hat(runs[r]['x'],knots) for r in TRAIN]);y=np.concatenate([runs[r]['y'] for r in TRAIN]);w=np.concatenate([np.full(len(runs[r]['t']),1/(4*len(runs[r]['t']))) for r in TRAIN])
 Q=B.T@(w[:,None]*B);c=B.T@(w*y);h0=np.linalg.solve(Q,c);floor=float(np.sum(w*(B@h0-y)**2))
 A,b,meta=constraints(runs,knots);b=b-eta*A[:,-1];A=A[:,:K]
 A=np.vstack([A,np.eye(K),-np.eye(K)]);b=np.r_[b,np.full(K,550.),np.zeros(K)]
 # Cut-plane SLSQP then analytical primal-dual active-set polishing.
 idx=set(np.flatnonzero(A@base>b+1e-9).tolist());x=base.copy()
 for iteration in range(40):
  ix=sorted(idx);AA=A[ix];bb=b[ix]
  def fun(h):v=h-h0;return float(v@Q@v)
  def jac(h):return 2*Q@(h-h0)
  res=minimize(fun,x,jac=jac,method='SLSQP',constraints=[{'type':'ineq','fun':lambda h:bb-AA@h,'jac':lambda h:-AA}],options={'maxiter':2000,'ftol':1e-12})
  x=res.x;viol=A@x-b;bad=np.flatnonzero(viol>1e-8)
  if not len(bad):break
  n=len(idx);idx.update(bad.tolist())
  if len(idx)==n:break
 near=np.flatnonzero(b-A@x<1e-5)
 weights,residual=nnls(A[near].T,-jac(x))
 act=[int(near[i]) for i in range(len(near)) if weights[i]>1e-8]
 # Remove linear dependence among active rows if necessary.
 keep=[]
 for j in act:
  if np.linalg.matrix_rank(A[keep+[j]],tol=1e-10)>len(keep):keep.append(j)
 act=keep
 for it in range(40):
  AA=A[act];bb=b[act]
  kkt=np.block([[2*Q,AA.T],[AA,np.zeros((len(act),len(act)))]])
  sol=np.linalg.solve(kkt,np.r_[2*c,bb]);xx=sol[:K];lam=sol[K:]
  vv=A@xx-b
  if np.min(lam,initial=0)<-1e-6:
   del act[int(np.argmin(lam))];continue
  if np.max(vv)>1e-7:
   j=int(np.argmax(vv))
   if j in act:raise RuntimeError('precision violation')
   act.append(j);continue
  x=xx;break
 maxviol=float(np.max(A@x-b));station=float(np.max(np.abs(jac(x)+A[act].T@lam)))
 if maxviol>2e-7 or station>2e-7 or np.min(lam,initial=0)<-2e-7:raise RuntimeError((maxviol,station,lam))
 out={'K':K,'eta':eta,'MSE':floor+fun(x),'RMSE':float(np.sqrt(floor+fun(x))),'maximum_constraint_violation':maxviol,'stationarity_residual':station,'minimum_multiplier':float(np.min(lam,initial=0)),'active_rows':act,'active_multipliers':lam.tolist(),'hessian_min_eigenvalue':float(np.linalg.eigvalsh(2*Q)[0]),'slsqp_success':bool(res.success),'slsqp_message':res.message,'kkt_polish_iterations':it+1}
 return knots,x,out

if __name__=='__main__':
 runs=load_runs();allrec=[]
 for K in (5,7):
  rec=json.loads((OUT/f'K{K}_training_diagnostics.json').read_text());eta=rec['LP_max_eta']
  settings=[('max_margin_screen',eta-1e-9)]
  if eta>1e-6:settings.extend([('min_MSE_contract',1e-6),('max_margin_50pct',eta-1e-9)])
  for name,margin in settings:
   k,x,d=solve_qp(runs,K,margin);d['policy']=name;d['admitted_for_event_contract']=bool(margin>0)
   if name=='max_margin_50pct' and d['MSE']>.25*rec['identity_mse']+1e-5:raise RuntimeError('Requires separate QCQP branch; not silently admitted')
   pd.DataFrame({'candidate_knot_C':k,'predicted_source_knot_C':x}).to_csv(OUT/f'K{K}_{name}_knots.csv',index=False,float_format='%.17g')
   allrec.append(d);print(json.dumps(d),flush=True)
 dump(OUT/'QP_KKT_CERTIFICATES.json',allrec)
 files=sorted(list(OUT.glob('*knots.csv'))+list(OUT.glob('*training_diagnostics.json'))+[OUT/'QP_KKT_CERTIFICATES.json'])
 dump(OUT/'TRAINING_FREEZE.json',{'utc':utc(),'files':{p.name:sha(p) for p in files},'D50_new_outcomes_evaluated':False,'protocol_sha':sha(ROOT/'PROTOCOL.md'),'addendum_sha':sha(ROOT/'PROTOCOL_NUMERICAL_ADDENDUM.md')})
