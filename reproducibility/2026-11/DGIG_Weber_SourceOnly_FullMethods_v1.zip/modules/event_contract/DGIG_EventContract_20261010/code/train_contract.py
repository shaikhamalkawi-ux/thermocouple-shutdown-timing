"""Same frozen knots, different objective: temperature fit vs event contract.
This script never evaluates Tests 5 or 9. Run evaluate_contract.py separately
only after models and training diagnostics have been frozen.
"""
from common import *
from scipy.optimize import linprog,minimize,nnls
import scipy,sys,time

def constraints(runs,knots):
 Crows=[];b=[];meta=[]
 for run in TRAIN:
  r=runs[run];t,x,y=r['t'],r['x'],r['y'];B=hat(x,knots);tt,C=gradient(t,B);_,sy=gradient(t,y)
  U=event(tt,sy);L=U-5
  for i in np.flatnonzero(tt<=L):
   Crows.append(np.r_[-C[i],1.]);b.append(-1.)
   meta.append(dict(kind='no_early',run=run,time=float(tt[i]),index=int(i)))
  Crows.append(np.r_[-interp_vec(tt,C,L),1]);b.append(-1.)
  meta.append(dict(kind='no_early_boundary',run=run,time=L))
  Crows.append(np.r_[interp_vec(tt,C,U),1]);b.append(1.)
  meta.append(dict(kind='by_deadline',run=run,time=U))
 for j in range(len(knots)-1):
  v=np.zeros(len(knots)+1);v[j]=1;v[j+1]=-1
  Crows.append(v);b.append(0.);meta.append(dict(kind='monotonicity',knot=j))
 return np.asarray(Crows),np.asarray(b),meta

def fit_k(K,runs):
 start=time.perf_counter();d=pd.read_csv(INPUT/f'K{K}_knots.csv');knots=d.candidate_knot_C.to_numpy();base=d.fitted_source_C.to_numpy()
 B=np.vstack([hat(runs[r]['x'],knots) for r in TRAIN]);y=np.concatenate([runs[r]['y'] for r in TRAIN]);w=np.concatenate([np.full(len(runs[r]['t']),1/(4*len(runs[r]['t']))) for r in TRAIN])
 Q=B.T@(w[:,None]*B);c=B.T@(w*y);y2=float(w@(y*y))
 # Center objective at least-squares solution for numerically stable MSE.
 h_ls=np.linalg.solve(Q,c);mse_floor=float(np.sum(w*(B@h_ls-y)**2))
 def mse(h):v=h-h_ls;return float(v@Q@v+mse_floor)
 def mse_jac(h):return 2*Q@(h-h_ls)
 ident_mse=float(np.mean([np.mean((runs[r]['x']-runs[r]['y'])**2) for r in TRAIN]))
 A,b,meta=constraints(runs,knots);obj=np.r_[np.zeros(K),-1.]
 lp=linprog(obj,A_ub=A,b_ub=b,bounds=[(0,550)]*K+[(None,None)],method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9})
 if not lp.success:raise RuntimeError(lp.message)
 # HiGHS <= multipliers use nonpositive convention for minimization.
 stat=obj - A.T@lp.ineqlin.marginals-lp.lower.marginals-lp.upper.marginals
 dual_bound=float(b@lp.ineqlin.marginals+550*np.sum(lp.upper.marginals[:K]))
 rec={'K':K,'constraints':len(b),'base_mse':mse(base),'identity_mse':ident_mse,'LP_max_eta':float(lp.x[-1]),'LP_max_violation':float(np.max(A@lp.x-b)),'LP_stationarity_residual':float(np.max(abs(stat))),'LP_primal_objective':float(obj@lp.x),'LP_dual_objective':dual_bound,'LP_gap':float(obj@lp.x-dual_bound),'policies':[]}
 np.savez_compressed(OUT/f'K{K}_contract_matrix.npz',A=A,b=b,knots=knots,Q=Q,c=c,y2=y2,lp_primal=lp.x,lp_dual=lp.ineqlin.marginals,lp_lower=lp.lower.marginals,lp_upper=lp.upper.marginals)
 active=np.flatnonzero(abs(lp.ineqlin.marginals)>1e-9)
 dump(OUT/f'K{K}_LP_active_certificate.json',{'rows':[dict(constraint_row=int(i),multiplier=float(lp.ineqlin.marginals[i]),residual=float(A[i]@lp.x-b[i]),**meta[i]) for i in active],**{k:v for k,v in rec.items() if k!='policies'}})
 # Always retain the frozen temperature baseline and the unconstrained max-margin screen result.
 policies={'temperature_only':base,'max_margin_screen':lp.x[:K]}
 rec['policies'].append({'name':'max_margin_screen','eta':float(lp.x[-1]),'training_mse':mse(lp.x[:K]),'constraint_valid':bool(lp.x[-1]>0)})
 if lp.x[-1] >= 1e-6:
  # QP via exchange algorithm; every candidate is checked against all constraints.
  A0=A[:,:K];b0=b-1e-6*A[:,-1]
  x=base.copy();idx=set(np.flatnonzero(A0@x>b0+1e-9).tolist());idx.update(range(len(b)-K+1,len(b)))
  for iteration in range(50):
   ix=sorted(idx);aa=A0[ix];bb=b0[ix]
   fit=minimize(lambda h:mse(h)/1000,x,jac=lambda h:mse_jac(h)/1000,method='SLSQP',bounds=[(0,550)]*K,constraints=[{'type':'ineq','fun':lambda h:bb-aa@h,'jac':lambda h:-aa}],options={'maxiter':2000,'ftol':1e-13})
   x=fit.x;viol=A0@x-b0;bad=np.flatnonzero(viol>2e-8)
   if not len(bad):break
   before=len(idx);idx.update(bad.tolist())
   if len(idx)==before:break
  valid=bool(np.max(viol)<2e-7)
  activeq=np.flatnonzero(b0-A0@x<1e-6)
  # include bounds into KKT residual check
  M=A0[activeq].T
  lam,res=nnls(M,-mse_jac(x)) if M.size else (np.array([]),np.linalg.norm(mse_jac(x)))
  rec['policies'].append({'name':'min_MSE_contract','eta':1e-6,'training_mse':mse(x),'max_violation':float(max(viol)),'solver_success':bool(fit.success),'solver_message':fit.message,'stationarity_nnls_residual':float(res),'constraint_valid':valid,'iterations':iteration+1})
  if valid:policies['min_MSE_contract']=x
  # Maximize margin with the unchanged >=50% training RMSE reduction criterion.
  cap=.25*ident_mse
  if mse(x)<=cap and valid:
   z=np.r_[x,1e-6];idx=set(np.flatnonzero(abs(A@z-b)<1e-5).tolist());idx.update(range(len(b)-K+1,len(b)))
   for iteration in range(60):
    ix=sorted(idx);aa=A[ix];bb=b[ix]
    con=[{'type':'ineq','fun':lambda z:bb-aa@z,'jac':lambda z:-aa},{'type':'ineq','fun':lambda z:(cap-mse(z[:K]))/cap,'jac':lambda z:np.r_[-mse_jac(z[:K])/cap,0.]}]
    so=minimize(lambda z:-z[-1],z,jac=lambda z:obj,method='SLSQP',bounds=[(0,550)]*K+[(1e-6,None)],constraints=con,options={'maxiter':2000,'ftol':1e-12})
    z=so.x;viol=A@z-b;bad=np.flatnonzero(viol>2e-8)
    if not len(bad):break
    before=len(idx);idx.update(bad.tolist())
    if len(idx)==before:break
   valid=bool(max(viol)<2e-7 and mse(z[:K])<=cap+1e-5)
   aq=np.flatnonzero(b-A@z<1e-6);M=np.column_stack([A[aq].T,np.r_[mse_jac(z[:K]),0.]])
   _,res=nnls(M,-obj)
   rec['policies'].append({'name':'max_margin_50pct','eta':float(z[-1]),'training_mse':mse(z[:K]),'MSE_cap':cap,'max_violation':float(max(viol)),'solver_success':bool(so.success),'solver_message':so.message,'stationarity_nnls_residual':float(res),'constraint_valid':valid,'iterations':iteration+1})
   if valid:policies['max_margin_50pct']=z[:K]
  else:rec['policies'].append({'name':'max_margin_50pct','status':'not_feasible_with_minimum_contract_temperature_error'})
 else:rec['policies'].append({'name':'min_MSE_contract','status':'LP_proves_sufficient_contract_infeasible_at_positive_eta'})
 for name,h in policies.items():
  pd.DataFrame({'candidate_knot_C':knots,'predicted_source_knot_C':h}).to_csv(OUT/f'K{K}_{name}_knots.csv',index=False,float_format='%.17g')
 rec['runtime_s']=time.perf_counter()-start
 dump(OUT/f'K{K}_training_diagnostics.json',rec)
 print(json.dumps(rec,indent=2),flush=True)
 return rec
if __name__=='__main__':
 runs=load_runs(strict=True,write_provenance=True)
 recs=[fit_k(k,runs) for k in (5,7)]
 files=sorted(list(OUT.glob('*knots.csv'))+list(OUT.glob('*training_diagnostics.json')))
 freeze={'utc':utc(),'files':{p.name:sha(p) for p in files},'D50_new_outcomes_evaluated':False,'protocol_sha':sha(ROOT/'PROTOCOL.md')}
 dump(OUT/'TRAINING_FREEZE.json',freeze)
