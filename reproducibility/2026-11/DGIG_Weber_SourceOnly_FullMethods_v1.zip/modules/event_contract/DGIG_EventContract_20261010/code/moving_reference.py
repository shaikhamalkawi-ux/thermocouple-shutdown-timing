"""Continuum drift analysis, not a sampled-noise robustness experiment.
Enumerates every first-crossing threshold branch of the finite observed trace.
Source and candidate drift independently, but each drift is temporally coherent.
"""
from common import *
from dataclasses import dataclass,asdict
from math import inf
import time
@dataclass(frozen=True)
class Band:
 lo:float; hi:float; lc:bool=True; hc:bool=True
 def good(self):return self.lo<self.hi or (self.lo==self.hi and self.lc and self.hc)
 def has(self,q):return (q>self.lo or (q==self.lo and self.lc)) and (q<self.hi or (q==self.hi and self.hc))
def meet(a,b):
 lo=max(a.lo,b.lo);hi=min(a.hi,b.hi)
 z=Band(lo,hi,(a.lo!=lo or a.lc)and(b.lo!=lo or b.lc),(a.hi!=hi or a.hc)and(b.hi!=hi or b.hc))
 return z if z.good() else None
def minus(a,b):
 x=meet(a,b)
 if x is None:return [a]
 return [z for z in [Band(a.lo,x.lo,a.lc,not x.lc),Band(x.hi,a.hi,not x.hc,a.hc)] if z.good()]
def merge(seq):
 out=[]
 for x in sorted((s for s in seq if s.good()),key=lambda z:(z.lo,not z.lc)):
  if not out:out.append(x);continue
  p=out[-1]
  if x.lo<p.hi or (x.lo==p.hi and (p.hc or x.lc)):
   hi=max(p.hi,x.hi);hc=(p.hi==hi and p.hc)or(x.hi==hi and x.hc)
   out[-1]=Band(p.lo,hi,p.lc,hc)
  else:out.append(x)
 return out
def meet_sets(a,b):return merge([x for i in a for j in b if (x:=meet(i,j))is not None])
@dataclass(frozen=True)
class Piece:
 band:Band; index:int; t0:float; g0:float; slope:float
 def time(self,q):return self.t0+self.slope*(q-self.g0)
def inverse(tt,g):
 visited=[];out=[]
 for i in np.flatnonzero(np.diff(g)<0):
  base=meet(Band(float(g[i+1]),float(g[i]),False,True),Band(0,inf,False,False))
  if base is None:continue
  parts=[base]
  for used in visited:
   parts=[s for a in parts for s in minus(a,used)]
   if not parts:break
  for b in parts:out.append(Piece(b,int(i),float(tt[i]),float(g[i]),float((tt[i+1]-tt[i])/(g[i+1]-g[i]))))
  visited=merge(visited+[base])
 return out

def envelope(pieces,qband):
 hits=[]
 for p in pieces:
  z=meet(p.band,qband)
  if z is not None:hits.append((p,z))
 cover=merge([z for _,z in hits]);missing=[qband]
 for b in cover:missing=[x for a in missing for x in minus(a,b)]
 if missing:return {'observed_for_all':False,'missing':[asdict(x) for x in missing]}
 extrem=[]
 for p,b in hits:
  extrem.extend([(p.time(b.lo),b.lo,p.index,b.lc),(p.time(b.hi),b.hi,p.index,b.hc)])
 low=min(extrem);high=max(extrem)
 return {'observed_for_all':True,'minimum':low[0],'maximum':high[0],'min_threshold':low[1],'max_threshold':high[1],'min_segment':low[2],'max_segment':high[2],'min_attained':low[3],'max_attained':high[3],'intersected_branches':len(hits)}

def feasible(pieces,L,U):
 if L>U:return []
 out=[]
 for p in pieces:
  lo=p.g0+(U-p.t0)/p.slope;hi=p.g0+(L-p.t0)/p.slope
  b=meet(p.band,Band(lo,hi))
  if b is not None:out.append(b)
 return merge(out)

def robust(records,rho,source_moving=True):
 per=[];joint=[Band(rho,inf,False,False)]
 for r in sorted(records):
  d=records[r]
  sb=Band(1-rho,1+rho) if source_moving else Band(1,1)
  e=envelope(d['source_pieces'],sb)
  if not e['observed_for_all']:
   per.append(dict(run=r,source=e,bands=[]));joint=[];continue
  L=e['maximum']-5;U=e['minimum']
  unpert=feasible(d['candidate_pieces'],L,U)
  eroded=merge([Band(b.lo+rho,b.hi-rho,b.lc,b.hc) for b in unpert])
  joint=meet_sets(joint,eroded)
  per.append(dict(run=r,source=e,common_time_lower=L,common_time_upper=U,bands=[asdict(b) for b in eroded]))
 return joint,per

def prepare_records(runs):
 rec={}
 for r,d in runs.items():
  tt,gs=gradient(d['t'],d['y']);_,gc=gradient(d['t'],d['x'])
  rec[r]=dict(source_pieces=inverse(tt,gs),candidate_pieces=inverse(tt,gc),tt=tt,gs=gs,gc=gc,raw=d)
 return rec

def main():
 tic=time.perf_counter();runs=load_runs(strict=False);records=prepare_records(runs);results=[]
 nominal,details=robust(records,0,True)
 assert len(nominal)==1
 assert abs(nominal[0].lo-.64982146)<1e-7 and abs(nominal[0].hi-.65177026)<1e-7
 for moving in [False,True]:
  low=0.;high=.05
  assert not robust(records,high,moving)[0]
  for _ in range(65):
   mid=(low+high)/2
   if robust(records,mid,moving)[0]:low=mid
   else:high=mid
  # Verified interior and outside probes do not masquerade as exact floating boundary.
  pass_r=max(0,low-1e-9);fail_r=high+1e-9
  bands,p=robust(records,pass_r,moving);failed,fp=robust(records,fail_r,moving)
  assert bands and not failed
  best=max(bands,key=lambda b:b.hi-b.lo);theta=(best.lo+best.hi)/2
  row=dict(source_moving=moving,numerical_lower_rho=low,numerical_upper_rho=high,interior_rho=pass_r,exterior_rho=fail_r,witness_theta=theta,interior_bands=[asdict(b) for b in bands],interior_per_run=p,exterior_per_run=fp)
  results.append(row)
  print(json.dumps({k:v for k,v in row.items() if 'per_run'not in k},indent=2),flush=True)
 # Exploratory source/candidate drift witnesses verify mapping at every relevant branch endpoint/interior.
 witness=[]
 for spec in results:
  for rec in spec['interior_per_run']:
   r=rec['run'];d=records[r];raw=d['raw'];rho=spec['interior_rho'];theta=spec['witness_theta']
   source_thresholds=[1.] if not spec['source_moving'] else [1-rho,1+rho,rec['source']['min_threshold'],rec['source']['max_threshold']]
   for q in source_thresholds:
    if not spec['source_moving']:ds=0.
    else:ds=1-q
    gyraw=raw['y']+ds*(raw['t']-raw['start']);tt,gs=gradient(raw['t'],gyraw);U=event(tt,gs,1.)
    for dc in (-rho,0.,rho):
     gxraw=raw['x']+dc*(raw['t']-raw['start']);_,gc=gradient(raw['t'],gxraw);T=event(tt,gc,theta)
     okay=bool(T is not None and U is not None and U-5-2e-8<=T<=U+2e-8)
     witness.append(dict(source_moving=spec['source_moving'],run=r,rho=rho,theta=theta,source_drift=ds,candidate_drift=dc,source_event=U,candidate_event=T,lead=None if T is None or U is None else U-T,pass_check=okay))
 assert all(w['pass_check'] for w in witness)
 pd.DataFrame(witness).to_csv(OUT/'moving_reference_raw_witnesses.csv',index=False,float_format='%.17g')
 dump(OUT/'moving_reference_continuum_results.json',{'nominal_band':[asdict(b) for b in nominal],'cases':results,'runtime_s':time.perf_counter()-tic,'raw_witness_count':len(witness),'all_raw_witnesses_pass':True,'scope':'Deterministic independent temperature drifts; not physical uncertainty coverage. Boundaries numerical; exact-input local verification separate.'})
 # Save every breakpoint representation so a checker need not trust narrative or just two endpoints.
 pp=[]
 for r,d in records.items():
  for channel in ['source','candidate']:
   for p in d[channel+'_pieces']:
    pp.append(dict(run=r,channel=channel,segment=p.index,lo=p.band.lo,hi=p.band.hi,lc=p.band.lc,hc=p.band.hc,time_origin=p.t0,gradient_origin=p.g0,inverse_slope=p.slope))
 pd.DataFrame(pp).to_csv(OUT/'first_crossing_threshold_branches.csv',index=False,float_format='%.17g')
if __name__=='__main__':main()
