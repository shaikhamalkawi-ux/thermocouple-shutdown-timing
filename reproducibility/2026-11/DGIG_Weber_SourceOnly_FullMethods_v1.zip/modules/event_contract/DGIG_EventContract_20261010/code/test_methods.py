import unittest
from fractions import Fraction
import numpy as np
from common import gradient,event,hat,interp_vec
from moving_reference import Band,meet,minus,merge,inverse,envelope,feasible
class MethodsTests(unittest.TestCase):
 def test_lag_interpolation_linear_signal(self):
  t=np.array([0.,.7,1.3,8.,15.,15.9,24.,31.]);tt,g=gradient(t,2*t+7)
  np.testing.assert_allclose(g,2,rtol=0,atol=1e-14)
 def test_constant_bias_cancels(self):
  t=np.arange(100)/2;y=100*(1-np.exp(-t/10));_,a=gradient(t,y);_,b=gradient(t,y+70)
  np.testing.assert_allclose(a,b,rtol=0,atol=3e-15)
 def test_linear_drift_identity(self):
  t=np.arange(100)/2;y=100*(1-np.exp(-t/10));d=.002
  _,a=gradient(t,y);_,b=gradient(t,y+23+d*t)
  np.testing.assert_allclose(b-a,d,rtol=0,atol=3e-15)
 def test_mapping_gradient_linearity(self):
  t=np.arange(101)*.5;x=np.sqrt(t)*8;k=np.array([0,10,20,40,60]);h=np.array([0,3,10,20,50]);B=hat(x,k)
  tt,C=gradient(t,B);_,g=gradient(t,B@h);np.testing.assert_allclose(C@h,g,rtol=0,atol=5e-15)
 def test_initial_below_needs_arming(self):
  self.assertIsNone(event(np.arange(4.),np.array([.3,.4,.6,.2])))
 def test_later_arming_valid(self):
  self.assertAlmostEqual(event(np.arange(4.),np.array([.3,2,3,0])),2+2/3)
 def test_strict_equality_not_alone_crossing(self):
  self.assertIsNone(event(np.arange(3.),np.array([2.,1.,1.])))
 def test_contract_is_sufficient(self):
  t=np.array([0.,1.,2.,3.,4.]);g=np.array([2.,1.2,1.1,.9,.6]);L=2.;U=3.
  z=event(t,g);self.assertTrue(L<=z<=U)
 def test_contract_not_necessary(self):
  # A first crossing can be in the window and then recross before the deadline.
  t=np.arange(5.);g=np.array([2,2,.5,2,3]);z=event(t,g)
  self.assertTrue(1<=z<=3);self.assertGreater(np.interp(3,t,g),1)
 def test_inverse_complete_on_nonmonotone_fixture(self):
  t=np.arange(7.);g=np.array([.3,2,1,3,.5,2,0]);p=inverse(t,g)
  for q in np.r_[np.linspace(.01,2.99,301),[.3,2,1,3,.5]]:
   z=event(t,g,q);hits=[a.time(q)for a in p if a.band.has(q)]
   self.assertEqual(len(hits),0 if z is None else 1)
   if z is not None:self.assertAlmostEqual(hits[0],z)
 def test_source_envelope_detects_nonobservability(self):
  p=inverse(np.arange(3.),np.array([3,2,1.]));self.assertFalse(envelope(p,Band(.9,1.1))['observed_for_all'])
 def test_band_endpoint_semantics(self):
  self.assertIsNone(meet(Band(0,1,True,False),Band(1,2)))
  self.assertEqual(len(minus(Band(0,2),Band(0,1,False,True))),2)
 def test_shared_first_crossing_time_erosion(self):
  p=inverse(np.arange(3.),np.array([3.,2.,1.]));e=envelope(p,Band(1.2,1.8));self.assertAlmostEqual(e['minimum'],1.2);self.assertAlmostEqual(e['maximum'],1.8)
 def test_two_row_obstruction(self):
  a=Fraction(2,3);b=Fraction(3,4);upper=(a-b)/(a+b);self.assertLess(upper,0)
if __name__=='__main__':unittest.main(verbosity=2)
