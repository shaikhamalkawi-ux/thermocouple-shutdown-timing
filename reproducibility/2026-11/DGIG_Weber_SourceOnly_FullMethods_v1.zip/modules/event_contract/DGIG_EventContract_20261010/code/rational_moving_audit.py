"""Exact native-decimal, running-minimum checker for the drift continuum.
This independently checks the reported interior/nonexistence brackets. It does
not import the floating inverse-piece implementation.
"""
from independent_raw_audit import read_raw,grad,first,ROOT,OUT,QA,F
from pathlib import Path
import csv,json,zipfile,io
from dataclasses import dataclass
@dataclass(frozen=True)
class I:
 lo:F;hi:F;lc:bool=False;hc:bool=True
 def good(self):return self.lo<self.hi or (self.lo==self.hi and self.lc and self.hc)
def intersection(a,b):
 lo=max(a.lo,b.lo);hi=min(a.hi,b.hi)
 x=I(lo,hi,(a.lo!=lo or a.lc)and(b.lo!=lo or b.lc),(a.hi!=hi or a.hc)and(b.hi!=hi or b.hc))
 return x if x.good() else None
def merged(a):
 out=[]
 for x in sorted((i for i in a if i.good()),key=lambda z:(z.lo,not z.lc)):
  if not out:out.append(x);continue
  p=out[-1]
  if x.lo<p.hi or (x.lo==p.hi and(x.lc or p.hc)):
   hi=max(p.hi,x.hi);out[-1]=I(p.lo,hi,p.lc,(p.hi==hi and p.hc)or(x.hi==hi and x.hc))
  else:out.append(x)
 return out
def sect(a,b):return merged([c for x in a for y in b if(c:=intersection(x,y))is not None])
def minima_pieces(t,g):
 # Exact earliest-passage representation for thresholds <= first value.
 floor=g[0];out=[]
 for j in range(1,len(g)):
  if g[j]<floor:
   b=I(g[j],floor,False,True);i=j-1
   out.append((b,t[i],g[i],(t[j]-t[i])/(g[j]-g[i])))
   floor=g[j]
 return out

def env(p,q):
 pieces=[(x,t,g,s) for b,t,g,s in p if(x:=intersection(b,q))is not None]
 cover=merged([x for x,*_ in pieces]);assert len(cover)==1 and cover[0]==q,'incomplete reference observability'
 ends=[t+s*(v-g) for b,t,g,s in pieces for v in(b.lo,b.hi)]
 return min(ends),max(ends)
def valid(p,L,U):
 if L>U:return []
 return merged([x for b,t,g,s in p if(x:=intersection(b,I(g+(U-t)/s,g+(L-t)/s,True,True)))is not None])
def read_inclusive():
 # Separate native string parser with original exact action sample retained.
 raw=read_raw()
 for zp in sorted((ROOT/'inputs/compact').glob('*PRIMARY*.zip')):
  with zipfile.ZipFile(zp)as z:
   for name in z.namelist():
    if not name.endswith('MeasurementData.CSV'):continue
    r=int(Path(name).parent.name.split('_')[0]);rows=list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8-sig')),delimiter=';'))
    t,x,y=raw[r];last=t[-1]
    for k,row in enumerate(rows):
     if F(row['Time since Start [min]'].replace(',','.'))==last:
      q=rows[k+1];t.append(F(q['Time since Start [min]'].replace(',','.')));x.append(F(q['TR404-085d'].replace(',','.')));y.append(F(q['TR404-108e'].replace(',','.')));break
 return raw

def run():
 raw=read_inclusive();records={}
 for r,(t,x,y)in raw.items():
  tt,gs=grad(t,y);_,gc=grad(t,x);U=first(tt,gs)
  # Thresholds greater than initial candidate gradient cannot produce a first
  # crossing in the late acceptance window: all later gradients are lower,
  # whereas their only possible arming peaks occur before that window.
  assert max(gc[i] for i,q in enumerate(tt) if q>=U-6)<gc[0]
  assert max(gs[i] for i,q in enumerate(tt) if q>=U-6)<gs[0]
  assert min(gs[0],gc[0])>F('1.05')
  records[r]=(minima_pieces(tt,gs),minima_pieces(tt,gc),gs[0],gc[0])
 cases=json.loads((OUT/'moving_reference_continuum_results.json').read_text())['cases'];audit=[]
 for case in cases:
  moving=case['source_moving']
  for name in ['interior_rho','exterior_rho']:
   rho=F(str(case[name]));joint=None;per=[]
   for r,(ps,pc,gfirst_s,gfirst_c)in sorted(records.items()):
    smin,smax=env(ps,I(1-rho if moving else F(1),1+rho if moving else F(1),True,True))
    bands=valid(pc,smax-5,smin)
    erode=merged([I(b.lo+rho,b.hi-rho,b.lc,b.hc)for b in bands])
    joint=erode if joint is None else sect(joint,erode)
    per.append({'run':r,'source_min_exact':str(smin),'source_max_exact':str(smax),'bands': [{'lo':str(b.lo),'hi':str(b.hi),'lc':b.lc,'hc':b.hc}for b in erode]})
   okay=bool(joint)
   assert okay==(name=='interior_rho')
   if okay:
    theta=F(str(case['witness_theta']))
    assert any((theta>b.lo or(theta==b.lo and b.lc))and(theta<b.hi or(theta==b.hi and b.hc))for b in joint)
   audit.append({'source_moving':moving,'kind':name,'rho_exact':str(rho),'feasible':okay,'bands':[{'lo':str(b.lo),'hi':str(b.hi),'lc':b.lc,'hc':b.hc}for b in joint],'per_run':per})
 (QA/'EXACT_MOVING_REFERENCE_AUDIT.json').write_text(json.dumps({'all_four_bracket_checks_pass':True,'arithmetic':'Fractions parsed from native decimal measurements and timestamps','scope':'Specified independent linear temperature drift; neither random-noise coverage nor physical sensor uncertainty','checks':audit},indent=2))
 print('EXACT CONTINUUM CHECK: fixed/moving-source feasible interior and infeasible exterior all PASS')
if __name__=='__main__':run()
