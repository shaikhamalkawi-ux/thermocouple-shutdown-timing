"""Independent csv/bisect/Fraction checker. Does not import analysis programs.
Float replay tests *every* archived policy/run. Rational certificates use exact
native decimal tokens and frozen knot/height decimal tokens, not an LP status.
This is another implementation, not an independent researcher or physical test.
"""
from pathlib import Path
from fractions import Fraction as F
from bisect import bisect_right,bisect_left
import csv,zipfile,io,json,hashlib,math,time
import numpy as np
ROOT=Path(__file__).resolve().parents[1];INPUT=ROOT/'inputs/compact';OUT=ROOT/'results';QA=ROOT/'verification'
TRAIN=(4,6,7,8)
def read_csv(p):
 with Path(p).open(newline='') as h:return list(csv.DictReader(h))
def fract(s):return F(s.replace(',','.'))
def read_raw():
 out={};provs={int(x['run']):x for x in read_csv(OUT/'source_provenance.csv')}
 for zp in sorted(INPUT.glob('*PRIMARY*.zip')):
  with zipfile.ZipFile(zp) as z:
   for member in z.namelist():
    if not member.endswith('MeasurementData.CSV'):continue
    raw=z.read(member);run=int(Path(member).parent.name.split('_')[0]);assert hashlib.sha256(raw).hexdigest()==provs[run]['sha256']
    rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig')),delimiter=';'))
    on=[fract(x['Heater_AO'])>F(9,2) for x in rows];segments=[];i=0
    while i<len(on):
     if not on[i]:i+=1;continue
     a=i
     while i<len(on) and on[i]:i+=1
     segments.append((a,i))
    a,b=max(segments,key=lambda v:v[1]-v[0]);assert b<len(rows)
    td=[fract(x['Time since Start [min]']) for x in rows[a:b]]
    xd=[fract(x['TR404-085d']) for x in rows[a:b]]
    yd=[fract(x['TR404-108e']) for x in rows[a:b]]
    out[run]=(td,xd,yd)
 return out

def linear(t,y,q):
 j=bisect_right(t,q)-1
 if j<0 or q>t[-1]:raise ValueError('outside domain')
 if t[j]==q:return y[j]
 return y[j]+(q-t[j])/(t[j+1]-t[j])*(y[j+1]-y[j])
def grad(t,y):
 i=bisect_left(t,t[0]+15);tt=t[i:]
 return tt,[(y[j]-linear(t,y,t[j]-15))/15 for j in range(i,len(t))]
def first(t,g,theta=1):
 for i in range(1,len(g)):
  if g[i-1]>=theta and g[i]<theta:
   return t[i-1]+(theta-g[i-1])/(g[i]-g[i-1])*(t[i]-t[i-1])
 return None
def mapping(x,k,h):
 if x<=k[0]:return h[0]
 if x>=k[-1]:return h[-1]
 return linear(k,h,x)
def g_at(t,y,q):
 tt,g=grad(t,y);return linear(tt,g,q)
def get_basis_grad(t,x,k,time):
 rows=[]
 for j in range(len(k)):
  h=[F(int(i==j)) for i in range(len(k))];mapped=[mapping(v,k,h) for v in x]
  rows.append(g_at(t,mapped,time))
 return rows

def main():
 tic=time.perf_counter();raw=read_raw();reported=read_csv(OUT/'decision_contract_all_run_results.csv');deltas=[]
 # Independently reconstructed float source values/events, no shared parser/gradient implementation.
 for row in reported:
  r=int(row['run']);K=int(row['K']);policy=row['policy'];td,xd,yd=raw[r]
  t=list(map(float,td));x=list(map(float,xd));y=list(map(float,yd))
  mod=read_csv(OUT/f'K{K}_{policy}_knots.csv');k=[float(z['candidate_knot_C']) for z in mod];h=[float(z['predicted_source_knot_C']) for z in mod]
  yp=[mapping(v,k,h) for v in x];tt,g=grad(t,yp);_,gs=grad(t,y);event=first(tt,g);source=first(tt,gs)
  rmse=math.sqrt(sum((a-b)**2 for a,b in zip(yp,y))/len(t));grmse=math.sqrt(sum((a-b)**2 for a,b in zip(g,gs))/len(g))
  up=None if event is None else sum(1 for i in range(1,len(g)) if tt[i]>=event and g[i-1]<1<=g[i])
  status='censored_deadline_missed' if event is None else ('within_window' if source-5<=event<=source else 'too_early' if event<source-5 else 'after_source_deadline')
  assert status==row['status'],(r,policy,status,row['status'])
  assert (event is None)==(row['first_event_min']==''),(r,policy)
  assert up== (None if row['recrossings']=='' else int(float(row['recrossings'])))
  checks={'rmse':abs(rmse-float(row['rmse_C'])),'gradient_rmse':abs(grmse-float(row['gradient_rmse_K_min'])),'source_event':abs(source-float(row['source_event_min'])),'event':0 if event is None else abs(event-float(row['first_event_min'])),'margin':abs(linear(tt,g,source)-float(row['gradient_at_source']))}
  assert max(checks.values())<2e-7,(r,policy,checks)
  deltas.append(dict(run=r,K=K,policy=policy,**checks,status_match=True,recrossing_match=True))
 print('Independent numeric replay',len(deltas),'rows passed',flush=True)
 # Exact native-decimal source events (all 4 training histories evaluated, not just named brackets).
 exact_source={}
 for r in TRAIN:
  t,x,y=raw[r];tt,g=grad(t,y);exact_source[r]=first(tt,g)
 # A two-row upper bound for every K5 height vector satisfying the specified contract.
 k=[fract(x['candidate_knot_C']) for x in read_csv(INPUT/'K5_knots.csv')]
 active=json.loads((OUT/'K5_LP_active_certificate.json').read_text())['rows']
 t6,x6,y6=raw[6];time6=F(str(next(z['time'] for z in active if z['run']==6)))
 assert time6<exact_source[6]-5
 c6=get_basis_grad(t6,x6,k,time6)
 t7,x7,y7=raw[7];c7=get_basis_grad(t7,x7,k,exact_source[7])
 assert all(z==0 for z in c6[:-2]+c7[:-2]);assert c6[-2]==-c6[-1] and c7[-2]==-c7[-1]
 a,b=c6[-1],c7[-1];assert b>a>0
 upper5=(a-b)/(a+b)
 proof5={'raw_decimal_exact':True,'a':str(a),'b':str(b),'a_decimal':float(a),'b_decimal':float(b),'eta_upper_exact':str(upper5),'eta_upper_decimal':float(upper5),'no_positive_margin_possible':bool(upper5<0),'proof':'a*(h4-h3)>=1+eta; b*(h4-h3)<=1-eta; a,b>0 and b>a imply eta<=(a-b)/(a+b)<0. This is for the stated sufficient contract, not all conceivable first-crossing maps.','test6_time_exact':str(time6),'test6_window_lower_exact':str(exact_source[6]-5),'test7_deadline_exact':str(exact_source[7])}
 print('Exact K5 upper',float(upper5),flush=True)
 # Exact K7 dual: deadline4, early7, last-increment nonnegativity.
 k7=[fract(x['candidate_knot_C']) for x in read_csv(INPUT/'K7_knots.csv')]
 active7=json.loads((OUT/'K7_LP_active_certificate.json').read_text())['rows']
 time7=F(str(next(z['time'] for z in active7 if z['kind']=='no_early')))
 v=get_basis_grad(*raw[4][:2],k7,exact_source[4]);w=[-z for z in get_basis_grad(*raw[7][:2],k7,time7)]
 assert all(z==0 for z in v[:4]+w[:4])
 l1=w[4]/(w[4]-v[4]);l2=1-l1;l3=-(l1*v[5]+l2*w[5]);assert min(l1,l2,l3)>0
 mono=[F(0)]*7;mono[5]=1;mono[6]=-1
 assert all(l1*v[j]+l2*w[j]+l3*mono[j]==0 for j in range(7))
 upper7=l1-l2
 proof7={'raw_decimal_exact':True,'multipliers':[str(l1),str(l2),str(l3)],'eta_upper_exact':str(upper7),'eta_upper_decimal':float(upper7),'positive_dual_multipliers':True,'exact_coefficient_cancellation':True,'training_scope':[4,6,7,8]}
 print('Exact K7 upper',float(upper7),flush=True)
 # Exact feasibility of all new positive-margin policies against the complete raw history.
 rational=[]
 for policy in ['min_MSE_contract','max_margin_50pct']:
  mod=read_csv(OUT/f'K7_{policy}_knots.csv');kk=[fract(z['candidate_knot_C']) for z in mod];hh=[fract(z['predicted_source_knot_C']) for z in mod]
  assert all(hh[i+1]>=hh[i] for i in range(6)) and min(hh)>=0 and max(hh)<=550
  for r in TRAIN:
   t,x,y=raw[r];pred=[mapping(z,kk,hh) for z in x];tt,g=grad(t,pred);U=exact_source[r];L=U-5
   early=[v-1 for q,v in zip(tt,g) if q<=L];early.append(linear(tt,g,L)-1);late=1-linear(tt,g,U)
   eta=min(min(early),late);assert eta>0
   event=first(tt,g);assert L<=event<=U
   rational.append(dict(policy=policy,run=r,exact_realized_margin=str(eta),margin_decimal=float(eta),event_exact=str(event),event_decimal=float(event),all_early_nodes_checked=len(early),passes=True))
  print('Exact full training contract',policy,'pass',flush=True)
 # All LP numerical dual residuals independently recomputed.
 lp=[]
 for K in [5,7]:
  d=np.load(OUT/f'K{K}_contract_matrix.npz');A,b=d['A'],d['b'];x,y=d['lp_primal'],d['lp_dual'];lower,upper=d['lp_lower'],d['lp_upper'];c=np.r_[np.zeros(K),-1.]
  sr=float(np.max(abs(c-A.T@y-lower-upper)));pv=float(max(0,np.max(A@x-b)))
  gap=float(abs(c@x-b@y-550*np.sum(upper[:K])));assert max(sr,pv,gap)<1e-8
  lp.append(dict(K=K,stationarity_residual=sr,primal_violation=pv,duality_gap=gap))
 with (QA/'independent_replay_differences.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(deltas[0]));w.writeheader();w.writerows(deltas)
 out={'independent_numeric_rows':len(deltas),'all_statuses_and_recrossings_match':True,'largest_numeric_discrepancy':max(max(d[x] for x in ['rmse','gradient_rmse','source_event','event','margin']) for d in deltas),'exact_K5_infeasibility_certificate':proof5,'exact_K7_margin_upper_certificate':proof7,'exact_positive_contract_checks':rational,'LP_primal_dual_checks':lp,'runtime_s':time.perf_counter()-tic,'not_an_external_human_review':True,'physical_uncertainty_certified':False}
 (QA/'INDEPENDENT_RAW_AUDIT.json').write_text(json.dumps(out,indent=2))
 print('AUDIT ALL PASS runtime',out['runtime_s'],flush=True)
if __name__=='__main__':main()
