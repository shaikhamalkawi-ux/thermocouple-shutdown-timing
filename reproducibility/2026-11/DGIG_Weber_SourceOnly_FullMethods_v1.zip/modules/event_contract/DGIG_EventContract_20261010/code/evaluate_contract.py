"""Evaluation only: verify frozen training hashes, then score without fitting."""
from common import *
if __name__=='__main__':
 freeze=json.loads((OUT/'TRAINING_FREEZE.json').read_text())
 for n,h in freeze['files'].items():
  if sha(OUT/n)!=h:raise ValueError('Frozen model changed: '+n)
 rows=[];runs=load_runs(strict=True)
 for p in sorted(OUT.glob('K*_knots.csv')):
  name=p.stem;K=int(name.split('_')[0][1:]);policy=name.split('_',1)[1].removesuffix('_knots')
  d=pd.read_csv(p,float_precision='round_trip');k=d.candidate_knot_C.to_numpy();h=d.predicted_source_knot_C.to_numpy()
  for r in sorted(runs):
   row=score(runs[r],k,h);row.update(K=K,policy=policy,partition='training' if r in TRAIN else 'held_out_D50',model_sha256=sha(p))
   rows.append(row)
 df=pd.DataFrame(rows)
 df.to_csv(OUT/'decision_contract_all_run_results.csv',index=False,float_format='%.17g')
 old=pd.read_csv(INPUT/'baseline_D50_results.csv')
 for r in TEST:
  for K in (5,7):
   a=old[(old.held_out_run==r)&(old.method==f'K{K}')].iloc[0]
   b=df[(df.run==r)&(df.K==K)&(df.policy=='temperature_only')].iloc[0]
   assert abs(float(a.rmse_C)-float(b.rmse_C))<1e-7
   assert pd.isna(a.crossing_min) and pd.isna(b.first_event_min)
 dump(OUT/'EVALUATION_RECEIPT.json',{'utc':utc(),'training_freeze_sha':sha(OUT/'TRAINING_FREEZE.json'),'new_results_sha':sha(OUT/'decision_contract_all_run_results.csv'),'baseline_D50_reproduction_pass':True,'rows':len(rows)})
 print(df[df.partition=='held_out_D50'][['K','policy','run','rmse_C','gradient_rmse_K_min','source_lead_min','status','recrossings','gradient_at_source','out_of_support']].to_string(index=False))
 print('\nTRAINING:\n',df[df.partition=='training'][['K','policy','run','rmse_C','source_lead_min','status','recrossings']].to_string(index=False))
