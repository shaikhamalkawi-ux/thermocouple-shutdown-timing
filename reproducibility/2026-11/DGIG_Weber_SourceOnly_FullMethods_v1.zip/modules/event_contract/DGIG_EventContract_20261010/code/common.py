from __future__ import annotations
from pathlib import Path
import hashlib,io,json,zipfile,re
from datetime import datetime,timezone
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
INPUT=ROOT/'inputs/compact'
OUT=ROOT/'results'
EXPECTED={4:(14766,'985f4452c04e495c6f07227d3ce238975d596caa5a9ea04f8e52fb08645e1d68'),5:(16243,'3318140e2de217cce5c407f862b238385f5872e46a11710ef8fed260cce22425'),6:(11069,'cbbf5b9846c2bd0945cebf6517f8a9b003f7d4b5aaf54c1de6bc8dc8de1a629b'),7:(15935,'19b88ec506a3e2407ca4bb40adeb8247d2467f4913b0a62de39afede45254a6b'),8:(9076,'1cbfdd865524224959a0d28836528c79dc7228e37e725e9e4be7b32f4ea799ef'),9:(14058,'050bd98e110121a9063e7c361f8a7cbbedad55fea6eed42c05e2e69a22ccbe2e')}
TRAIN=(4,6,7,8)
TEST=(5,9)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,obj):
 Path(p).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def utc():return datetime.now(timezone.utc).isoformat()
def load_runs(strict=True,write_provenance=False):
 runs={};prov=[]
 for zp in sorted(INPUT.glob('*PRIMARY*.zip')):
  with zipfile.ZipFile(zp) as z:
   for name in z.namelist():
    if not name.endswith('MeasurementData.CSV'):continue
    r=int(Path(name).parent.name.split('_')[0]);raw=z.read(name);h=hashlib.sha256(raw).hexdigest()
    n_exp,h_exp=EXPECTED[r]
    if h!=h_exp:raise ValueError((r,h,'hash mismatch'))
    df=pd.read_csv(io.BytesIO(raw),sep=';',decimal=',',low_memory=False)
    if len(df)!=n_exp:raise ValueError('row mismatch')
    names=['Time since Start [min]','TR404-085d','TR404-108e','Heater_AO']
    values=df[names].to_numpy(float)
    if not np.isfinite(values).all():raise ValueError('nonfinite source data')
    on=values[:,3]>4.5
    starts=np.flatnonzero(on & np.r_[True,~on[:-1]])
    ends=np.flatnonzero(on & np.r_[~on[1:],True])+1
    k=int(np.argmax(ends-starts));s,a=int(starts[k]),int(ends[k]); stop=a if strict else a+1
    t=values[s:stop,0];x=values[s:stop,1];y=values[s:stop,2]
    if np.any(np.diff(t)<=0):raise ValueError('nonincreasing time')
    runs[r]={'run':r,'t':t,'x':x,'y':y,'action':float(values[a,0]),'start':float(t[0]),'horizon':float(t[-1])}
    prov.append(dict(run=r,member=name,sha256=h,rows=len(df),start_row=s,action_row=a,n_preaction=a-s,archive=zp.name))
 if write_provenance:pd.DataFrame(prov).sort_values('run').to_csv(OUT/'source_provenance.csv',index=False)
 if set(runs)!=set(range(4,10)):raise ValueError('run scope differs')
 return runs

def gradient(t,y,w=15.):
 ii=np.flatnonzero(t>=t[0]+w);tt=t[ii]
 if np.ndim(y)==1:return tt,(y[ii]-np.interp(tt-w,t,y))/w
 past=np.column_stack([np.interp(tt-w,t,y[:,j]) for j in range(y.shape[1])])
 return tt,(y[ii]-past)/w

def event(tt,g,threshold=1.):
 ii=np.flatnonzero((g[:-1]>=threshold)&(g[1:]<threshold))
 if not len(ii):return None
 i=int(ii[0]);return float(tt[i]+(threshold-g[i])*(tt[i+1]-tt[i])/(g[i+1]-g[i]))

def hat(x,knots):
 x=np.clip(x,knots[0],knots[-1]);j=np.clip(np.searchsorted(knots,x,side='right')-1,0,len(knots)-2)
 z=(x-knots[j])/(knots[j+1]-knots[j]);B=np.zeros((len(x),len(knots)))
 B[np.arange(len(x)),j]=1-z;B[np.arange(len(x)),j+1]=z
 return B

def interp_vec(t,v,query):
 if np.ndim(v)==1:return float(np.interp(query,t,v))
 return np.array([np.interp(query,t,v[:,j]) for j in range(v.shape[1])])

def score(r,knots,h):
 t,x,y=r['t'],r['x'],r['y'];yh=hat(x,knots)@h
 tt,g=gradient(t,yh);_,gy=gradient(t,y);first=event(tt,g);src=event(tt,gy)
 stat='censored_deadline_missed' if first is None and src is not None and t[-1]>=src else 'censored_unresolved'
 if first is not None:
  stat='within_window' if src-5<=first<=src else 'too_early' if first<src-5 else 'after_source_deadline'
 ups=None if first is None else int(np.sum((tt[1:]>=first)&(g[:-1]<1)&(g[1:]>=1)))
 return dict(run=r['run'],rmse_C=float(np.sqrt(np.mean((yh-y)**2))),gradient_rmse_K_min=float(np.sqrt(np.mean((g-gy)**2))),source_event_min=src,first_event_min=first,source_lead_min=None if first is None else src-first,status=stat,recrossings=ups,gradient_at_source=float(np.interp(src,tt,g)),horizon=r['horizon'],horizon_after_source_min=r['horizon']-src,out_of_support=int(np.sum((x<knots[0])|(x>knots[-1]))))
