"""Regenerate the two real-data decision-variable figures (separate figures)."""
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
# Embed searchable TrueType fonts in the vector PDF (no palette changes).
matplotlib.rcParams['pdf.fonttype'] = 42
from common import ROOT, load_runs, gradient, event, hat


def main():
    output = ROOT / 'figures'
    output.mkdir(exist_ok=True)
    runs = load_runs(strict=True)
    policies = [
        ('temperature_only', 'Temperature-only fit', '--'),
        ('min_MSE_contract', 'Minimum-error event contract', '-.'),
        ('max_margin_50pct', 'Maximum-margin event contract', ':'),
    ]
    for number in (5, 9):
        run = runs[number]
        times, ref_gradient = gradient(run['t'], run['y'])
        ref_event = event(times, ref_gradient)
        if ref_event is None:
            raise RuntimeError(f'Test {number}: reference event unavailable')
        relative = times - ref_event
        visible = relative >= -6
        fig, ax = plt.subplots(figsize=(8.5, 4.8))
        ax.plot(relative[visible], ref_gradient[visible],
                label='Reconstructed reference gradient', linewidth=1.8)
        for policy, label, style in policies:
            model = pd.read_csv(ROOT/'results'/f'K7_{policy}_knots.csv')
            prediction = hat(run['x'], model['candidate_knot_C'].to_numpy()) @ model['predicted_source_knot_C'].to_numpy()
            _, g = gradient(run['t'], prediction)
            ax.plot(relative[visible], g[visible], linestyle=style, linewidth=1.7, label=label)
        ax.axhline(1.0, linestyle='--', linewidth=1.0, label='Threshold: 1 K/min')
        ax.axvline(0.0, linestyle=':', linewidth=1.0)
        ax.set_xlabel('Time relative to the reconstructed reference event (min)', fontsize=11)
        ax.set_ylabel('Reconstructed 15-minute gradient (K/min)', fontsize=11)
        ax.set_title(f'D50 Test {number}: same seven-knot model, different training objectives', fontsize=12)
        ax.set_xlim(-6, relative[-1] + 0.08)
        ax.legend(fontsize=9, loc='best')
        ax.tick_params(labelsize=10)
        fig.tight_layout()
        fig.savefig(output/f'D50_Test{number}_decision_contract.pdf')
        fig.savefig(output/f'D50_Test{number}_decision_contract.png', dpi=170)
        plt.close(fig)

if __name__ == '__main__':
    main()
