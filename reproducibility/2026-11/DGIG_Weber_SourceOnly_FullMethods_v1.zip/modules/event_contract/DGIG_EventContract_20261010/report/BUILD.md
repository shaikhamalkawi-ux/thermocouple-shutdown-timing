Build the mathematical report after the figures are present:

```bash
cd report
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```
The delivered report is at ../DGIG_EventContract_NewResults_20261010.pdf. TeX installation is only required for editing/rebuilding the report, not numerical reproduction.
