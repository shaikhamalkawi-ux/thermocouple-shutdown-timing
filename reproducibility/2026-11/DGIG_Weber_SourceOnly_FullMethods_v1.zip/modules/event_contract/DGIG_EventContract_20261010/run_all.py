#!/usr/bin/env python3
"""Recompute in a clean temporary tree, leaving shipped evidence unchanged.

Usage: python run_all.py [--output /an/empty/directory]
A new output directory is created; an existing directory is never overwritten.
No network access is used. Original compact inputs accompany this package.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare_csv(original, rerun):
    """Full row/column check; exact identities and finite numeric tolerances."""
    import math
    import numpy as np
    with original.open(newline='') as f:
        a = list(csv.reader(f))
    with rerun.open(newline='') as f:
        b = list(csv.reader(f))
    if len(a) != len(b) or a[0] != b[0]:
        raise AssertionError(f'CSV schema differs: {original.name}')
    count = 0
    for rowa, rowb in zip(a[1:], b[1:]):
        if len(rowa) != len(rowb):
            raise AssertionError(f'Column count differs: {original.name}')
        for x, y in zip(rowa, rowb):
            if x == y:
                count += 1
                continue
            # Model byte hashes depend on floating-point serializer; compare
            # their corresponding knot arrays separately below.
            if len(x) == 64 and len(y) == 64:
                try:
                    int(x, 16); int(y, 16)
                    continue
                except ValueError:
                    pass
            try:
                xx, yy = float(x), float(y)
            except ValueError as exc:
                raise AssertionError(f'Text differs in {original.name}: {x!r} / {y!r}') from exc
            if not (math.isfinite(xx) and math.isfinite(yy) and np.isclose(xx, yy, rtol=1e-10, atol=1e-9)):
                raise AssertionError(f'Numeric difference in {original.name}: {x} / {y}')
            count += 1
    return {'file': original.name, 'rows': len(a)-1, 'cells_compared': count,
            'byte_identical': digest(original) == digest(rerun), 'numeric_match': True}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, help='New directory for logs and regenerated results.')
    args = p.parse_args()
    start = time.perf_counter()
    if args.output:
        target = args.output.resolve()
        target.mkdir(parents=True, exist_ok=False)
    else:
        target = Path(tempfile.mkdtemp(prefix='dgig-event-contract-'))
    for directory in ('results', 'verification', 'figures'):
        (target/directory).mkdir()
    shutil.copytree(ROOT/'code', target/'code', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    shutil.copytree(ROOT/'inputs'/'compact', target/'inputs'/'compact')
    for name in ('PROTOCOL.md', 'PROTOCOL_NUMERICAL_ADDENDUM.md'):
        shutil.copy2(ROOT/name, target/name)
    env = dict(os.environ, MPLBACKEND='Agg', OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1', PYTHONDONTWRITEBYTECODE='1')
    steps = ['test_methods.py', 'train_contract.py', 'polish_training.py',
             'evaluate_contract.py', 'moving_reference.py', 'independent_raw_audit.py',
             'rational_moving_audit.py', 'make_figures.py']
    step_records = []
    for name in steps:
        t = time.perf_counter()
        print(f'Running {name}...', flush=True)
        proc = subprocess.run([sys.executable, str(target/'code'/name)],
                              cwd=target, env=env, text=True, capture_output=True)
        (target/'verification'/f'{name}.log').write_text(proc.stdout + '\n' + proc.stderr)
        step_records.append({'step':name, 'returncode':proc.returncode,
                             'runtime_s':time.perf_counter()-t})
        if proc.returncode:
            raise RuntimeError(f'{name} failed; inspect {target}/verification/{name}.log')
    matches = []
    for old in sorted((ROOT/'results').glob('*.csv')):
        matches.append(compare_csv(old, target/'results'/old.name))
    import numpy as np
    matrix_matches = []
    for old in sorted((ROOT/'results').glob('*.npz')):
        a, b = np.load(old), np.load(target/'results'/old.name)
        assert set(a.files) == set(b.files)
        for key in a.files:
            np.testing.assert_allclose(a[key], b[key], rtol=1e-10, atol=1e-9,
                                       err_msg=f'{old.name}/{key}')
        matrix_matches.append({'file': old.name, 'arrays': len(a.files), 'match': True})
    audit = json.loads((target/'verification'/'INDEPENDENT_RAW_AUDIT.json').read_text())
    assert audit['all_statuses_and_recrossings_match']
    assert audit['exact_K5_infeasibility_certificate']['no_positive_margin_possible']
    assert all(x['passes'] for x in audit['exact_positive_contract_checks'])
    exact = json.loads((target/'verification'/'EXACT_MOVING_REFERENCE_AUDIT.json').read_text())
    # The audit programs assert the inside/outside brackets and exact cancellation.
    result = {'status':'PASS', 'steps':step_records, 'csv_matches':matches,
              'matrix_matches':matrix_matches, 'independent_numeric_rows':audit['independent_numeric_rows'],
              'exact_contract_checks':len(audit['exact_positive_contract_checks']),
              'total_runtime_s':time.perf_counter()-start,
              'fresh_output':str(target),
              'scope':'New contract/drift extension only; not a rerun of every historical DGIG analysis.'}
    (target/'verification'/'FRESH_REPLAY.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
