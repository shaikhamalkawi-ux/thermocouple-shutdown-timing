from pathlib import Path
import csv,hashlib,sys
root=Path(__file__).resolve().parent
with (root/'MANIFEST_SHA256.csv').open(newline='') as f: rows=list(csv.DictReader(f))
errors=[]
expected=set()
for r in rows:
 p=root/r['path'];expected.add(r['path'])
 if not p.is_file():errors.append((r['path'],'missing'));continue
 if p.stat().st_size!=int(r['bytes']) or hashlib.sha256(p.read_bytes()).hexdigest()!=r['sha256']:errors.append((r['path'],'size/hash'))
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
unlisted=actual-expected-{'MANIFEST_SHA256.csv'}
if unlisted:errors.append(('unlisted',sorted(unlisted)))
print({'entries':len(rows),'errors':errors,'status':'PASS' if not errors else 'FAIL'})
sys.exit(bool(errors))
