# Which numerical files are authoritative?

Final calibrated maps are the `results/K*_knots.csv` outputs. Final convex-QP training losses, constraints and multipliers are in `results/QP_KKT_CERTIFICATES.json`. Final all-run scores and censoring are in `results/decision_contract_all_run_results.csv`; the six primary D50 comparisons are copied without refitting to `HELD_OUT_RESULTS.csv`.

`K5_training_diagnostics.json` and `K7_training_diagnostics.json` intentionally preserve the initial LP/SLSQP training stage. Policy-specific heights/losses in that stage can differ from the FINAL lexicographic KKT-polished maps, and must not be quoted as their final values. Global LP margin optima remain the same. The subsequent final training freeze includes both the original diagnostics and the final QP certificates, before evaluation. See the recorded pre-evaluation numerical addendum for this deterministic resolution of nonunique margin optima.

The `max_margin_screen` and `max_margin_50pct` K7 maps are identical because the temperature-error budget is inactive. Do not count them as independent methods. The negative-margin K5 `max_margin_screen` map is an inadmissible relaxed diagnostic, not a contract-satisfying solution.

`verification/pre_tie_closure/` is historical numerical provenance; it does not supersede the final freeze or final results. `verification/INHERITED_FIXED_THRESHOLD_RESULT_NOT_NEW.md` is an earlier DGIG result included specifically to avoid misrepresenting it as new.

Exact fresh verification uses `INDEPENDENT_RAW_AUDIT.json` and `EXACT_MOVING_REFERENCE_AUDIT.json`. The latter certifies the reported inside/outside radius brackets, not the untested physical distribution of sensor errors.
