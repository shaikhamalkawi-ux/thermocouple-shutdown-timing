# Completed scientific extension to frozen DGIG R14

## Decision

Retain the same-basis event-contract optimization, exact fixed-grid certificates and complete D50 failure/success accounting. Do not present generic decision-focused learning, standard linear-program duality or the inherited fixed-threshold radius as novel. Do not add a new model family. The R14 manuscript remains unchanged in this investigation.

## Baseline and new research questions

The original six-run temperature/event finding is preserved. The new questions are: (1) can the same frozen calibration basis satisfy an explicit no-early / below-at-deadline contract at all; (2) does changing only the training objective alter held-out event behavior; and (3) does a continuum of source as well as candidate drifts change common-threshold feasibility?

## Verified results

For the frozen five-knot grid, two original-data constraints imply a maximum margin of at most -0.012048708953505667 K/min. Therefore no nonnegative contract margin exists. The exact certificate is independent of the optimizer and appears in `verification/INDEPENDENT_RAW_AUDIT.json`. This excludes only the stated sufficient contract for that grid. The five- and seven-knot grids are not nested, so no universal minimum number of knots is inferred.

For the seven-knot grid, a three-inequality exact certificate bounds the maximum training margin by 0.15813400011990505 K/min. A feasible lexicographic fit achieves at least 0.15813399911989648 K/min when rechecked using exact native-decimal arithmetic. The 50% training-RMSE criterion is inactive at this optimum. The same fitted map appears under two diagnostic labels; these are not distinct methods.

The minimum-MSE positive-contract fit increases training MSE from 13.804229623878763 to 13.865648885080324 C^2. The minimum exact realized margin is positive, approximately 9.9999999874e-7 K/min; this is a numerical strictness guard, not a physical noise tolerance. The maximum-margin fit has training MSE 76.4380105331841 C^2.

Test 5: temperature-only RMSE 3.161608 C with no observed first crossing; minimum-error contract RMSE 3.164872 C with first crossing 2.283046 minutes before source and 12 upward recrossings; maximum-margin contract RMSE 8.348282 C with first crossing 2.423893 minutes before source and zero subsequent recrossings in the recorded continuation. The first change is only about 0.1033% in held-out temperature RMSE.

Test 9: all three remain right-censored and miss the one-sided reconstructed-source deadline. RMSEs are 2.422469, 2.381220 and 8.545004 C, respectively. The strict observed horizons extend 1.434889 and 0.146208 minutes beyond the reference event in Tests 5 and 9. No eventual later crossing is inferred.

All six primary K7 D50 policy/run rows have zero out-of-training-range raw candidate values. These comparisons therefore do not depend on extrapolating the held-out inputs outside the fitted knot span. Good input-range support is not a generalization certificate.

The moving-reference drift calculation produces a feasible interior radius 0.0009743989999993201 and an infeasible exterior radius 0.0009744009999993203 K/min, independently checked with exact decimal Fraction arithmetic. The source-fixed and source-moving limits coincide at the displayed precision. This is a useful unchanged-result finding, not stronger physical robustness. Ninety direct raw perturbation witnesses agree, but the continuum claim rests on interval-branch algebra and exact checks rather than the finite witness count.

## Verification and numerical scope

- 14 synthetic/analytic unit tests pass.
- A separate raw csv/bisect implementation reproduces all 36 exported computational policy/run rows and censoring/recrossing statuses; max discrepancy 1.42e-14.
- Eight positive-contract training histories pass exact rational checks; exact K5 obstruction and K7 upper certificate pass.
- Four source-fixed/source-moving inside/outside brackets pass a second exact branch calculation.
- Fresh-tree replay passes all eight program stages; ten result CSVs are byte-identical; two LP matrix containers match numerically.
- The 36 rows are NOT 36 independent experiments. They include training rows and a duplicate maximum-margin K7 policy label. Experimental units remain six.

## Why this can strengthen the paper

The paper can distinguish a failure of temperature-only training from a failure of a specified contract in a frozen representation, and a failure of internal fit from failure on a withheld configuration. The new contribution candidate is a compact, verifiable contract analysis applied to real measurements, with exact witnesses and mixed transfer outcomes. This is more specific than the already-established slogan that prediction accuracy need not imply decision quality.

No first-in-literature claim is established by this targeted search. No new external operational validation, sensor-noise uncertainty coverage, physical energy result, or closed-loop controller result is produced. Do not turn the zero-recrossing Test 5 trace into a statement about an alternative physically switched trajectory.
