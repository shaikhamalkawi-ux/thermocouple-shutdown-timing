# DGIG: verified event-contract calibration and transfer limits

Research extension calculated on 10 October 2026. **R14 is unchanged.** This is a completed numerical investigation, not a submitted manuscript, an externally reviewed theorem, or prospective controller validation.

## Read first

- `DGIG_EventContract_NewResults_20261010.pdf`: mathematical definitions, exact certificates, held-out outcomes, real-data plots and literature comparison.
- `FINDINGS.md`: machine-readable companion summary.
- `HELD_OUT_RESULTS.csv`: all six primary K7 policy / D50 comparisons. Blank event times and recrossing counts mean censored / undefined, NOT zero.
- `LITERATURE_REGISTER.csv`: closest primary sources, scope of inspection, and the distinction from this work.

## Completed work

The same existing seven-knot model was fitted with different training objectives, without changing the four-training/two-D50 split. Minimum-temperature-error event constraints recover Test 5's first event with RMSE 3.164872 C versus 3.161608 C for temperature-only training, but yield 12 later upward recrossings. A maximum-margin fit yields Test 5's first event with no later recrossings on the recorded continuation and RMSE 8.348282 C. Both policies still miss the source deadline in Test 9. Nothing here executes an alternative physical heater command.

An exact native-decimal two-constraint certificate proves the fixed five-knot grid cannot satisfy the stated sufficient event contract at any nonnegative margin. This is NOT an impossibility result for all first-event-preserving maps or all five-knot grids. The fixed seven-knot grid has a certified margin upper bound near 0.158134 K/min and an exact checked feasible fit within 1e-9 K/min of it.

The moving-reference linear-drift analysis retains the existing limiting scale (about 0.0009744 K/min); it is a useful scope check, not a new headline result. No physical error coverage is assigned to this deterministic drift family.

## Reproduce

Use Python 3.11 or later with the dependencies in `requirements.txt`. The exact tested Python and library versions are in `ENVIRONMENT.json`. No network is needed after installing dependencies.

```bash
python run_all.py
```

The runner copies code and compact inputs into a NEW temporary directory. It executes fourteen unit tests, LP/QP training, freezes training outputs before held-out evaluation, repeats the drift analysis and two separate raw/Fraction audit implementations, regenerates both figures, and compares all shipped numerical result CSVs and LP matrices. The original frozen evidence is not overwritten. To retain output at a chosen location, pass `--output PATH_TO_NEW_DIRECTORY`.

A clean-tree rerun completed all eight program stages in about 20.6 seconds in the recorded environment. Ten result CSVs were byte-identical. Runtime is descriptive and will vary across machines. It is not a performance benchmark.

## Experimental and methodological boundaries

Six original Weber runs come from one apparatus. The source is TR404-108e, the candidate is TR404-085d. Tests 4,6,7,8 are training; 5,9 are D50 evaluation. The source first event and the 5-minute one-sided acceptance window are numerical analysis definitions. These data had already been inspected in prior research. The protocol predates the NEW computations, not access to the experimental campaign. Model optimization never uses D50 loss or event times. An explicit pre-evaluation addendum resolves nonunique LP solutions by minimum training MSE.

The contract requires no early crossing AND a value below threshold at the deadline. It is sufficient but not necessary for first-event agreement, because an admissible first crossing can recross above threshold before the deadline. Two positive contract policies are tested; duplicate `max_margin_screen` and `max_margin_50pct` results have identical K7 maps and are not independent methods. The negative-margin K5 screen result is retained only as an inadmissible relaxed diagnostic.

Independent implementation means a separately coded checker, not a separate human research team. Exact rational checks certify the finite recorded decimal numbers and chosen model representation, not physical metrological accuracy. This is not a probability model, energy-saving result, safety assessment or closed-loop validation.

## Data, rights and archive scope

The compact original source ZIPs and the native measurement CSV bytes are carried forward unchanged from the verified DGIG source archive. Weber Version 2 is CC BY 4.0; see `DATA_ATTRIBUTION.md`. Source hashes and native row counts are checked before use. Original R14 manuscript, supplement, and complete historical software are NOT duplicated here, and were not modified.

New analysis code and reports are supplied for author review. No public code-license decision or journal acceptance is implied. This package was not automatically committed to public GitHub or deposited on Zenodo.

Use `python verify_manifest.py` for exact package-integrity verification. Code and new numeric results are the additions; literature is used to delimit claims, not to substitute for experiments.
