# Fixed-input first-crossing robustness: verified result

The single authorized real-data run completed with exit code 0 after a repeated 12/12 synthetic-test pass. No R8 files were changed. The threshold and protocol were fixed before loading these robustness inputs.

## Result

For the fixed nearest-channel threshold **0.6507958600000014 K/min**, all six recorded gradient traces satisfy the stated first-crossing contract for **every independent gradient-node perturbation with absolute magnitude at most 0.0009734255999992653 K/min**. The certificate excludes every possible downward crossing before the fixed source event minus five minutes, and supplies a robust-above/robust-below witness establishing a crossing by the fixed source event.

All inequalities were independently re-evaluated using exact fractions of the frozen binary64 inputs. This certifies those numerical arrays and fixed target times only. It does not certify upstream gradient-computation rounding, source-event reconstruction as physical truth, digitization, temperature-sensor noise, historical supervisory code, or prospective operation. Subsequent re-crossings are allowed: the contract concerns the first crossing, not stable-below behavior.

| Quantity | Value (K/min) | Interpretation |
|---|---:|---|
| Nominal numerical band cap estimate | 0.0009743999999992647 | Derived from existing binary64 band endpoints, not exactly certified |
| Reported exact-input sufficient radius | 0.0009734255999992653 | All six runs pass; 0.1% deliberate interior cushion |
| Explicit counterexample radius | 0.0009753743999992641 | Exact-input violating perturbation for the same fixed threshold |

The lower and counterexample upper bounds are close (gap about 0.2% of the nominal cap estimate). These bounds apply to this **fixed chosen threshold**, not a threshold optimized for robustness. The numerical bisection's upper value equals the initialized nominal cap and was not recorded as a failed trial; it is a search boundary, not a demonstrated failing radius. The verified upper claim instead comes from the explicit replay below. No additional halvings of the predetermined interior radius were needed.

## Counterexample and other failures

At radius 0.0009753743999992641 K/min, **Test 6** admits an early event on gradient segment 3646 (zero-based). Reducing both endpoints 3646 and 3647 by that radius, leaving all other nodes unchanged, yields an exact first crossing whose decimal display is **80.80443262113252 min**, before its fixed lower boundary **80.85289108544097 min**. Its upper/source boundary is 85.85289108544097 min. These coordinates use the deposited time field, not time since heater-on.

The nominal event is on segment 3670 at 81.2002671482658 min. Thus the counterexample activates an earlier crossing branch; it is not merely a perturbation of the nominal crossing segment. This demonstrates why the entire earlier history was included.

A uniform gradient shift of **-0.0009753743999992641 K/min** independently gives the same Test-6 early event. Exact replay finds the other five runs still within their fixed windows under this particular uniform shift. This explicit admissible vector is enough to disprove universal box robustness at that radius, independently of the numerical precision of the original threshold band.

At this same probe radius, the sufficient deadline witness fails for Test 7. No early counterexample was found there by the exact early-history test. This is labelled **inconclusive for Test 7**, not a proved late event or proof of failed universal timing. Tests 4, 5, 8 and 9 retain sufficient certificates at the probe radius. The Test-6 counterexample alone supplies the required verified upper bound.

## Per-run witnesses at the reported sufficient radius

Indices below refer to the saved gradient arrays, not raw CSV row numbers. Every below witness is an observed node before the corresponding frozen source deadline. The exact times and margins are retained as rational strings in the JSON.

| Run | Robust-above node | Robust-below node | Entire early history excluded | Exact sufficient result |
|---:|---:|---:|---|---|
| 4 | 265 | 3812 | Yes | PASS |
| 5 | 267 | 3711 | Yes | PASS |
| 6 | 265 | 3671 | Yes | PASS |
| 7 | 259 | 4232 | Yes | PASS |
| 8 | 277 | 3699 | Yes | PASS |
| 9 | 265 | 3643 | Yes | PASS |

## Files and audit schema

* `PROTOCOL.md`: frozen assumptions, test, cushion and scope.
* `gradient_robustness.py`: pure float/exact functions, synthetic tests, gated real-data runner.
* `outputs/robustness_certificate.json`: `theta`, `band`, `results.reported_radius`, `results.exact_check.runs`, nominal numerical search history, per-run provenance and hashes, `near_cap_probe.runs`, `constant_shift_probe`, `verified_counterexample_upper_radius`.
* `outputs/frozen_gradient_inputs.json.gz`: gzip UTF-8 JSON with top-level `theta` and `traces`; each trace has `name`, `times`, `values`, `lower`, `upper`, `horizon`. All are the inputs used, allowing verification without reparsing source measurement archives.

Each `results.exact_check.runs` entry contains `name`, `passed`, `early_counterexample`, and `deadline_witness`. Exact deadline witnesses include above/below indices, rational times and strict/non-strict margins. The Test-6 counterexample is also available in `near_cap_probe.runs` and `early_examples`, with exact endpoint deltas and direct first-event time. Source provenance, protocol/script hashes and big-endian binary64 array hashes are retained.

## Manuscript recommendation

Keep this as a compact supplementary qualification, not a new headline, figure, theorem or sensor-accuracy claim. It validates the numerical scale of the narrow threshold band and exposes the earlier-history failure branch just beyond it. It does not demonstrate that realistic errors belong to this box or resolve the source-event uncertainty. Constant additive temperature bias cancels from the gradient; this result must not be converted into an equivalent physical temperature-noise tolerance.
