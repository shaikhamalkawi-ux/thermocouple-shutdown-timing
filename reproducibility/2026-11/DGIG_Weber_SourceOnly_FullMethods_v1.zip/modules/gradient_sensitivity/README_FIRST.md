# DGIG R14 — Supplemental numerical-sensitivity reproducibility module

This self-contained *code and results module* uses original, source-hashed Weber Version-2 packed-bed measurements, distributed in a separately provided reviewer archive. It does not supply a physical uncertainty budget, an observed substitute-triggered heater shutoff, or independent multi-apparatus validation. No new model is fitted.

The dated scenario protocol preceded the new calculations but followed prior study of the six-run campaign. Near-nominal changes in the mathematical rule are a 15-minute gradient window plus/minus 1 second and a threshold of 1 K/min plus/minus 0.001 K/min. The eight broader scenarios are exploratory; none is calibrated as an instrument tolerance or probability model.

## Source input

Obtain the unchanged `DGIG_R13_Reviewer_Reproducibility.zip` (SHA-256 `711551269b904ad73614111c77084d7658101f90dde5ed05b07e2c04716b9413`). This companion contains Weber measurements, source hashes, original calculations, the frozen 5-/7-knot D50 check and its separately implemented numerical audit. It is not uploaded inside the public GitHub repository. Source DOI: https://doi.org/10.17632/3pp86gdvh4.2 (CC BY 4.0).

## Exact reproduction commands

Tested using Python 3.13 and versions specified in `requirements.txt`:

```bash
python -m pip install -r requirements.txt
python prepare_inputs.py --archive /path/to/DGIG_R13_Reviewer_Reproducibility.zip
python -m unittest discover -s tests -v
python analyze_dgig_stress.py --phase all
python independent_sensitivity_audit.py
python plot_dgig_diagnostics.py
```

The extraction script SHA-verifies the immutable input ZIP, then writes original raw inputs only to local `repro/` and `blocked/` directories. The main script recomputes seven scientific CSVs, including 102 nearest-channel scenario/run rows, 34 D50 K7 scenario rows, decision-gradient diagnostics and exact first-event threshold intervals. The independent standalone audit rereads the original measurements and reproduces 54 near-nominal source/candidate event pairs, 18 D50 case-status pairs and 48 nonempty common-threshold interval midpoint witnesses. The independent 1001-point candidate sweep corroborates one empty interval, but the exact continuous interval endpoints are provided by the separately retained inverse-piece algorithm, not independently derived by this sweep.

`plot_dgig_diagnostics.py` regenerates the four vector PDF plots (plus optional PNG previews). PDF CreationDate metadata may change across runs; scientific CSV values and state labels are the substantive reproducibility target.

## Findings and limits

The unmodified 80-mm candidate's first event remains earlier than the reconstructed source event on all six runs in all nine near-nominal mathematical rule specifications; these 54 row/case calculations reuse six experimental units. Frozen D50 K7 temperature and gradient RMSEs both decrease, yet both source-event deadlines are missed. An all-six-run *retrospective* common candidate-threshold interval is nonempty under eight of the nine near-nominal cases and empty for a 15-min+1-s window and source threshold 0.999 K/min, due to a Test-6/Test-7 constraint gap. These are not evidence of calibrated sensor noise robustness, energy savings, prospective closed-loop control, or statistical generalizability.

This module plus the verified companion source archive is the intended reviewer reproduction path. The public GitHub preview at https://github.com/shaikhamalkawi-ux/thermocouple-shutdown-timing is not a complete reproduction deposit; no persistent Zenodo DOI is asserted. `SHA256SUMS.csv` identifies the module's immutable files on delivery.
