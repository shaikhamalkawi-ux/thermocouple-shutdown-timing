# Weber source evidence gate for physical uncertainty claims

Original journal article: Anika Weber et al., **Experimental dataset of fluid flow and heat transfer in a shallow packed bed at low Reynolds numbers**, *Data in Brief* **61** (2025), article 111743, DOI https://doi.org/10.1016/j.dib.2025.111743. Published version is hosted by the German Aerospace Center: https://elib.dlr.de/216089/1/1-s2.0-S2352340925004706-main.pdf .

**Source Table 5 (PDF page 19)** explicitly reports in-house calibrated Type-N thermocouples, calibrated in increasing 50 K steps through the measurement chain. Listed manufacturer/calibration instrument accuracy ranges:

- **323–523 K:** ±4.57 K.
- **573–823 K:** ±2.28 K.

The published table does not provide here a usable per-sample dynamic residual noise autocorrelation model for the specific two channels during heating. The ranges have a gap (523–573 K), and an absolute accuracy bound should not be silently transformed into independent per-second Gaussian noise, thermocouple time drift, or a statistical 95% uncertainty interval.

**Admissible mathematics only (conditional bound, not a measured result):** For a finite 15-min gradient `g(t)=[T(t)-T(t-15)]/15`, additive temperature bias constant in time cancels **exactly**. If two endpoint errors are each bounded absolutely by an `A` value valid at BOTH corresponding temperatures, then the conservative instantaneous gradient-error bound is `2A/15` K/min. This gives *conditional worst-case algebraic* bounds of 0.60933 K/min for `A=4.57 K` and 0.30400 K/min for `A=2.28 K`. These values are NOT established dynamic fluctuation magnitudes for this experiment, and do not estimate a time-to-event error distribution or physical event uncertainty.

The archived prior `GRADIENT_ROBUSTNESS` computation gives an exact-input sufficient radius of 0.0009734256 K/min for a fixed candidate threshold and frozen source event on the six numerical gradient arrays. That certificate is NOT equivalent to instrument accuracy, an uncertainty budget, or robust transfer under perturbations of both channels and of the source event.

**Scientific gate:** Broad physical measurement-noise certification stays HOLD until source-backed channel-specific calibration residuals, noise spectrum/serial correlation, timing alignment and the relevant covariance assumptions are admissible. The 17 new operator/window/threshold scenarios are clearly labelled *specification stress*; they are not physical-noise trials. No arbitrary Monte Carlo, no added sensor-error model and no claim about expected probability of event reversal are included.
