#!/usr/bin/env python3
"""Extract original read-only DGIG R13 reviewer archive for the bounded checks.

This script deliberately never writes into the original archive; it checks the
known SHA-256 and extracts only to the local evidence workspace.
"""
import hashlib,zipfile,argparse
from pathlib import Path
HERE=Path(__file__).resolve().parent
EXPECTED='711551269b904ad73614111c77084d7658101f90dde5ed05b07e2c04716b9413'

def check_and_extract(src,dest):
 h=hashlib.sha256()
 with src.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 if h.hexdigest()!=EXPECTED:raise ValueError(f'Reviewer archive checksum mismatch: {h.hexdigest()} != {EXPECTED}')
 dest.mkdir(exist_ok=True,parents=True)
 with zipfile.ZipFile(src) as z:
  if z.testzip() is not None:raise ValueError('Reviewer archive CRC error')
  for x in z.infolist():
   safe=(dest/x.filename).resolve()
   if not safe.is_relative_to(dest.resolve()):raise ValueError('Unsafe member name')
  z.extractall(dest)
 inner=dest/'DGIG_WRITER2_BLOCKED_TEST_20260927_CHECKPOINT_01.zip'
 with zipfile.ZipFile(inner) as z:
  if z.testzip() is not None:raise ValueError('Inner blocked archive CRC error')
  blocked=HERE/'blocked';blocked.mkdir(exist_ok=True)
  for x in z.infolist():
   safe=(blocked/x.filename).resolve()
   if not safe.is_relative_to(blocked.resolve()):raise ValueError('Unsafe nested member name')
  z.extractall(blocked)
 print('INPUTS PASS: reviewer archive SHA-256 and both ZIP CRC checks; original source bytes preserved')

if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('--archive',type=Path,required=True,help='path to unchanged DGIG_R13_Reviewer_Reproducibility.zip')
 p.add_argument('--destination',type=Path,default=HERE/'repro')
 a=p.parse_args();check_and_extract(a.archive,a.destination)
