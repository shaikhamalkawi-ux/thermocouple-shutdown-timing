import sys, unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from analyze_dgig_stress import gradients,first_cross,recross_count

class TestStandaloneEventLogic(unittest.TestCase):
 def test_observed_downcrossing(self):
  t=np.array([0.,1.,2.,3.]);g=np.array([2.,1.5,.5,.3])
  self.assertAlmostEqual(first_cross(t,g,1.),1.5)
 def test_initial_below_not_arm(self):
  self.assertIsNone(first_cross(np.array([0.,1.,2.]),np.array([.6,.5,.4]),1.))
 def test_strict_threshold_semantics(self):
  self.assertEqual(first_cross(np.array([0.,1.,2.]),np.array([1.3,1.,.2]),1.),1.)
 def test_constant_additive_bias_exact_cancellation(self):
  t=np.linspace(0,30,1001);v=np.sin(t/3)*5+20
  tt,a=gradients(t,v,15.);qq,b=gradients(t,v+2.28,15.)
  np.testing.assert_allclose(a,b,atol=2e-14,rtol=0.)
 def test_affine_gradient(self):
  t=np.linspace(0,31,1002);v=np.sin(t/4)*8+3
  _,a=gradients(t,v,15.);_,b=gradients(t,1.7*v+45,15.)
  np.testing.assert_allclose(1.7*a,b,atol=3e-14,rtol=0.)
 def test_upward_recrosses_only_after_first(self):
  t=np.arange(6.);g=np.array([1.4,.4,1.2,.5,1.3,.3])
  self.assertEqual(recross_count(t,g,1.),2)

if __name__=='__main__':unittest.main()
