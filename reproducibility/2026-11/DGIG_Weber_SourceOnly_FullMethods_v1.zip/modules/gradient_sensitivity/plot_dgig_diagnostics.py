#!/usr/bin/env python3
"""Post-analysis visual evidence summaries, with no new fitted models."""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams['pdf.fonttype']=42
plt.rcParams['ps.fonttype']=42
BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs';PLOTS=BASE/'figures'; PLOTS.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':10.5,'axes.labelsize':11,'axes.titlesize':12,'xtick.labelsize':9.5,'ytick.labelsize':9.5,'legend.fontsize':9})

# 1: Six-run first-event lead over nine small specification stress cases.
a=pd.read_csv(OUT/'specification_stress_six_runs.csv')
a=a[a.tier.eq('micro')].copy();order=sorted(a.scenario_id.unique(),key=lambda x:(float(x.split('_W')[1].split('_T')[0]),float(x.split('_T')[1])))
code={sc:i for i,sc in enumerate(order)}
fig,ax=plt.subplots(figsize=(10.4,5.1))
marks=['o','s','^','d','v','P'];styles=['-','--','-.',':','-','--']
for j,run in enumerate(sorted(a.run.unique())):
    df=a[a.run.eq(run)].set_index('scenario_id').loc[order]
    ax.plot(np.arange(9),df.candidate_lead_vs_source_min.values,marker=marks[j],linestyle=styles[j],linewidth=1.5,markersize=4.3,label=f'Test {run}')
ax.axhline(0,linestyle=':',color='0.2',linewidth=1)
ax.set_xticks(np.arange(9),[f'{float(x.split("_W")[1].split("_T")[0]):.3f}\n{float(x.split("_T")[1]):.3f}' for x in order])
ax.set_xlabel('15-min gradient window (min) / source threshold (K min$^{-1}$)')
ax.set_ylabel('Source minus 80-mm candidate first crossing (min)')
ax.set_title('Near-nominal specification stress: nearest candidate remains early in six runs')
ax.legend(ncol=6,loc='upper center',bbox_to_anchor=(.5,-.24),frameon=False)
ax.grid(alpha=.3);fig.subplots_adjust(bottom=.32,left=.1,right=.98,top=.89)
for ext in ('png','pdf'):fig.savefig(PLOTS/f'fig_micro_source_candidate_leads.{ext}',dpi=220)
plt.close(fig)

# 2: Exact observed-trace threshold intersection under 9 micro scenarios.
b=pd.read_csv(OUT/'threshold_oracle_specification_stress.csv');b=b[b.tier.eq('micro')].set_index('scenario_id').loc[order]
fig,ax=plt.subplots(figsize=(9.4,5.0))
for i,(name,row) in enumerate(b.iterrows()):
    if row.all_six_intersection_status=='nonempty':
        ax.plot([row.widest_interval_lower,row.widest_interval_upper],[i,i],linewidth=6,solid_capstyle='butt',color='0.25' if name=='micro_W15.000000_T1.000' else '0.5')
        ax.plot([row.widest_interval_lower,row.widest_interval_upper],[i,i],linestyle='',marker='|',markersize=11,color='black')
    else:
        ax.plot(.6502,i,marker='x',markersize=10,markeredgewidth=2,color='black')
        ax.annotate('empty (Test 6 / Test 7 gap)',(.65035,i),xytext=(5,0),textcoords='offset points',va='center',fontsize=9)
ax.axvline(.65079586,linestyle='--',linewidth=1,color='0.3',label='Original-band midpoint')
ax.set_yticks(range(len(order)),[f'{float(x.split("_W")[1].split("_T")[0]):.3f} min / {float(x.split("_T")[1]):.3f}' for x in order]); ax.invert_yaxis()
ax.set_xlabel('Common candidate threshold (K min$^{-1}$)')
ax.set_title('Retrospective common-threshold interval changes under specification stress')
ax.grid(axis='x',alpha=.25);ax.legend(frameon=False,loc='upper center',bbox_to_anchor=(.55,-.12));fig.subplots_adjust(left=.25,right=.98,top=.89,bottom=.24)
for ext in ('png','pdf'):fig.savefig(PLOTS/f'fig_oracle_feasible_intervals.{ext}',dpi=220)
plt.close(fig)

# 3: Observed original source and frozen K7 15-min gradient near the D50 source event.
file=BASE/'blocked'/'DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/WRITER2_COLLABORATION_20260927/BLOCKED_LOW_CAPACITY_20260927/verified_outputs/evaluated/held_out_samples.csv'
c=pd.read_csv(file)
for run in (5,9):
  df=c[(c.held_out_run==run)&(c.method=='K7')].sort_values('time_min')
  tt=df.time_min.to_numpy(float);gref=df.source_trailing15_gradient_K_per_min.to_numpy(float);gpred=df.mapped_trailing15_gradient_K_per_min.to_numpy(float)
  mask=np.isfinite(gref)&np.isfinite(gpred);tt=tt[mask];gref=gref[mask];gpred=gpred[mask]
  e=int(np.flatnonzero((gref[:-1]>=1)&(gref[1:]<1))[0]);refev=tt[e]+(1-gref[e])*(tt[e+1]-tt[e])/(gref[e+1]-gref[e]);horizon=tt[-1]
  flt=(tt-refev>=-2.5)&(tt-refev<=max(1.8,horizon-refev+.3))
  fig,ax=plt.subplots(figsize=(8.5,4.8))
  ax.plot(tt[flt]-refev,gref[flt],linewidth=1.8,linestyle='-',label='Reference gradient (reconstructed)')
  ax.plot(tt[flt]-refev,gpred[flt],linewidth=1.8,linestyle='--',label='Frozen K7 mapped gradient')
  ax.axhline(1.0,color='black',linestyle=':',linewidth=1.4,label='Termination threshold: 1 K/min')
  ax.axvline(0,color='0.4',linestyle='-.',linewidth=1.2,label='Reconstructed source event')
  ax.axvline(horizon-refev,color='0.1',linestyle=':',linewidth=1.2,label='Strict observation horizon')
  ax.set_xlim(-2.55,max(1.8,horizon-refev+.3))
  ax.set_xlabel('Time relative to reconstructed reference crossing (min)')
  ax.set_ylabel('Reconstructed 15-min gradient (K min$^{-1}$)')
  ax.set_title(f'Frozen seven-knot D50 Test {run}: source threshold vs mapped gradient')
  ax.grid(alpha=.22);ax.legend(loc='upper center',bbox_to_anchor=(.5,-.22),frameon=False,fontsize=9,ncol=3)
  fig.subplots_adjust(bottom=.32,left=.115,right=.98,top=.89)
  for ext in ('png','pdf'):fig.savefig(PLOTS/f'fig_D50_test{run}_local_gradient.{ext}',dpi=220)
  plt.close(fig)
print('Created',len(list(PLOTS.glob('*.png'))),'PNG and',len(list(PLOTS.glob('*.pdf'))),'vector PDF figures')
