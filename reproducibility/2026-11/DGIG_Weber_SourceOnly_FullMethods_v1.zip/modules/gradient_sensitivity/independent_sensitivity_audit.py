#!/usr/bin/env python3
"""Separate read-path audit of R13 proposed sensitivity (not JME manuscript code).

Source raw CSV measurements are read from the frozen CC-BY source ZIPs. No
imports of the original sensitivity script, its threshold-certificate module,
or its parameter definitions. Independent implementation of first downcross.
"""
from __future__ import annotations
import io, zipfile, json, hashlib, math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'repro/DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/R2E_REPRO_CLEAN_20260920/source_zips'
D50=ROOT/'blocked/DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/WRITER2_COLLABORATION_20260927/BLOCKED_LOW_CAPACITY_20260927/verified_outputs/evaluated/held_out_samples.csv'
OUT=ROOT/'outputs'
REPORT=ROOT/'INDEPENDENT_REPLAY_RESULT.json'
EXPECTED={
4:'985f4452c04e495c6f07227d3ce238975d596caa5a9ea04f8e52fb08645e1d68',
5:'3318140e2de217cce5c407f862b238385f5872e46a11710ef8fed260cce22425',
6:'cbbf5b9846c2bd0945cebf6517f8a9b003f7d4b5aaf54c1de6bc8dc8de1a629b',
7:'19b88ec506a3e2407ca4bb40adeb8247d2467f4913b0a62de39afede45254a6b',
8:'1cbfdd865524224959a0d28836528c79dc7228e37e725e9e4be7b32f4ea799ef',
9:'050bd98e110121a9063e7c361f8a7cbbedad55fea6eed42c05e2e69a22ccbe2e'}


def action_bounds(heater):
    """Longest contiguous heater-on segment and first following off sample."""
    on=np.asarray(heater)>4.5
    seg=[];first=None
    for i,b in enumerate(on):
        if b and first is None:first=i
        if first is not None and (not b or i==len(on)-1):
            last=i if not b else i+1
            if last < len(on):seg.append((last-first,first,last))
            first=None
    assert seg
    _,s,off=max(seg,key=lambda z:z[0])
    return s,off


def gradients(t,y,w):
    ix=np.flatnonzero((t-t[0])>=w)
    xx=t[ix];gl=(y[ix]-np.interp(xx-w,t,y))/w
    return xx,gl


def event(t,g,level):
    for i in range(1,len(g)):
        if g[i-1]>=level and g[i]<level:
            return float(t[i-1]+(level-g[i-1])*(t[i]-t[i-1])/(g[i]-g[i-1]))
    return None

raw={}; hashes=0
for name in ['A_tests4_6','B_tests7_9']:
    with zipfile.ZipFile(BASE/f'DGIG_WEBER_CORE_PRIMARY_{name}.zip') as z:
        for fn in z.namelist():
            if not fn.endswith('/MeasurementData.CSV'):continue
            run=int(Path(fn).parent.name.split('_')[0]);blob=z.read(fn)
            assert hashlib.sha256(blob).hexdigest()==EXPECTED[run]
            d=pd.read_csv(io.BytesIO(blob),sep=';',decimal=',',low_memory=False)
            s,a=action_bounds(d.Heater_AO.to_numpy(float))
            t=d['Time since Start [min]'].to_numpy(float)[s:a+1]
            y=d['TR404-108e'].to_numpy(float)[s:a+1]
            x=d['TR404-085d'].to_numpy(float)[s:a+1]
            assert np.all(np.diff(t)>0)
            raw[run]=(t,y,x)
            hashes+=1
assert hashes==6

summary=pd.read_csv(OUT/'specification_stress_summary.csv')
assert len(summary)==17
micro=summary.loc[summary.tier=='micro']
assert len(micro)==9
primary_rows=pd.read_csv(OUT/'specification_stress_six_runs.csv')
assert len(primary_rows)==102
checked=0
for _,s in micro.iterrows():
    for run in range(4,10):
        t,y,x=raw[run]
        ts,gs=gradients(t,y,s.window_min);_,gc=gradients(t,x,s.window_min)
        e_ref=event(ts,gs,s.source_threshold);e_cand=event(ts,gc,s.source_threshold)
        r=primary_rows[(primary_rows.scenario_id==s.scenario_id)&(primary_rows.run==run)].iloc[0]
        assert e_ref is not None and e_cand is not None and e_cand<e_ref
        assert abs(e_ref-r.source_first_min)<1e-8
        assert abs(e_cand-r.candidate_first_min)<1e-8
        checked+=1
assert checked==54

samples=pd.read_csv(D50)
blocked=pd.read_csv(OUT/'d50_K7_specification_stress.csv')
assert len(blocked)==34
blocked_micro=blocked[blocked.tier=='micro']
checked_d50=0
for run in (5,9):
    r=samples[(samples.held_out_run==run)&(samples.method=='K7')].sort_values('time_min')
    t=r.time_min.to_numpy(float);ref=r.source_C.to_numpy(float);y=r.predicted_C.to_numpy(float)
    for _,rr in blocked_micro[blocked_micro.run==run].iterrows():
        xx,gr=gradients(t,ref,rr.window_min)
        _,gm=gradients(t,y,rr.window_min)
        e_ref=event(xx,gr,rr.source_threshold);e_map=event(xx,gm,rr.source_threshold)
        assert e_ref is not None and abs(e_ref-rr.source_first_min)<1e-8
        assert (e_map is None)==(rr.candidate_event_status=='right_censored')
        assert rr.one_sided_deadline_status in ('missed_deadline','after_source_deadline')
        if e_map is not None:
            assert abs(e_map-rr.candidate_first_min)<1e-8 and e_map>e_ref
        else:
            assert t[-1]>e_ref
        checked_d50+=1
    if run==5:
        nom=blocked_micro[(blocked_micro.run==run)&blocked_micro.scenario_id.eq('micro_W15.000000_T1.000')].iloc[0]
        tt,gr=gradients(t,ref,15);_,gm=gradients(t,y,15)
        rmse=float(np.sqrt(np.mean((gm-gr)**2)))
        assert abs(rmse-.19466)<1e-5
        assert abs(np.interp(nom.source_first_min,tt,gm)-1.04874)<1e-5
    if run==9:
        nom=blocked_micro[(blocked_micro.run==run)&blocked_micro.scenario_id.eq('micro_W15.000000_T1.000')].iloc[0]
        tt,gr=gradients(t,ref,15);_,gm=gradients(t,y,15)
        rmse=float(np.sqrt(np.mean((gm-gr)**2)))
        assert abs(rmse-.17759)<1e-5
        assert abs(np.interp(nom.source_first_min,tt,gm)-1.03748)<1e-5
assert checked_d50==18

orac=pd.read_csv(OUT/'threshold_oracle_specification_stress.csv')
assert len(orac)==17 and sum(orac[orac.tier=='micro'].all_six_intersection_status=='nonempty')==8
# Reconstruct the event for the midpoint witness in all eight nonempty cases,
# checking *six* runs each; verify the nominal interval & failed-interval
# geometric conflict at the published source-event window.
witness_checks=0
for _,v in orac[(orac.tier=='micro')&(orac.all_six_intersection_status=='nonempty')].iterrows():
    threshold=.5*(v.widest_interval_lower+v.widest_interval_upper)
    for run in range(4,10):
        t,ref,cand=raw[run]
        tt,gs=gradients(t,ref,v.window_min)
        _,gc=gradients(t,cand,v.window_min)
        e_ref=event(tt,gs,v.source_threshold)
        e_cand=event(tt,gc,threshold)
        assert e_ref is not None and e_cand is not None
        assert (e_ref-5-1e-9<=e_cand<=e_ref+1e-9)
        witness_checks+=1
assert witness_checks==48
fail=orac[(orac.tier=='micro')&(orac.all_six_intersection_status=='empty')].iloc[0]
assert fail.scenario_id=='micro_W15.016667_T0.999'
prs=pd.read_csv(OUT/'threshold_oracle_per_run_feasible_sets.csv')
x6=prs[(prs.scenario_id==fail.scenario_id)&(prs.run==6)].iloc[0]
x7=prs[(prs.scenario_id==fail.scenario_id)&(prs.run==7)].iloc[0]
assert x6.max_upper < x7.min_lower
# Sample direct candidates densely in the narrow [0.64, 0.66] region, to
# corroborate the exact interval certificate's sign (not a standalone proof).
th_grid=np.linspace(.64,.66,1001)
cnt=0
# Cache source/candidate gradient arrays ONCE per run; only the prospective
# candidate threshold changes across 1001 sampled witness checks.
stored={}
for run in range(4,10):
    t,ref,cand=raw[run]
    tt,gr=gradients(t,ref,fail.window_min)
    _,gc=gradients(t,cand,fail.window_min)
    stored[run]=(tt,gc,event(tt,gr,fail.source_threshold))
for level in th_grid:
    ok=True
    for run,(tt,gc,a) in stored.items():
        b=event(tt,gc,level)
        if a is None or b is None or not(a-5<=b<=a):ok=False;break
    cnt+=int(ok)
assert cnt==0
res=dict(status='PASS',scope='Independent code path reading original source CSV bytes; no import of sensitivity code or oracle interval solver',source_runs_verified=hashes,primary_micro_run_scenarios_verified=checked,d50_micro_case_statuses_verified=checked_d50,oracle_nonempty_midpoint_witnesses_verified=witness_checks,failed_case_grid_no_candidates=1001,oracle_exact_interval_not_independently_derived=True)
REPORT.write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps(res,indent=2))
