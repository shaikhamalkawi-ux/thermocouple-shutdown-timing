#!/usr/bin/env python3
"""Bounded reproducible DGIG sensitivity and decision-variable diagnostics.

Research baseline is R13, not a R14 submission manuscript.
NO measurement-uncertainty claims. Full protocol in PROTOCOL_BEFORE_NEW_CALCULATIONS.md.
"""
from __future__ import annotations
import sys, hashlib, io, json, zipfile, csv, time, importlib.util, argparse
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
WORK = HERE/'repro'/'DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK'
OUT = HERE/'outputs'; OUT.mkdir(parents=True,exist_ok=True)
CANON = WORK/'R2E_REPRO_CLEAN_20260920/scripts/reproduce_weber_operational.py'
CERT = WORK/'SCIENTIFIC_ADVANCE_20260927/THRESHOLD_CERTIFICATE/threshold_certificate.py'
CAUSAL = WORK/'SCIENTIFIC_ADVANCE_20260927/CAUSAL_CORRECTION/run_causal_correction.py'
BLOCK = HERE/'blocked'/'DGIG_OVERNIGHT_AUTONOMOUS_BUILD_WORK/WRITER2_COLLABORATION_20260927/BLOCKED_LOW_CAPACITY_20260927'

def import_mod(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module
mod=import_mod(CANON,'weber_canonical')
cert=import_mod(CERT,'weber_certificate')
causal=import_mod(CAUSAL,'weber_causal')
SOURCE='TR404-108e'; CAND='TR404-085d'

# Predeclared explicit specification stress, NOT physical-measurement uncertainty.
STRESSES=[]
for tier, windows, thresholds in [
    ('micro', [15-1/60,15.,15+1/60], [0.999,1.,1.001]),
    ('broad',[14.5,15.,15.5],[0.99,1.,1.01])
]:
    for w in windows:
        for th in thresholds:
            if tier=='broad' and w==15. and th==1.:
                continue
            STRESSES.append(dict(tier=tier,window_min=float(w),source_threshold=float(th),scenario_id=f'{tier}_W{w:.6f}_T{th:.3f}'))
assert len(STRESSES)==17

def get_runs():
    runs={}
    hashes=[]
    for key in ('A_tests4_6','B_tests7_9'):
        zpath=WORK/f'R2E_REPRO_CLEAN_20260920/source_zips/DGIG_WEBER_CORE_PRIMARY_{key}.zip'
        with zipfile.ZipFile(zpath) as z:
            for filename in z.namelist():
                if not filename.endswith('/MeasurementData.CSV'):continue
                run=int(filename.split('/')[-2].split('_')[0]); assert run in range(4,10)
                raw=z.read(filename)
                digest=hashlib.sha256(raw).hexdigest()
                rows,sha=mod.EXPECTED_SOURCE[run]
                assert digest==sha,(run,'SHA mismatch')
                df=mod.load_measurement(io.BytesIO(raw))
                assert len(df)==rows
                assert np.all(np.isfinite(df[['Time since Start [min]',SOURCE,CAND,'Heater_AO']].to_numpy(float)))
                start, action=mod.reconstruct_action(df)
                t=df['Time since Start [min]'].to_numpy(float)[start:action+1]
                ref=df[SOURCE].to_numpy(float)[start:action+1]
                x=df[CAND].to_numpy(float)[start:action+1]
                assert np.all(np.diff(t)>0)
                gref_t,gref=gradients(t,ref,15.)
                eref=first_cross(gref_t,gref,1.)
                gcand_t,gcand=gradients(t,x,15.)
                ecand=first_cross(gcand_t,gcand,1.)
                assert eref is not None and ecand is not None
                runs[run]=dict(t=t,ref=ref,x=x,act_time=float(t[-1]),start_time=float(t[0]),source_first=eref,cand_first=ecand,raw_sha=digest)
                hashes.append(dict(run=run,original_archive=zpath.name,original_member=filename,bytes=len(raw),sha256=digest,rows=rows))
    assert sorted(runs)==list(range(4,10))
    pd.DataFrame(hashes).sort_values('run').to_csv(OUT/'source_provenance.csv',index=False)
    return runs

def gradients(t,y,window):
    """Causal trailing finite difference; only within supplied and observed time domain."""
    ii=np.flatnonzero(t>=t[0]+window)
    tt=t[ii]
    past=np.interp(tt-window,t,y)
    gg=(y[ii]-past)/window
    return tt,gg

def first_cross(tt,g,theta):
    # Source protocol: crossing must be armed by a preceding g >= theta.
    ix=np.flatnonzero((g[:-1]>=theta)&(g[1:]<theta))
    if not len(ix): return None
    i=int(ix[0]);y0,y1=g[i],g[i+1]
    return float(tt[i]+(theta-y0)*(tt[i+1]-tt[i])/(y1-y0))

def first_cross_slope(tt,g,theta):
    ix=np.flatnonzero((g[:-1]>=theta)&(g[1:]<theta))
    if not len(ix): return None
    i=int(ix[0])
    return float((g[i+1]-g[i])/(tt[i+1]-tt[i]))

def recross_count(tt,g,theta):
    first=first_cross(tt,g,theta)
    if first is None:return None
    ix=(tt[1:]>=first-1e-10)&(g[:-1]<theta)&(g[1:]>=theta)
    return int(ix.sum())

def gradient_rmse(tt,g,tt2,g2):
    assert len(tt)==len(tt2) and np.max(np.abs(tt-tt2))<1e-9
    return float(np.sqrt(np.mean((g-g2)**2)))

def scen_status(tval,target,lower5=5):
    if target is None:return 'source_event_censored'
    if tval is None:return 'right_censored'
    if target-lower5<=tval<=target:return 'within_one_sided_5_min'
    return 'earlier_than_one_sided_window' if tval<target-lower5 else 'after_source_deadline'

def stress_primary(runs):
    primary=[]
    for sc in STRESSES:
        window=sc['window_min']; theta=sc['source_threshold']
        for r,data in sorted(runs.items()):
            t=data['t'];tt,gref=gradients(t,data['ref'],window);_,gx=gradients(t,data['x'],window)
            src=first_cross(tt,gref,theta);cand=first_cross(tt,gx,theta)
            primary.append(dict(**sc,run=r,source_event_status='observed' if src is not None else 'right_censored',
                source_first_min=src,candidate_event_status='observed' if cand is not None else 'right_censored',
                candidate_first_min=cand,recorded_action_min=data['act_time'],
                candidate_lead_vs_source_min=src-cand if src is not None and cand is not None else None,
                candidate_lead_vs_command_min=data['act_time']-cand if cand is not None else None,
                source_to_command_min=data['act_time']-src if src is not None else None,
                first_candidate_crossing_slope_K_min2=first_cross_slope(tt,gx,theta),
                candidate_upward_recrossings=recross_count(tt,gx,theta)))
    pd.DataFrame(primary).to_csv(OUT/'specification_stress_six_runs.csv',index=False)
    summary=[]
    for sc in STRESSES:
        part=[row for row in primary if row['scenario_id']==sc['scenario_id']]
        leads=np.array([row['candidate_lead_vs_source_min'] for row in part if row['candidate_lead_vs_source_min'] is not None]);
        summary.append(dict(**sc,runs=6,source_events_observed=sum(r['source_first_min'] is not None for r in part),
            candidate_events_observed=sum(r['candidate_first_min'] is not None for r in part),
            all_candidate_before_source=bool(len(leads)==6 and np.all(leads>0)),
            minimum_lead_vs_source_min=float(leads.min()) if len(leads) else None,
            maximum_lead_vs_source_min=float(leads.max()) if len(leads) else None,
            minimum_lead_vs_action_min=min((r['candidate_lead_vs_command_min'] for r in part if r['candidate_lead_vs_command_min'] is not None),default=None)))
    pd.DataFrame(summary).to_csv(OUT/'specification_stress_summary.csv',index=False)
    return primary,summary

def stress_blocked():
    d=pd.read_csv(BLOCK/'verified_outputs/evaluated/held_out_samples.csv')
    expected=pd.read_csv(BLOCK/'verified_outputs/evaluated/held_out_results.csv')
    primary=[]
    for sc in STRESSES:
        for run in (5,9):
            rows=d[(d['held_out_run']==run)&(d['method']=='K7')].sort_values('time_min')
            t=rows['time_min'].to_numpy(float); source=rows['source_C'].to_numpy(float); predicted=rows['predicted_C'].to_numpy(float)
            assert len(t)>4500 and np.all(np.diff(t)>0)
            tt,gg=gradients(t,source,sc['window_min']);_,gp=gradients(t,predicted,sc['window_min'])
            src=first_cross(tt,gg,sc['source_threshold']);pred=first_cross(tt,gp,sc['source_threshold'])
            horizon=t[-1]
            primary.append(dict(**sc,run=run,map='K7_frozen',source_first_min=src,
                 candidate_event_status='observed' if pred is not None else 'right_censored',
                 candidate_first_min=pred,observation_horizon_min=float(horizon),
                 post_source_observed_min=float(horizon-src) if src is not None else None,
                 one_sided_deadline_status=('missed_deadline' if pred is None and src is not None and horizon>=src else
                     'unresolved' if pred is None else scen_status(pred,src)),
                 mapped_gradient_at_source_K_min=float(np.interp(src,tt,gp)) if src is not None else None,
                 source_gradient_at_source_K_min=float(np.interp(src,tt,gg)) if src is not None else None))
    pd.DataFrame(primary).to_csv(OUT/'d50_K7_specification_stress.csv',index=False)
    orig=pd.read_csv(BLOCK/'verified_outputs/evaluated/held_out_results.csv')
    for run in (5,9):
        old=orig[(orig.held_out_run==run)&(orig.method=='K7')].iloc[0]
        sc=next(x for x in primary if x['run']==run and x['scenario_id']=='micro_W15.000000_T1.000')
        assert abs(sc['source_first_min']-float(old['source_first_min']))<1e-8
        assert sc['candidate_event_status']=='right_censored' and sc['one_sided_deadline_status']=='missed_deadline'
        assert abs(sc['post_source_observed_min']-(float(old['observation_horizon_min'])-float(old['source_first_min'])))<1e-8
    return primary

def diagnostic_decision_variable(runs):
    cd=pd.read_csv(WORK/'SCIENTIFIC_ADVANCE_20260927/CAUSAL_CORRECTION/outputs/held_out_results.csv')
    md=pd.read_csv(WORK/'SCIENTIFIC_ADVANCE_20260927/MONOTONE_STATIC_CORRECTION/outputs/held_out_samples.csv')
    mr=pd.read_csv(WORK/'SCIENTIFIC_ADVANCE_20260927/MONOTONE_STATIC_CORRECTION/outputs/held_out_results.csv')
    dd=pd.read_csv(BLOCK/'verified_outputs/evaluated/held_out_samples.csv')
    dr=pd.read_csv(BLOCK/'verified_outputs/evaluated/held_out_results.csv')
    out=[]
    for run,data in sorted(runs.items()):
        # Use exactly strict preaction grid and source values, matching prior LORO result.
        t=data['t'][:-1]; ref=data['ref'][:-1]; candidate=data['x'][:-1]; tt,source_g=gradients(t,ref,15.)
        src=first_cross(tt,source_g,1.)
        assert abs(src-data['source_first'])<1e-8
        for method in ['identity','temperature_affine_tau0','temperature_causal_selected','temperature_isotonic_piecewise_linear']:
            if method=='temperature_isotonic_piecewise_linear':
                samp=md[md.held_out_run==run].sort_values('time_min');
                assert len(samp)==len(t) and np.max(np.abs(samp.time_min.to_numpy()-t))<1e-6
                mapped=samp.predicted_C.to_numpy(float)
                old=mr[mr.held_out_run==run].iloc[0]
            else:
                old=cd[(cd.held_out_run==run)&(cd.sensor==CAND)&(cd.method==method)].iloc[0]
                if method=='identity':mapped=candidate
                elif method=='temperature_affine_tau0':mapped=float(old.gain)*candidate+float(old.offset_C)
                else:
                    mapped=float(old.gain)*causal.causal_filter(t,candidate,float(old.tau_min))+float(old.offset_C)
            assert abs(np.sqrt(np.mean((mapped-ref)**2))-float(old.rmse_C))<2e-7,(run,method,'RMSE discrepancy')
            _,mapped_g=gradients(t,mapped,15.);cross=first_cross(tt,mapped_g,1.)
            expected_cross=old.crossing_min
            if pd.isna(expected_cross): assert cross is None,(run,method,'unexpected observed event')
            else: assert cross is not None and abs(cross-float(expected_cross))<2e-6,(run,method,'event discrepancy')
            out.append(dict(run=run,method=method,split='overlapping_LORO_exploratory',
                temp_rmse_C=float(old.rmse_C),gradient_rmse_K_min=gradient_rmse(tt,mapped_g,tt,source_g),
                mapped_gradient_at_source_K_min=float(np.interp(src,tt,mapped_g)),
                signed_margin_vs_1_at_source_K_min=float(np.interp(src,tt,mapped_g)-1.),
                event_status='observed' if cross is not None else 'right_censored',
                first_event_min=cross,abs_event_error_vs_source_min=abs(src-cross) if cross is not None else None,
                first_crossing_slope_K_min2=first_cross_slope(tt,mapped_g,1.),
                upward_recrossings=recross_count(tt,mapped_g,1.),
                source_first_min=src,observation_horizon_min=t[-1],source_gradient_at_source=float(np.interp(src,tt,source_g))))
    for run in (5,9):
        for method in ('identity','K5','K7'):
            rows=dd[(dd.held_out_run==run)&(dd.method==method)].sort_values('time_min')
            t=rows.time_min.to_numpy(float);ref=rows.source_C.to_numpy(float);mapped=rows.predicted_C.to_numpy(float)
            tt,sg=gradients(t,ref,15.);_,mg=gradients(t,mapped,15.)
            src=first_cross(tt,sg,1.);cross=first_cross(tt,mg,1.)
            old=dr[(dr.held_out_run==run)&(dr.method==method)].iloc[0]
            assert len(t)==old.n_samples
            assert abs(np.sqrt(np.mean((mapped-ref)**2))-float(old.rmse_C))<2e-7
            if pd.isna(old.crossing_min): assert cross is None
            else: assert abs(cross-float(old.crossing_min))<2e-6
            out.append(dict(run=run,method=method,split='blocked_D50_train_homogeneous',
                temp_rmse_C=float(old.rmse_C),gradient_rmse_K_min=gradient_rmse(tt,mg,tt,sg),
                mapped_gradient_at_source_K_min=float(np.interp(src,tt,mg)),
                signed_margin_vs_1_at_source_K_min=float(np.interp(src,tt,mg)-1.),
                event_status='observed' if cross is not None else 'right_censored',
                first_event_min=cross,abs_event_error_vs_source_min=abs(src-cross) if cross is not None else None,
                first_crossing_slope_K_min2=first_cross_slope(tt,mg,1.),
                upward_recrossings=recross_count(tt,mg,1.),
                source_first_min=src,observation_horizon_min=t[-1],source_gradient_at_source=float(np.interp(src,tt,sg))))
    pd.DataFrame(out).to_csv(OUT/'decision_variable_error_by_run.csv',index=False)
    return out

def stress_oracle(runs):
    all_rows=[]
    per_run_rows=[]
    for sc in STRESSES:
        tic=time.monotonic()
        ww=sc['window_min'];ss=sc['source_threshold']
        recs=[]
        for run,data in sorted(runs.items()):
            tt,gs=gradients(data['t'],data['ref'],ww)
            target=first_cross(tt,gs,ss)
            if target is None:
                recs.append(dict(run=run,target=None,pieces=[]));continue
            _,gx=gradients(data['t'],data['x'],ww)
            pieces=cert.inverse_pieces(tt,gx)
            per_run=cert.feasible(pieces,target,5.)
            per_run_rows.append(dict(scenario_id=sc['scenario_id'],run=run,source_event_min=target,component_count=len(per_run),intervals_json=json.dumps([dict(lo=x.lo,hi=x.hi,lc=x.lc,hc=x.hc) for x in per_run]),min_lower=min((x.lo for x in per_run),default=None),max_upper=max((x.hi for x in per_run),default=None)))
            recs.append(dict(run=run,target=target,pieces=pieces,tt=tt,gg=gx))
        if any(x['target'] is None for x in recs):
            bands=[];status='source_event_unobserved'
        else:
            bands=cert.common_feasible(recs,5.)
            status='nonempty' if bands else 'empty'
        widths=[max(0.,b.hi-b.lo) for b in bands]
        best=max(bands,key=lambda z:z.hi-z.lo) if bands else None
        if best is not None:
            # Direct event replay, independent of inverse-piece membership formula.
            witness=(best.lo+best.hi)*.5
            for rec in recs:
                trig=first_cross(rec['tt'],rec['gg'],witness)
                assert trig is not None and rec['target']-5.-1e-8<=trig<=rec['target']+1e-8,(sc['scenario_id'],rec['run'],'oracle witness failed')
        all_rows.append(dict(**sc,source_event_observed=sum(x['target'] is not None for x in recs),
            all_six_intersection_status=status,connected_interval_count=len(bands),
            total_threshold_band_width_K_min=float(sum(widths)),
            widest_interval_lower=best.lo if best else None,
            widest_interval_upper=best.hi if best else None,
            nominal_theta_0p65079586_feasible=bool(cert.point_in_sets(bands,.65079586)) if bands else False,
            ))
        print('ORACLE',sc['scenario_id'],status,'components',len(bands),'width',sum(widths),'time',round(time.monotonic()-tic,2),flush=True)
    df=pd.DataFrame(all_rows)
    df.to_csv(OUT/'threshold_oracle_specification_stress.csv',index=False)
    pd.DataFrame(per_run_rows).to_csv(OUT/'threshold_oracle_per_run_feasible_sets.csv',index=False)
    nominal=df.loc[df.scenario_id.eq('micro_W15.000000_T1.000')].iloc[0]
    # Only if code agrees with the already frozen nominal interval.
    assert nominal.all_six_intersection_status=='nonempty'
    assert abs(nominal.widest_interval_lower-.64982146)<3e-7
    assert abs(nominal.widest_interval_upper-.65177026)<3e-7
    return all_rows

def main():
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=['all','stress','decision','oracle'],default='all');args=p.parse_args()
    runs=get_runs()
    # Frozen unchanged-rule: numerical verification of six source/candidate event leads.
    pub=pd.read_csv(WORK/'R2E_REPRO_CLEAN_20260920/outputs/primary_same_level_results.csv')
    for run,data in sorted(runs.items()):
        row=pub[(pub.run==run)&(pub.sensor==CAND)].iloc[0]
        assert abs((data['act_time']-data['cand_first'])-float(row.lead_vs_action_min))<1e-6, (run,'action lead mismatch',row.lead_vs_action_min,data)
    if args.phase in ('all','stress'):
        ss,summary=stress_primary(runs)
        blocked=stress_blocked()
        print('STRESS',len(ss),'primary scenario rows;',len(blocked),'D50 rows; all-nearest-before-source',sum(r['all_candidate_before_source'] for r in summary),'/',len(summary))
        for run in (5,9):
            k=[r for r in blocked if r['run']==run];print('D50',run,[(x['scenario_id'],x['one_sided_deadline_status']) for x in k])
    if args.phase in ('all','decision'):
        d=diagnostic_decision_variable(runs)
        print('DECISION',len(d),'rows; gradient median grouped:')
        print(pd.DataFrame(d).groupby(['split','method'],sort=False)[['temp_rmse_C','gradient_rmse_K_min']].median().round(4).to_string())
    if args.phase in ('all','oracle'):
        stress_oracle(runs)
    print('PHASE COMPLETE',args.phase)
if __name__=='__main__':main()
