# DGIG experimental operator and decision-variable stress protocol

Purpose: respond to a post hoc reviewer suggestion on the locked DGIG R13 scientific baseline. This is NOT a preregistered study, laboratory calibration, uncertainty budget, or new model-selection exercise.

Input admission: use only the byte-verified Weber Version-2 primary experiments Tests 4–9 from the already archived DGIG R13 reviewer reproduction ZIP; frozen 80-mm nearest alternative, 95-mm source, all six run units, and fixed 15-min/1 K min^-1 original decision rule. For the D50 diagnostic reuse only the frozen training-selected 7-knot map and originally held-out Tests 5 and 9, without refitting or reselecting.

Baseline replay: reconstruct heater-action indices exactly as the source script (longest interval with Heater_AO >4.5 mA). Primary direct substitution uses the action sample as originally published; fitted-method comparisons and D50 use last sample STRICTLY before action; first downcross requires preceding value >= theta and subsequent value < theta. An absent event is right-censored, not assigned zero error. First crossing is linearly interpolated. Source event must be recalculated under the identical alternative operator/threshold for both channels.

Analytical stress grids (chosen before new scenario outcomes; they are not evidence of measurement uncertainty):
- 'Micro' specification stress: gradient window 15 minutes minus/plus exactly 1 second; threshold 1.000 minus/plus 0.001 K/min. These are diagnostic rounding/operational-specification changes only and not claimed instrument errors.
- 'Broad' specification stress: gradient window 14.5 / 15 / 15.5 minutes; threshold 0.99 / 1 / 1.01 K/min. They are deliberately visible sensitivity probes, not physical-calibration ranges. Preserve nominal case once; 17 unique scenarios total.
- Distinguish reinterpreting the gradient operator/threshold from perturbing measured temperatures. DO NOT add a stochastic measurement perturbation without a traceable calibration-driven scale/time correlation. Retain the existing R9 exact-input bounded-gradient-node certificate as historical, fixed-source-deadline logic; do not present it as hardware accuracy.

Readouts: run-wise source-event relative to recorded command, nearest-candidate lead vs source/command, first-event status/censoring, signed deadline classification for D50 K7, and the full post-source strict observation margin. Original 24 same-level primary rows and the two locked D50 identities must be checked against archived outputs.

Decision-variable diagnostics: from existing frozen affine, 2-minute causal+affine, high-capacity isotonic, and blocked K7 predictions, calculate gradient RMSE over paired eligible time samples, signed mapped-gradient minus 1 K/min at the RECONSTRUCTED source first crossing, local crossing slope, event status, upward recross count and temperature RMSE; independently check reproduced mapped temperatures against frozen results to within numeric tolerances. All run units remain distinct. This does not turn high-capacity vs low-capacity predictions into a controlled same-split comparator.

Threshold oracle: recompute six-run feasible candidate-threshold intersections for one-sided window [reconstructed source event minus 5 min, reconstructed source event], with source event recalculated for each specification stress. Use the recorded history only, do not extend beyond heater action. Report count/width of connected interval components, and whether the original common interval survives. A static threshold from all six runs is a retrospective oracle, not a prospective transferable controller.

Output gate: scientific controls and full row-level CSVs, code and source SHA manifest. Keep new results as diagnostic/supplementary until numerical review; no uncalibrated noise assumptions, no claims of physical uncertainty or energy savings. Do not change R13 scientific results, manuscript or GitHub on basis of a preliminary stress test.
